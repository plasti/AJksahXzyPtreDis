@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Nuevo usurio</span></h1>

			<section class="form-edit">
				<form action="{{ route('users.store') }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}

					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre *</label>
						<input type="text" name="name" id="name" value="{{ old('name') }}" placeholder="Nombre del usuario">
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('email') ? ' has-error' : '' }}">
						<label for="email">E-mail</label>
						<input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus placeholder="ejemplo@correo.com">
						@if ($errors->has('email'))
							<span class="valida-msg">
								<strong>{{ $errors->first('email') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('id_group') ? ' has-error' : '' }}">
						<label for="{{'id_group'}}">Grupo *</label>
						<select name="{{'id_group'}}" id="{{'id_group'}}">
							@foreach($grupos as $grupo)
								<option value="{{$grupo->id}}">{{$grupo->name}}</option>
							@endforeach
						</select>
						@if ($errors->has('id_group'))
							<span class="valida-msg">
								<strong>{{ $errors->first('id_group') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('password') ? ' has-error' : '' }}">
						<label for="password">Contraseña</label>
						<input id="password" type="password" name="password" placeholder="*********">
						@if ($errors->has('password'))
							<span class="valida-msg">
								<strong>{{ $errors->first('password') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form">
						<label for="password-confirm">Confirmar contraseña</label>
						<input id="password-confirm" type="password" name="password_confirmation" placeholder="*********">
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Registrar" class="btn">
					</div>

				</form>
			</section>
		</section>

	</main>

@endsection