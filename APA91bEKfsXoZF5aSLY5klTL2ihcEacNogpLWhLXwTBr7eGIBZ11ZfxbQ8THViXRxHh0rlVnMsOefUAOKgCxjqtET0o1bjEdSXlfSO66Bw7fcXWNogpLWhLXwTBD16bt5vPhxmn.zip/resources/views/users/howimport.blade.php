@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Estructura del archivo de importación de usuarios</span></h1>
			<h2>1 - Estructura</h2>
			<div class="editado">
				<p>La estructura del archivo debe llevar 4 columnas (Nombre, Correo, Contraseña, Grupo)</p>	
				<p>En la columna "Grupo" debe ir el identificador del grupo, el cual lo puede consultar dando <a href="{{route('groups')}}">click aquí</a></p>
				<p>En caso de no tener habilitada esta funcion o te encuentres con el mensaje "Url no encontrada" entonces: en el archivo la columna "Grupo" debe de ir siempre el valor de "1"</p>
				<p>La siguiente imagen se ve un ejemplo claro del archivo: </p>
			</div>
			<div class="container-imagen-estructura">
				<img src="{{asset('images/estructura-csv.PNG')}}">
			</div>
			<h2>2 - Guardar archivo</h2>
			<div class="editado">
				<p>Una vez ya tengas tu archivo con la información de los usuarios y el grupo, procederemos a guardar el archivo como CSV (archivo separado por comas)</p>
				<p>Ve el ejemplo en la siguiente imagen: </p>
			</div>
			<div class="container-imagen-estructura">
				<img src="{{asset('images/exportar-csv.png')}}">
			</div>
		</section>
	</main>
@endsection