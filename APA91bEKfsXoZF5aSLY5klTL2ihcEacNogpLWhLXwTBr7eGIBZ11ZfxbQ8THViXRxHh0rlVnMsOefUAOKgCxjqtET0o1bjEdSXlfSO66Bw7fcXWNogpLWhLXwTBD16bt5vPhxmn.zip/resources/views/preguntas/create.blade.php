@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Nueva pregunta</span></h1>

			<form action="{{ route('preguntas.store', $id) }}" method="post" style="text-align: center;" accept-charset="utf-8" enctype="multipart/form-data">
				{{ csrf_field() }}
				<section class="form-edit" style="display: inline-block; vertical-align: top; max-width: 400px; width: 95%; margin: 0 20px; text-align: left;">
        			@php $campo = 'pregunta' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Pregunta *</label>
						<textarea name="{{$campo}}" id="{{$campo}}" cols="30" rows="10" placeholder="Pregunta..">{{old($campo)}}</textarea>
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'tiempo' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Tiempo de respuesta ( en segundos ) *</label>
						<input type="number" name="{{$campo}}" id="{{$campo}}" placeholder="0" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'puntos' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Puntos que suma la pregunta *</label>
						<input type="number" name="{{$campo}}" id="{{$campo}}" placeholder="0" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'imagen' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Imagen ( opcional ) ( dimensiones 400 x 300 )</label>
						<input type="file" accept="image/*" name="{{$campo}}" id="{{$campo}}" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>
				</section>
				<section class="form-edit" style="display: inline-block; vertical-align: top; max-width: 400px; width: 95%; margin: 0 20px; text-align: left;">
					@php $campo = 'opcion_a' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Opción A</label>
						<input type="text" name="{{$campo}}" id="{{$campo}}" placeholder="Opción A" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'opcion_b' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Opción B</label>
						<input type="text" name="{{$campo}}" id="{{$campo}}" placeholder="Opción B" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'opcion_c' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Opción C</label>
						<input type="text" name="{{$campo}}" id="{{$campo}}" placeholder="Opción C" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'opcion_d' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Opción D</label>
						<input type="text" name="{{$campo}}" id="{{$campo}}" placeholder="Opción D" value="{{ old($campo) }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'respuesta' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Respuesta corecta *</label>
						<select name="{{$campo}}" id="{{$campo}}">
							<option value="">Seleccionar..</option>
							<option value="A" @if(old($campo) == 'A') selected @endif>Opción A</option>
							<option value="B" @if(old($campo) == 'B') selected @endif>Opción B</option>
							<option value="C" @if(old($campo) == 'C') selected @endif>Opción C</option>
							<option value="D" @if(old($campo) == 'D') selected @endif>Opción D</option>
						</select>
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>
				</section>

				<div class="divider"></div>

				<div class="btn-submit">
					<input type="submit" name="" value="Crear" class="btn">
				</div>
			</form>

		</section>

	</main>

@endsection