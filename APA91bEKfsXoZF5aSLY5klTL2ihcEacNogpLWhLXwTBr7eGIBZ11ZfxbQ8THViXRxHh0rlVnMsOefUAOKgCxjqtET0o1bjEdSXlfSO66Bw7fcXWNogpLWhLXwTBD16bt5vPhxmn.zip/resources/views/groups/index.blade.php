@extends('layouts.app')

@section('minialert') <div class="minialert">Estás editando los resultados de tu grupo</div> @endsection

@section('menu-partidos')
	<ul class="other-view">
		<li>
			<a href="{{ url('partidos') }}" role="button" class="btn {{ $currentMatch == 'personal' ? 'current':'' }}">
				Mis partidos
			</a>
		</li>
		<li>
			<a href="{{ route('group.index') }}" role="button" class="btn {{ $currentMatch == 'grupo' ? 'current':'' }}">
				Mi Grupo
			</a>
		</li>
	</ul>

@endsection

@section('content')

<main class="partidos">

	<article>
		
		@include('partidos.partials.tutorial')

		<h1><span>Partidos - {{ $user->group->name }}</span></h1>
		
		@include('partidos.partials.lista')

		{{-- Ruta para guardar las predicciones de un grupo --}}
		<input type="hidden" value="{{ route('grupo.store') }}" name="urlsave">
	
	</article>

	<aside>
		<section class="data-user">
			<div class="avatar">
				<div>
					<img src="@if(strpos($user->avatar, 'https') === false) {{ asset('/images/avatars') }}/{{ $user->avatar }} @else {{$user->avatar}} @endif" alt="avatar">
				</div>
			</div>
			<div class="los-datos">
				<h3 class="nombre">{{ $user->name }}</h3>
				<div class="dato">
					<p>Puntaje</p>
					<span>{{ $user->puntos }}</span>
				</div>
				<div class="dato">
					<p>Posición</p>
					<span>{{ $user->position }}°</span>
				</div>
				<h4 class="grupo">Grupo: {{ $user->group->name }}</h4>
				<div class="dato">
					<p>Puntaje</p>
					<span class="dato">{{ $user->grupo_puntos }}</span>
				</div>
				<div class="dato">
					<p>Posición</p>
					<span class="dato">{{ $user->grupo_position }}°</span>
				</div>
			</div>
		</section>

		<section class="posiciones">
			<h2>Top 5</h2>
			<p>Puntos</p>
			{{-- Codigo para mostrar las posciones del top 5 --}}
			<a href="{{ url('posiciones') }}" class="link-seccion btn">Tabla completa</a>
		</section>

		<section class="premios">
			<h2>Premios</h2>
			@foreach(config('polla.premios') as $premio)
				<div class="premio">
					<div class="circle-gift">
						<div class="img">
							<img src="{{ asset('/images') }}/{{$premio['img']}}">
						</div>
					</div>
					<div class="gift-info">
						<h3>{{$premio['titulo']}}</h3>
						<p>{{$premio['descripcion']}}</p>
					</div>
				</div>
			@endforeach
		</section>

		<section class="banner">
			Paute aquí
		</section>

	</aside>

</main>

@endsection

@section('scripts')

	<script src="{{ asset('js/partidos.js') }}"></script>
	@if(config('polla.slider'))
		<script src="{{ asset('slick/slick.js') }}"></script>
		<script src="{{ asset('js/slider.js') }}"></script>
	@endif

@endsection
@if(config('polla.slider'))
	@section('styles')
		<link rel="stylesheet" href="{{asset('slick/slick.css')}}">
	@endsection
@endif