@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Lista de grupos</span></h1>
		</section>

		
		<section class="form-search">
			<form action="{{route('groups')}}" method="get" accept-charset="utf-8">
				<input type="text" name="buscar" value="{{$buscar}}" placeholder="Buscar..">
				<button type="submit" name="" value="" class="btn-buscar icon-search2"></button>
			</form>
		</section>
		

		<article>
			
			<section class="posiciones">
				@if (config('polla.groups'))
					<h3 class="icon icon-user-group">Grupos</h3>
				@endif
				<p>Puntos</p>
				@foreach ($grupos as $group)
					<div class="position @if ($group->position == 1) primero 
						@elseif($group->position == 2) segundo @elseif($group->position == 3) tercero @endif">
						<div class="circle">
							<span class="pos-grupo">{{ $group->position }}</span>
						</div>
						<div class="pos-info">
							<span class="puntos">{{ $group->points }}</span>
							<span class="nombre-tabla">
								{{ $group->name }} - <div class="grupo">Identificador: {{ $group->id }}</div>
							</span>
						</div>
					</div>
				@endforeach
			</section>
		</article>

	</main>
@endsection