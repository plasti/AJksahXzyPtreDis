@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Nueva trivia</span></h1>

			<section class="form-edit">
				<form action="{{ route('trivias.store') }}" method="post">
					{{ csrf_field() }}

					<div class="fila-form{{ $errors->has('titulo') ? ' has-error' : '' }}">
						<label for="titulo">Título de la trivia</label>
						<input type="text" name="titulo" id="titulo" placeholder="Título.." value="{{ old('titulo') }}">
						@if ($errors->has('titulo'))
							<span class="valida-msg">
								<strong>{{ $errors->first('titulo') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('objetivo') ? ' has-error' : '' }}">
						<label for="objetivo">Objetivo de la trivia <small>(esto será visible para los participantes)</small></label>
						<textarea name="objetivo" id="objetivo" cols="30" rows="10" placeholder="Objetivo..">{{old('objetivo')}}</textarea>
						@if ($errors->has('objetivo'))
							<span class="valida-msg">
								<strong>{{ $errors->first('objetivo') }}</strong>
							</span>
						@endif
					</div>

					{{-- <div class="fila-form{{ $errors->has('estado') ? ' has-error' : '' }}">
						<label for="estado">Estado</label>
						<select name="estado" id="estado">
							<option value="">Seleccionar..</option>
							<option value="Activa" @if(old('estado') == 'Activa') selected @endif>Activa</option>
							<option value="Inactiva" @if(old('estado') == 'Inactiva') selected @endif>Inactiva</option>
						</select>
						@if ($errors->has('estado'))
							<span class="valida-msg">
								<strong>{{ $errors->first('estado') }}</strong>
							</span>
						@endif
					</div> --}}

					<div class="btn-submit">
						<input type="submit" name="" value="Crear" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection