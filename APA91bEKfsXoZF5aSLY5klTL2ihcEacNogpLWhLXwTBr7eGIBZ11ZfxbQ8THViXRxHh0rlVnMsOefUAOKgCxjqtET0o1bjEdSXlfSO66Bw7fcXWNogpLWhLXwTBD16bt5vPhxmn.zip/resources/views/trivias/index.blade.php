@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Lista de trivias</span></h1>
		</section>
		<section class="form-search">
			<a href="{{route('trivias.create')}}" class="btn" style="float: right; margin-left: 15px;">Crear nueva trivia</a>
		</section>
		<section class="posiciones" style="width: 95%;">
			@if($trivias->count() > 0)
			<p>Acción</p>
				@foreach ($trivias as $trivia)
					<div class="position">
						<div class="pos-info" style="padding-bottom: 20px; margin-left: 0;">
							<span class="puntos" style="margin-left: 50px;">
								<a href="{{route('trivias.edit', $trivia->id)}}" class="btn">Editar</a>
							</span>
							<span class="puntos" 
								style="margin-left: 50px; 
								padding: 2px 10px;
								border-radius: 5px;
								background-color: {{($trivia->estado == 'Activa') ? '#009d51' : '#e41c24'}}"
							>{{$trivia->estado}}</span>
							<span class="puntos">Preguntas: {{$trivia->preguntas->count()}}</span>
							<span class="nombre-tabla">
								<a href="{{route('trivias.edit', $trivia->id)}}" class="jugador">{{ $trivia->titulo }}</a>
							</span>
						</div>
					</div>
				@endforeach
				{{ $trivias->links() }}
			@else
				<h3 class="icon">No hay trivias disponibles.</h3>
			@endif
		</section>
	</main>
@endsection