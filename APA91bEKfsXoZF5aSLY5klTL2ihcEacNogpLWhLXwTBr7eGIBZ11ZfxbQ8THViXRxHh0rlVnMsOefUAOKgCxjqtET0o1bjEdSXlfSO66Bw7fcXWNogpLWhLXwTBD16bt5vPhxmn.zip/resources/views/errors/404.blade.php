@extends('layouts.app')

@section('content')
	<main>

		<section class="text-center">
			<h1>Oops!</h1>
			<h2>La página que buscas no existe</h2>
		</section>
		
	</main>
@endsection