@extends('layouts.app')

@section('content')


	<main>

		<section>
			<h1><span>Importar codigos</span></h1>

			<section class="form-edit">
				<form action="{{ route('codes.admin.import.file') }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}

					<div class="fila-form{{ $errors->has('file') ? ' has-error' : '' }}">
						<label for="file">En el siguiente enlace tendrá un ejemplo de la estructura del archivo que se debe importar.</label>
						<a href="{{route('codes.admin.howimport')}}" target="_blank">Click aqui</a><br>
						<div class="divider"></div>
						<label for="file">Selecciona un archivo ( Solo con extención .CSV )</label>
						<input type="file" name="file" id="file" accept="*,.csv">
						@if ($errors->has('file'))
							<span class="valida-msg">
								<strong>{{ $errors->first('file') }}</strong>
							</span>
						@endif
						<div class="divider"></div>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Importar" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection

