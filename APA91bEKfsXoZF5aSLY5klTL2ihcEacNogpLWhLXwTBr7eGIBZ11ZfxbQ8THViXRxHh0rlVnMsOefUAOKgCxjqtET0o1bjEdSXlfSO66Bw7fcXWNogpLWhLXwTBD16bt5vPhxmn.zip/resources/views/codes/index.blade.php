@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Códigos</span></h1>
		</section>

		<section class="form-code">
			<form action="{{ url('codes') }}" method="POST">
				{{ csrf_field() }}
				<h3>Si tienes un código de la polla, regístralo aquí</h3>
				<div class="fila-form{{ $errors->has('code') ? ' has-error' : '' }}">
					<input id="code" type="text" name="code" value="{{ old('code') }}" required autofocus placeholder="######">
					
				</div>

				<div class="btn-submit">
					<input type="submit" name="" value="Registrar código" class="btn">
				</div>
			</form>
			@if ($errors->has('code'))
				<span class="valida-msg">
					<strong>{{ $errors->first('code') }}</strong>
				</span>
			@endif
		</section>

		<table class="codes-list">
			<caption>
				<h4>Códigos registrados: {{count($codes)}}</h4>
				<h4>Puntos acumulados: {{ count($codes) * config('polla.code_points') }}</h4>
			</caption>
			<thead>
				<tr>
					<th>Código</th>
					<th>Fecha de registro</th>
					<th>Puntos ganados</th>
				</tr>
			</thead>
			<tbody>
				@foreach ($codes as $code)
					<tr>
						<td>{{ $code->code->used_code }}</td>
						<td>{{ \Carbon\Carbon::parse($code->created_at)->format('d/m/Y H:i')}}</td>
						<td>{{ config('polla.code_points') }}</td>
					</tr>
				@endforeach
			</tbody>
		</table>
		
	</main>
@endsection