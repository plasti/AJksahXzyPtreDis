@extends('layouts.app')

@section('content')
<main>
	
	<section>

		<h1>¡Hola!</h1>
		<section class="acceso">
			
			<div class="btn-ingreso">
				<button type="button" class="btn btn-sesion">Inicia sesión</button>
				@if (config('polla.register'))
					<button type="button" class="btn btn-register">Regístrate</button>
				@endif
			</div>

			<div class="form-login {{ old('email') ? ' open' : '' }}">
				<div class="head-login">Acceder</div>
				<form action="{{ route('login') }}" method="POST" accept-charset="utf-8">
					{{ csrf_field() }}

					<div class="fila-form{{ $errors->has('email') ? ' has-error' : '' }}">
						<label for="email">E-mail</label>
						<input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus placeholder="ejemplo@correo.com">
						@if ($errors->has('email'))
							<span class="valida-msg">
								<strong>{{ $errors->first('email') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('password') ? ' has-error' : '' }}">
						<label for="password">Contraseña</label>
						<input type="password" name="password" id="password" placeholder="*******" required>
						@if ($errors->has('password'))
							<span class="valida-msg">
								<strong>{{ $errors->first('password') }}</strong>
							</span>
						@endif
					</div>


					@if(config('polla.login_redes'))
						<div class="fila-form">
							<a href="register/google" class="btn-redes-login google">Continuar con Google</a>
							<a href="register/facebook" class="btn-redes-login facebook">Continuar con Facebook</a>
						</div>
					@endif


					<div class="remember">
						<input type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
						<label for="remember">Recordarme</label>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Ingresar" class="btn">
					</div>

				</form>

				<div class="after-form-login">
					<p><a href="{{ route('password.request') }}">¿Olvidaste tu contraseña?</a></p>
					<p>¿No estás registrado? <a href="#" class="btn-register">Regístrate aquí</a></p>
				</div>

			</div> {{-- /form-login --}}

			<div class="form-register {{ old('name') ? ' open' : '' }}">
				<div class="head-login">Registrarse</div>					
				<form action="{{ route('register') }}" method="POST" accept-charset="utf-8">
					{{ csrf_field() }}

					
					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre</label>
						<input id="name" type="text" placeholder="Nombre" name="name" value="{{ old('name') }}" required>
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('email-reg') ? ' has-error' : '' }}">
						<label for="email-reg">E-mail</label>
						<input name="email-reg" id="email-reg" type="email" placeholder="ejemplo@correo.com" value="{{ old('email-reg') }}" required>
						@if ($errors->has('email-reg'))
							<span class="valida-msg">
								<strong>{{ $errors->first('email-reg') }}</strong>
							</span>
						@endif
					</div>
					
					<div class="fila-form{{ $errors->has('password-reg') ? ' has-error' : '' }}">
						<label for="password-reg">Contraseña</label>
						<input id="password-reg" type="password" name="password-reg" placeholder="********" required>
						@if ($errors->has('password-reg'))
							<span class="valida-msg">
								<strong>{{ $errors->first('password-reg') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form">
						<label for="password-confirm">Confirmar contraseña</label>
						<input id="password-confirm" type="password" name="password-reg_confirmation" placeholder="********" required>
					</div>

					@if(config('polla.login_redes'))
						<div class="fila-form">
							<a href="register/google" class="btn-redes-login google">Continuar con Google</a>
							<a href="register/facebook" class="btn-redes-login facebook">Continuar con Facebook</a>
						</div>
					@endif

					@if (config('polla.code_reg'))
						<div class="fila-form{{ $errors->has('code') ? ' has-error' : '' }}">
							<label for="code">Código</label>
							<input type="text" id="code" name="code" value="{{ old('code') }}" required>
							@if ($errors->has('code'))
								<span class="valida-msg">
									<strong>{{ $errors->first('code') }}</strong>
								</span>
							@endif
						</div>
					@endif
					@if(!(config('polla.debug')))
						@captcha
					@endif

					<div class="{{ $errors->has('g-recaptcha-response') ? ' has-error' : '' }}">
						@if ($errors->has('g-recaptcha-response'))
							<span class="valida-msg">
								<strong>{{ $errors->first('g-recaptcha-response') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('terms') ? ' has-error' : '' }}">
						<label for="terms">
							<input type="checkbox" name="terms" id="terms" {{ old('terms') ? 'checked' : '' }}>
							<span>Acepto los <a href="#" class="a-cond">términos y condiciones</a> y las <a href="#" class="a-poli">políticas de privacidad</a></span>
						</label>
						
						@if ($errors->has('terms'))
							<span class="valida-msg">
								<strong>{{ $errors->first('terms') }}</strong>
							</span>
						@endif
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Regístrate" class="btn">
					</div>
				</form>
			</div> {{-- /form-register --}}

			<div class="login-note">
				Si tienes incovenientes con el sistema puedes comunicarte al correo <a href="mailto:joe@example.com?subject=feedback">soporte@lapollamundial.com</a>
			</div>

			@include('layouts.partials.terminos')
			@include('layouts.partials.politicas')

		</section>
	</section>
</main>

@endsection

@section('scripts')
	<script src="{{ asset('js/login.js') }}"></script>
@endsection
