@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Instrucciones</span></h1>
			<h2>Cómo jugar</h2>
			<div class="editado">
				<iframe style="width: 100%; min-height: 500px;" src="https://www.youtube.com/embed/dweprOPWYw4" title="Cómo jugar" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</section>
		
	</main>
@endsection