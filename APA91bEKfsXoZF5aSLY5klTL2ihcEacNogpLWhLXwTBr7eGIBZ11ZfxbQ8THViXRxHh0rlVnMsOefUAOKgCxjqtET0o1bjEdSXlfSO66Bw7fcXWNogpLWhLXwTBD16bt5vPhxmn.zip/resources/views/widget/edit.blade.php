@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Configuración de widget</span></h1>

			<section class="form-edit">
				<form action="{{ route('widget.update') }}" method="post">
					{{ csrf_field() }}

					@php $campo = 'titulo' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Titulo del widget</label>
						<input type="text" name="{{$campo}}" id="{{$campo}}" placeholder="Titulo.." value="{{ $widget->$campo }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'wpp' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Numero de Whatsapp</label>
						<input type="number" name="{{$campo}}" id="{{$campo}}" placeholder="000 000 00 00" value="{{ $widget->$campo }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>


					@php $campo = 'tel' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Numero de teléfono</label>
						<input type="number" name="{{$campo}}" id="{{$campo}}" placeholder="000 000 00 00" value="{{ $widget->$campo }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'color' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Color de fondo del widget</label>
						<input type="color" name="{{$campo}}" id="{{$campo}}" value="{{ $widget->$campo }}">
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					@php $campo = 'estado' @endphp
					<div class="fila-form{{ $errors->has($campo) ? ' has-error' : '' }}">
						<label for="{{$campo}}">Estado del widget</label>
						<select name="{{$campo}}" id="{{$campo}}">
							<option value="Activo" @if($widget->$campo == 'Activo') selected @endif>Activo</option>
							<option value="Inactivo" @if($widget->$campo == 'Inactivo') selected @endif>Inactivo</option>
						</select>
						@if ($errors->has($campo))
							<span class="valida-msg">
								<strong>{{ $errors->first($campo) }}</strong>
							</span>
						@endif
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection