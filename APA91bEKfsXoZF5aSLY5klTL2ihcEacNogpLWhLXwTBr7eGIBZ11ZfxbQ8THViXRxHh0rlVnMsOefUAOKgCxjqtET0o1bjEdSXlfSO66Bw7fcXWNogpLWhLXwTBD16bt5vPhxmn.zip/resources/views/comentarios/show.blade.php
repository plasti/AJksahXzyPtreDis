@extends('layouts.app')

@section('content')
	<main>

		<div class="comentarios">
			
			<h2>Comentarios</h2>
			<div class="banner-partido">
				<div class="fecha-partido">{{date_format(date_create($match->date_time), 'd/m/Y H:i')}} HS</div>
				<div class="detalles-partido-comentario">
					<div class="equipo-comentario">
						<img src="{{ asset('/images/flags') }}/{{ $match->team_a->flag }}" alt="Bandera {{ $match->team_a->country }}">
						<span>{{$match->team_a->country}}</span>
						<span class="resultado-comentario">{{($match->team_a->score_a != null) ? $match->team_a->score_a : '--'}}</span>
					</div>
					<strong class="vs">VS</strong>
					<div class="equipo-comentario">
						<img src="{{ asset('/images/flags') }}/{{ $match->team_b->flag }}" alt="Bandera {{ $match->team_b->country }}">
						<span>{{$match->team_b->country}}</span>
						<span class="resultado-comentario">{{($match->team_b->score_b != null) ? $match->team_b->score_b : '--'}}</span>
					</div>
				</div>
			</div>
			<div class="body-comentarios">
				
				<div class="form-comentario">
					<textarea name="comentario" id="comentario" placeholder="Comentar.."></textarea>	
					<a href="#" url="{{route('comentarios.store', $match->id)}}" class="comentar-btn">Comentar ></i></a>
				</div>

				<div id="comentarios-all">
					@if($match->comentarios->count() > 0)
						@foreach($match->comentarios as $comentario)
							<div class="comentario" id="comentario_app_{{$comentario->id}}">
								@if($comentario->id_user == Auth::user()->id)
									<span class="eliminar-comentario" title="Eliminar comentario" item="{{route('comentarios.delete', $comentario->id)}}">x</span>
								@endif
								<div class="header-comentario">
									<div class="cintainer-avatar">
										<img src="{{$comentario->user->avatar()}}" alt="avatar">
									</div>
									<strong>{{$comentario->user->name}}</strong>
								</div>
								<div class="text">{{$comentario->text}}</div>
								<span class="fecha">{{date_format(date_create($comentario->created_at), 'd/m/Y H:i')}} HS</span>
							</div>
						@endforeach
					@else
						<span class="nothing" style="font-size: 1.5rem; color: {{config('polla.primario')}}">No hay comentarios, sé el primero en comentar algo sobre este partido.</span>
					@endif

				</div>
			</div>
		</div>
	</main>
@endsection
@section('scripts')
	<script src="{{ asset('js/comentarios.js') }}"></script>
@endsection