@extends('layouts.app')

@section('content')
	<main>
		<section>
			<h1>App mobile</h1>
			<div class="editado">
				<p>1) Descarga la aplicación, puedes encontrarla en Play store y App store</p>
				@if(App\Code_app::find(1) != null)
					<p>2) Escanea el siguiente codigo QR o ingresa este codigo: {{App\Code_app::find(1)->code}}</p>
				@else
					<p>2) Escanea el siguiente codigo QR</p>
				@endif
				<p>3) ¡A jugar!</p>
			</div>
			<div class="btn-stores">
				<a href="#">
					<img src="{{asset('images/googleplay.png')}}">
					Play store
				</a>
				<a href="#">
					<img src="{{asset('images/apple.png')}}">
					App store
				</a>
			</div>
			<div class="qr-img">
				@php
					$objet = [
						'name' => config('polla.name'),
						'generated' => "polla",
						'primary' => config('polla.primario'),
						'secondary' => config('polla.secundario'),
						'tertiary' => config('polla.terciario'),
						'background' => asset('images/campo768.jpg'),
						'logo' => asset('images/logo.png'),
						'host' => $_SERVER['SERVER_NAME'],
						'register' => config('polla.register'),
						'login_redes' => config('polla.login_redes'),
						'grupos' => config('polla.groups'),
						'trivia' => config('polla.trivia'),
						'url_tutorial_app' => config('polla.url_tutorial_app'),
						'url_soporte' => config('polla.url_soporte'),
					];
				@endphp
				{!! QrCode::size(400)->backgroundColor(0,0,0,0)->color(255,255,255)->generate(json_encode($objet)); !!}
			</div>
		</section>
	</main>
@endsection