<table>
    <thead>
    <tr>
        <th><strong>Nombre</strong></th>
        <th><strong>Correo</strong></th>
        <th><strong>Puntos</strong></th>
        <th><strong>Posición</strong></th>
        @if(config('polla.groups'))
            <th><strong>Grupo</strong></th>
            <th><strong>Puntos grupo</strong></th>
            <th><strong>Posición grupo</strong></th>
        @endif
    </tr>
    </thead>
    <tbody>
    @foreach($users as $user)
        <tr>
            <td>{{ $user->name }}</td>
            <td>{{ $user->email }}</td>
            <td>{{ $user->points }}</td>
            <td>{{ $user->position }}</td>
            @if(config('polla.groups'))
                <td>{{ $user->group->name }}</td>
                <td>{{ $user->group->points }}</td>
                <td>{{ $user->group->position }}</td>
            @endif
        </tr>
    @endforeach
    </tbody>
</table>