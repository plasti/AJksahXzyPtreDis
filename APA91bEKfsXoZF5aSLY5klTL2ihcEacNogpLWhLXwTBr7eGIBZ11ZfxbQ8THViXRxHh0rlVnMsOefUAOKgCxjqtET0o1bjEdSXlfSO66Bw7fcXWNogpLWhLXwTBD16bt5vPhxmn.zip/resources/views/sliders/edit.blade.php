@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Editar slider</span></h1>

			<section class="form-edit">
				<form action="{{ route('sliders.update', $slider->id) }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}

					<div class="fila-form">
						<img src="{{$slider->img()}}">
					</div>

					<div class="fila-form{{ $errors->has('img') ? ' has-error' : '' }}">
						<label for="img">Reemplazar Imagen ( Dimensiones 900 x 300 )</label>
						<input type="file" name="img" id="img">
						@if ($errors->has('img'))
							<span class="valida-msg">
								<strong>{{ $errors->first('img') }}</strong>
							</span>
						@endif
						@if ($error_extension)
							<span class="valida-msg">
								<strong>Solo se aceptan imágenes .jpg o .png</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre</label>
						<input type="text" name="name" id="name" value="{{ $slider->name }}">
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('link') ? ' has-error' : '' }}">
						<label for="link">Enlace (opcional)</label>
						<input type="text" name="link" placeholder="https://" id="link" value="{{ $slider->link }}">
						@if ($errors->has('link'))
							<span class="valida-msg">
								<strong>{{ $errors->first('link') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('status') ? ' has-error' : '' }}">
						<label for="status">Estado</label>
						<select name="status" id="status">
							<option value="">Seleccionar..</option>
							<option @if($slider->status == 'Si') selected @endif value="Si">Activo</option>
							<option @if($slider->status == 'No') selected @endif value="No">Inactivo</option>
						</select>
						@if ($errors->has('status'))
							<span class="valida-msg">
								<strong>{{ $errors->first('status') }}</strong>
							</span>
						@endif
					</div>

					<div class="btn-submit">
						<a class="btn" href="{{route('sliders.delete', $slider->id)}}" id="eliminar-algo">Eliminar Slider</a>
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection