@extends('layouts.app')

@section('content')
	<main>
		<div class="bar-btns">
			<a href="{{route('sliders.create')}}" class="btn">Nuevo slider</a>
		</div>
		@foreach($sliders as $slider)
			<a href="{{route('sliders.edit', $slider->id)}}" class="slider-index @if($slider->status == 'No') diseable @endif">
				<img src="{{$slider->img()}}">
				<span>{{$slider->name}}</span>
			</a>
		@endforeach
		{{$sliders->links()}}
	</main>
@endsection