@extends('layouts.app')

@section('content')
	<main>

		<div class="comentarios">
			
			<h2>Notificaciones</h2>
			<div class="body-comentarios">
				<div id="comentarios-all">
					@if($notificaciones->count() > 0)
						@foreach($notificaciones as $notificacion)
							<a href="{{$notificacion->link}}" class="comentario">
								<div class="header-comentario">
									<div class="cintainer-avatar" style="background-color: {{config('polla.primario')}}">
										<img style="display: block; width: 36px; height: 36px;" src="{{$notificacion->icono()}}" alt="avatar">
									</div>
									<strong>{{$notificacion->titulo}}</strong>
								</div>
								<div class="text">{{$notificacion->descripcion}}</div>
								<span class="fecha">{{App\Plastimedia::parse_fecha($notificacion->created_at)}} HS</span>
							</a>
						@endforeach
						{{$notificaciones->links()}}
					@else
						<span class="nothing" style="font-size: 1.5rem; color: {{config('polla.primario')}}">No tienes notificaciones aún.</span>
					@endif

				</div>
			</div>
		</div>
	</main>
@endsection