<header>
	<div class="ancho">
		
		@yield('minialert')

		<div class="menu-sec">
			<input type="checkbox" id="menu-check" />
			<label for="menu-check" class="label-menu">
				<div class="btn-menu" role="button"> 
					<div class="stick1"></div><div class="stick2"></div><div class="stick3"></div>
				</div>
				<ul>
					@if (Auth::guest())
						<li><a href="{{ url('login') }}">Iniciar sesión</a></li>
					@endif
					<li><a href="{{ url('instrucciones') }}">Instrucciones</a></li>
					<li><a href=" {{ url('plan-premios') }} ">Plan de premios</a></li>
					<li><a href=" {{ url('la-polla') }} ">Sobre la polla</a></li>
					@if(config('polla.app_mobile'))
						<li><a href="{{url('app/mobile')}}">Aplicación mobile</a></li>
					@endif
					@if (!Auth::guest())
						<li><a href=" {{ url('configuracion') }} ">Configurar perfil</a></li>
						@if(Auth::user()->role == 'admin')
							@if(config('polla.medals'))
								<li class="item-admin"><a href="{{route('medals')}}">Configurar premios</a></li>
							@endif
							@if(config('polla.users_admin'))
								<li class="item-admin"><a href=" {{ url('users') }} ">Configurar usuarios</a></li>
							@endif
							@if(config('polla.groups'))
								<li class="item-admin"><a href=" {{ url('groups') }} ">Grupos</a></li>
							@endif
							@if(config('polla.code_section'))
								<li class="item-admin"><a href=" {{ route('codes.admin') }} ">Configurar códigos</a></li>
							@endif
							@if(config('polla.slider'))
								<li class="item-admin"><a href=" {{ url('sliders') }} ">Configurar sliders</a></li>
							@endif
							@if(config('polla.trivia'))
								<li class="item-admin"><a href="{{route('trivias')}}">Configurar trivia</a></li>
							@endif
							@if(config('polla.widget'))
								<li class="item-admin"><a href="{{route('widget.edit')}}">Configurar widget</a></li>
							@endif
						@endif
					@endif
					@if (!Auth::guest())
						<li>
							<a href="{{ route('logout') }}"
								onclick="event.preventDefault();
								document.getElementById('logout-form').submit();">
								Salir
							</a>

							<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
								{{ csrf_field() }}
							</form>
						</li>
					@endif
				</ul>
			</label>
		</div> 
		{{-- notificaciones --}}
		@auth
			<a href="{{route('notificaciones')}}" class="notificaciones" id="icono_notificacion_header">
				<img src="{{asset('images/bell.png')}}">
				<span style="display: {{(App\Plastimedia::check_notificaciones(Auth::user()->id)) ? 'block' : 'none'}}" class="bola" id="bola_notificacion"></span>
			</a>
			<div class="notificacion-fixed">
            	<a href="#" class="cerrar-notificacion">x</a>
            	<div class="banner-notificacion">
            		<div class="container-img">
            			<img id="icono_notificacion" src="">
            		</div>
            	</div>
            	<div class="body-notificacion">
            		<h3 id="title_notificacion">---</h3>
            		<p id="content_notificacion">---</p>
	            	<div class="footer">
	            		<a href="#" id="boton_notificacion">Ver más</a>
	            	</div>
            	</div>
        	</div>
		@endif

		{{-- /menu-sec --}}

		<div class="logo {{ (Auth::guest())?'no-menu':'' }}">
			<a href="{{ url('partidos') }}">
				<img src="{{ asset('images/logo.png') }}" alt="Logo la polla mundial">
			</a>
		</div>

		@if (!Auth::guest())
			
			<div class="menu-ppl">
				
				@yield('menu-partidos')

				<nav>
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="{{ url('partidos') }}" class="icon-soccer-ball @isset ($current) {{ $current == 'partidos' ? 'current':'' }} @endisset">
								Partidos
							</a>
						</li>
						<li>
							<a href="{{ url('posiciones') }}" class="icon-trophy @isset ($current) {{ $current == 'posiciones' ? 'current':'' }} @endisset">
								Posiciones
							</a>
						</li>
						@if (config('polla.code_section'))
							<li>
								<a href="{{ url('codes') }}" class="icon-barcode @isset ($current) {{ $current == 'codes' ? 'current':'' }} @endisset">
									Códigos
								</a>
							</li>
						@endif
						<li>
							<a href="{{ url('perfil') }}" class="icon-user @isset ($current) {{ $current == 'perfil' ? 'current':'' }} @endisset">
								Perfil
							</a>
						</li>
					</ul>
				</nav>
			</div>

		@endif

	</div> {{-- /ancho --}}
</header> {{-- /header --}}

{{-- Alerta de acciones --}}
@if (session('status'))
	<div class="alert {{ session('class') }}" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="icon-cerrar"></i></button>
		{{ session('status') }}
	</div>
@endif
{{-- @if (count($errors) > 0)
	<div class="alert" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="icon-cerrar"></i></button>
		<ul>
			@foreach ($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>
	</div>
@endif --}}
