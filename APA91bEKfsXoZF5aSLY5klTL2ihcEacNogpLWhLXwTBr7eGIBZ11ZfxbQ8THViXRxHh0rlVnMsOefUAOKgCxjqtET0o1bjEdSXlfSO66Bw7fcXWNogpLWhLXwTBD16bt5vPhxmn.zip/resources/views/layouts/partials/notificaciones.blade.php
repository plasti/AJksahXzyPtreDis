 @auth
    @php
        $n = env('CHANNEL_PUSHER');
        $id_event = env('PUSHER_APP_ID_EVENT_'.$n);
    @endphp
    <script src="{{asset('js/notificaciones.js')}}"></script>
    <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
    <script>
        var pusher = new Pusher('{{$id_event}}', {cluster: 'us2'});
        var channel = pusher.subscribe('NotificacionesCanal');
        channel.bind('NotificacionesEvento', function(data) {
            Notificacion(data, '{{Auth::user()->id}}');
        });
    </script>
@endif