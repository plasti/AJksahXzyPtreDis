<section class="popup condiciones">
	<span class="close-panel">x</span>
	<h3>Términos y condiciones</h3>
	<div class="in-pop">
		{{-- terminos y condiciones a qui --}}
	</div>
</section>

