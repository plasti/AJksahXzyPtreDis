@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Sobre la Polla</span></h1>
			<h2>¿Qué es?</h2>
			{{-- <div class="editado">
				
			</div> --}}
			<h2>Términos y condiciones</h2>
			{{-- <div class="editado">
				
			</div> --}}
			<h2>Políticas de privacidad</h2>
			{{-- <div class="editado">
				
			</div> --}}
		</section>
		
	</main>
@endsection