@extends('layouts.app')

@if (config('polla.groups'))
	@section('menu-partidos')
		<ul class="other-view">
			<li>
				<a href="{{ url('partidos') }}" role="button" class="btn {{ $currentMatch == 'personal' ? 'current':'' }}">
					Mis partidos
				</a>
			</li>
			<li>
				<a href="{{ route('group.index') }}" role="button" class="btn {{ $currentMatch == 'grupo' ? 'current':'' }}">
					Mi Grupo
				</a>
			</li>
		</ul>
	@endsection
@endif

@section('content')

<main class="partidos">
	<article>
		@if(config('polla.widget'))
			@include('partidos.partials.widget')
		@endif
		@if(config('polla.trivia'))
			@include('partidos.partials.trivia')
		@endif

		@include('partidos.partials.tutorial')
		<h1><span>Partidos</span></h1>
		@include('partidos.partials.lista')
		{{-- Ruta para guardar las predicciones de un usuario --}}
		<input type="hidden" value="{{ route('prediction.store') }}" name="urlsave">
	</article>

	<aside>

		<section class="data-user">
			<div class="avatar">
				<div>
					<img src="@if(strpos($user->avatar, 'https') === false) {{ asset('/images/avatars') }}/{{ $user->avatar }} @else {{$user->avatar}} @endif" alt="avatar">
				</div>
			</div>
			<div class="los-datos">
				<h3 class="nombre">{{ $user->name }}</h3>
				<div class="dato">
					<p>Puntaje</p>
					<span>{{ $user->points }}</span>
				</div>
				<div class="dato">
					<p>Posición</p>
					<span>{{ $user->position }}°</span>
				</div>
				
				@if (config('polla.groups'))
					<h4 class="grupo">Grupo: {{ $user->group->name }}</h4>
					<div class="dato">
						<p>Puntaje</p>
						<span class="dato">{{ $user->group->points }}</span>
					</div>
					<div class="dato">
						<p>Posición</p>
						<span class="dato">{{ $user->group->position }}°</span>
					</div>
				@endif

			</div>
		</section>

		<section class="posiciones">
			<h2>Top 5</h2>
			<p>Puntos</p>
			@foreach ($top5 as $user)
				<div class="position @if ($user->position == 1) primero 
								@elseif($user->position == 2) segundo @elseif($user->position == 3) tercero @endif">
					<div class="circle">
						<div class="img"><img src="@if(strpos($user->avatar, 'https') === false) {{ asset('/images/avatars') }}/{{ $user->avatar }} @else {{$user->avatar}} @endif" alt="avatar"></div>
						<span class="in-circle">{{ $user->position }}</span>
					</div>
					<div class="pos-info">
						<span class="puntos">{{ $user->points }}</span>
						<span class="nombre-tabla">{{ $user->name }}</span>
					</div>
				</div>
			@endforeach
				
			<a href="{{ url('posiciones') }}" class="link-seccion btn">Tabla completa</a>
		</section>

		<section class="premios text-center">
			<h2>Premios</h2>
			@foreach(config('polla.premios') as $premio)
				<div class="premio">
					<div class="circle-gift">
						<div class="img">
							<img src="{{ asset('/images') }}/{{$premio['img']}}">
						</div>
					</div>
					<div class="gift-info">
						<h3>{{$premio['titulo']}}</h3>
						<p>{{$premio['descripcion']}}</p>
					</div>
				</div>
			@endforeach
			<a href="{{ url('plan-premios') }}" class="link-seccion btn">Ver más</a>
		</section> {{-- /premios --}}
		
		<section class="banner">
			{{-- <img src="{{asset('images/logo.png')}}" alt=""> --}}
			Paute aquí
		</section>

	</aside>

</main>
@endsection

@section('scripts')

	<script src="{{ asset('js/partidos.js') }}"></script>
	@if(config('polla.slider'))
		<script src="{{ asset('slick/slick.js') }}"></script>
		<script src="{{ asset('js/slider.js') }}"></script>
	@endif

@endsection
@if(config('polla.slider'))
	@section('styles')
		<link rel="stylesheet" href="{{asset('slick/slick.css')}}">
	@endsection
@endif