@extends('layouts.app')

@section('content')

<main>

	<div class="loader"></div>

	<section>
		
		<h1><span>Importar marcador</span></h1>
		
	</section>

	<section class="respuestas">
		<ul class="ul-respuesta">
			<li>Marcador importado</li>
		</ul>
	</section>

	{{ csrf_field() }}
	<input type="hidden" value="{{ url('user-predictions') }}" class="urlPredUser">
	<input type="hidden" value="{{ url('user-points') }}" class="urlPointsUser">
	<input type="hidden" value="{{ url('user-positions') }}" class="urlPositionUser">
	<input type="hidden" value="{{ config('polla.groups') ? url('group-predictions') : '' }}" class="urlPredGroup">
	<input type="hidden" value="{{ config('polla.groups') ? url('group-points') : '' }}" class="urlPointsGroup">
	<input type="hidden" value="{{ config('polla.groups') ? url('group-positions') : '' }}" class="urlPositionGroup">
	<input type="hidden" value="{{ url('match/update') }}" class="urlMatchUpdate">

</main>

@endsection

@section('scripts')

	<script src="{{ asset('js/import.js') }}"></script>

@endsection