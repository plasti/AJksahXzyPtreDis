@if($trivia != null)
	<div class="trivia-letrero">
		<h2>{{$trivia->titulo}}</h2>
		<div class="spanes">
			<span>Pueder ganar hasta {{$trivia->getPuntos()}} puntos</span>
			<span>En total son {{$trivia->preguntas->count()}} preguntas</span>
		</div>
		<a href="{{route('trivia.comenzar', $trivia->id)}}" class="btn">¡Realizar trivia!</a>
	</div>
@endif