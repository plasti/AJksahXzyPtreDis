@if(config('polla.slider'))
	<div class="banner-big">
		@include('partidos.partials.slider')
	</div>	
@endif
{{-- Recorro por etapa --}}
@foreach ($etapas as $etapa)
	<h2 class="etapa-titulo">{{ $etapa['titulo'] }}</h2>
	
	@php
		$dia = '';
	@endphp
	{{-- Recorro por partido por etapa --}}
	@foreach ($etapa['partidos'] as $partido)
		@if ($dia == '')
			<a class="{{ Carbon\Carbon::parse($partido->date_time)->format('n-j') }}" ></a>
			<section class="dia"> {{-- Abre el primer dia de la etapa --}}
		@endif
		{{-- Muestro el día como título --}}
		@if ($dia != $partido->date )
			@if ($dia != '')
				</section>
				<a class="{{ Carbon\Carbon::parse($partido->date_time)->format('n-j') }}" ></a>
				<section class="dia">
			@endif
			@php
				$dia = $partido->date;
			@endphp
			@if(config('polla.slider'))
				@if ( Carbon\Carbon::parse($partido->date_time)->format('n-j') == Carbon\Carbon::now()->format('n-j') )
					<div class="banner-big">
						@include('partidos.partials.slider')
					</div>
				@endif
			@endif

			<div class="fecha">
				<i class="icon-calendar2"></i>
				{{ $partido->date }}
			</div>
		@endif
		
		{{-- Muestro el partido pero primero verifico si ya está cerrado --}}
		@if ($partido->cerrado) {{-- Partido cerrado --}}
			<div class="partido">
				<div class="time"><i class="icon-clock"></i>{{ $partido->time }} HS</div>
				<div class="datos">
					<div>
						{{-- Equipo 1 --}}
						<div class="team-l">
							<div class="flag">
								<img src="{{ asset('/images/flags') }}/{{ $partido->team_a->flag }}" alt="Bandera {{ $partido->team_a->country }}">
							</div>
							<div class="nombre @if (!is_null($partido->nombres)) {{ $partido->nombres ? 'win':'fail' }} @endif">
								{{ $partido->team_a->country }}
							</div>
						</div>
						{{-- Marcadores --}}
						<div class="marcador cerrado">
							<div class="m-left">
								<input type="text" name="p{{ $partido->id_match }}-t1" min="0" placeholder="-" value="{{ $partido->a_score }}" 
									class="p{{ $partido->id_match }}-t1 @if (!is_null($partido->marcador_a)) {{ $partido->marcador_a ? 'win':'fail' }} @endif" 
									readonly />
							</div>
							<div class="separa-teams">
								<i class="icon-star"></i><i class="icon-star"></i>
							</div>
							<div class="m-right">
								<input type="text" name="p{{ $partido->id_match }}-t2" min="0" placeholder="-" value="{{ $partido->b_score }}" 
									class="p{{ $partido->id_match }}-t2 @if (!is_null($partido->marcador_b)) {{ $partido->marcador_b ? 'win':'fail' }} @endif" 
									readonly />
							</div>
						</div>
						{{-- Equipo 2 --}}
						<div class="team-r">
							<div class="nombre @if (!is_null($partido->nombres)) {{ $partido->nombres ? 'win':'fail' }} @endif">
								{{ $partido->team_b->country }}
							</div>
							<div class="flag">
								<img src="{{ asset('/images/flags') }}/{{ $partido->team_b->flag }}" alt="Bandera {{ $partido->team_b->country }}">
							</div>
						</div>
					</div>
				</div>
				<div class="save-div"></div>
				
				@if ( !is_null($partido->score_a) && !is_null($partido->score_b) )
					<div class="resultado">
						<span>{{ $partido->team_a->country }} {{ $partido->score_a }} : {{ $partido->score_b }} {{ $partido->team_b->country }}</span> 
						@if ($partido->points > 0) <span class="puntos">+ {{ $partido->points }} pts</span> @endif
					</div>
				@endif
				<br>
				<a href="{{route('comentarios', $partido->id_match)}}" class="link-comentarios">Ver comentarios</a>
				<a href="{{route('marcadores', $partido->id_match)}}" class="link-comentarios">Ver marcadores</a>
			</div>
		@else {{-- Partido abierto --}}
			<div class="partido">
				<div class="time"><i class="icon-clock"></i>{{ $partido->time }} HS</div>
				<div class="datos p{{ $partido->id_match }}-t1 p{{ $partido->id_match }}-t2">
					<div>
						{{-- Equipo 1 --}}
						<div class="team-l">
							<div class="flag">
								<img src="{{ asset('/images/flags') }}/{{ $partido->team_a->flag }}" alt="Bandera {{ $partido->team_a->country }}">
							</div>
							<div class="nombre">{{ $partido->team_a->country }}</div>
						</div>
						{{-- Marcadores --}}
						<div class="marcador">
							<div class="m-left">
								<button type="button" class="btn-plus" value="p{{ $partido->id_match }}-t1"><i class="icon-plus"></i></button>
								<input type="text" name="p{{ $partido->id_match }}-t1" class="score p{{ $partido->id_match }}-t1" min="0" placeholder="-" 
									value="{{ $partido->a_score }}" maxlength="1" />
								<button type="button" class="btn-minus" value="p{{ $partido->id_match }}-t1"><i class="icon-minus"></i></button>
							</div>
							<div class="separa-teams"><i class="icon-star"></i><i class="icon-star"></i></div>
							<div class="m-right">
								<button type="button" class="btn-plus" value="p{{ $partido->id_match }}-t2"><i class="icon-plus"></i></button>
								<input type="text" name="p{{ $partido->id_match }}-t2" class="score p{{ $partido->id_match }}-t2" min="0" placeholder="-" 
									value="{{ $partido->b_score }}" maxlength="1" />
								<button type="button" class="btn-minus" value="p{{ $partido->id_match }}-t2"><i class="icon-minus"></i></button>
							</div>
						</div>
						{{-- Equipo 2 --}}
						<div class="team-r">
							<div class="nombre">{{ $partido->team_b->country }}</div>
							<div class="flag">
								<img src="{{ asset('/images/flags') }}/{{ $partido->team_b->flag }}" alt="Bandera {{ $partido->team_b->country }}">
							</div>
						</div>
						<label class="p{{ $partido->id_match }}-t1 p{{ $partido->id_match }}-t2 "></label>
					</div>
				</div> {{-- /datos --}}

				<div class="save-div">
					<button class="save-match p{{ $partido->id_match }}-t1 p{{ $partido->id_match }}-t2" name="p{{ $partido->id_match }}-t1" id="p{{ $partido->id_match }}">
						Guardar
					</button>
				</div>
				<a href="{{route('comentarios', $partido->id_match)}}" class="link-comentarios">Ver comentarios</a>
				
			</div> {{-- /partido --}}
		@endif
	@endforeach

	</section> {{-- Cierra el ultimo dia de la etapa --}}

@endforeach
{{ csrf_field() }}