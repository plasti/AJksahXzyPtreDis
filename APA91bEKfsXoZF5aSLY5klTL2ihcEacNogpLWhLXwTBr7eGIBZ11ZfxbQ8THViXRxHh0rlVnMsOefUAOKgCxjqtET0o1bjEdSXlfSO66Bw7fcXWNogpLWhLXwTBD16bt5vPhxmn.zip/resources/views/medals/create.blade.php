@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Nuevo premio</span></h1>

			<section class="form-edit">
				<form action="{{ route('medals.store') }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}

					<div class="fila-form{{ $errors->has('img') ? ' has-error' : '' }}">
						<label for="img">Subir imagen (300 x 300)</label>
						<input type="file" name="img" id="img">
						@if ($errors->has('img'))
							<span class="valida-msg">
								<strong>{{ $errors->first('avatar') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre del premio</label>
						<input type="text" name="name" id="name" value="{{ old('name') }}">
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('desc') ? ' has-error' : '' }}">
						<label for="desc">Desccripción del premio</label>
						<textarea name="desc" cols="30" rows="10" placeholder="...">{{old('desc')}}</textarea>
						@if ($errors->has('desc'))
							<span class="valida-msg">
								<strong>{{ $errors->first('desc') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('desc') ? ' has-error' : '' }}">
						<label for="match">Partido en el cual aplica el premio</label>
						<select name="id_match" required>
							<option value="">Seleccionar..</option>
							@foreach($matchs as $match)
								<option value="{{$match->id}}">{{$match->team_a->country}} - vs - {{$match->team_b->country}}</option>
							@endforeach
						</select>
						@if ($errors->has('id_match'))
							<span class="valida-msg">
								<strong>{{ $errors->first('id_match') }}</strong>
							</span>
						@endif
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection