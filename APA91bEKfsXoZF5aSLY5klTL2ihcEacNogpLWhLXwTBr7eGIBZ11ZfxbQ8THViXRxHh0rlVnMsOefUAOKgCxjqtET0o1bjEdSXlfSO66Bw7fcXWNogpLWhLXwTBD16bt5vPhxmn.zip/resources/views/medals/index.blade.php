@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Lista de premios</span></h1>
		</section>

		<section class="form-search">
			<a href="{{route('medals.create')}}" class="btn" style="float: right; margin-left: 15px;">Nuevo premio</a>
		</section>	

		<article>
			
			<section class="posiciones">	
				@foreach ($medals as $medal)
					<div class="position">
						<div class="circle">
							<div class="img">
								<img src="{{$medal->img()}}" alt="avatar">
							</div>
						</div>
						<div class="pos-info" style="padding-bottom: 20px;">
							<a href="{{route('medals.edit', $medal->id)}}" class="btn puntos" style="float: right; margin-left: 30px;">Ver</a>
							@if($medal->generados != null)
								<span class="puntos">Ganadores: {{$medal->users->count()}}</span>
							@else
								<a href="{{route('medals.calcular', $medal->id)}}" class="btn puntos" style="margin-left: 30px;">Calcular ganadores</a>
							@endif
							<span class="nombre-tabla">
								<a href="{{route('medals.edit', $medal->id)}}" class="jugador">{{ $medal->name }}</a>
							</span>
						</div>
					</div>
				@endforeach
				{{ $medals->links() }}
			</section>

		</article>
	</main>
@endsection