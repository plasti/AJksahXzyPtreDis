@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Editar premio</span></h1>

			<section class="form-edit">
				<form action="{{($medal->users->count() == 0) ? route('medals.update', $medal->id) : '#' }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}

					@if($medal->img != null)
						<div class="avatar-edit">
							<img src="{{$medal->img()}}" alt="avatar">
						</div>
					@endif

					<div class="fila-form{{ $errors->has('img') ? ' has-error' : '' }}">
						<label for="img">Subir imagen (300 x 300)</label>
						<input type="file" name="img" id="img">
						@if ($errors->has('img'))
							<span class="valida-msg">
								<strong>{{ $errors->first('avatar') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre del premio</label>
						<input type="text" name="name" id="name" value="{{ $medal->name }}">
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('desc') ? ' has-error' : '' }}">
						<label for="desc">Desccripción del premio</label>
						<textarea name="desc" cols="30" rows="10" placeholder="...">{{$medal->desc}}</textarea>
						@if ($errors->has('desc'))
							<span class="valida-msg">
								<strong>{{ $errors->first('desc') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('desc') ? ' has-error' : '' }}">
						<label for="match">Partido en el cual aplica el premio</label>
						<select name="id_match" required>
							<option value="">Seleccionar..</option>
							@foreach($matchs as $match)
								<option @if($medal->id_match == $match->id) selected @endif value="{{$match->id}}">{{$match->team_a->country}} - vs - {{$match->team_b->country}}</option>
							@endforeach
						</select>
						@if ($errors->has('id_match'))
							<span class="valida-msg">
								<strong>{{ $errors->first('id_match') }}</strong>
							</span>
						@endif
					</div>

					<div class="divider"></div>

					<div class="btn-submit">
						@if($medal->users->count() == 0)
							<input type="submit" name="" value="Guardar cambios" class="btn">
							<a href="{{route('medals.delete', $medal->id)}}" id="eliminar-premio-medal" class="btn">Eliminar premio</a>
						@endif
					</div>

				</form>
			</section>

		</section>

		<section>
			<h1><span>Lista de ganadores</span></h1>
		</section>

		<article>			
			<section class="posiciones">	
				@foreach ($medal->users as $medal_user)
					<div class="position">
						<div class="circle">
							<div class="img">
								<img src="{{$medal_user->user->avatar()}}" alt="avatar">
							</div>
						</div>
						<div class="pos-info" style="padding-bottom: 20px;">
							<a href="{{route('users.edit', $medal_user->user->id)}}" class="btn puntos" style="float: right; margin-left: 30px;">Ver usuario</a>
							<span class="nombre-tabla">
								<a href="{{route('users.edit', $medal_user->user->id)}}" class="jugador">{{ $medal_user->user->name }}</a>
							</span>
						</div>
					</div>
				@endforeach
			</section>

		</article>

	</main>

@endsection