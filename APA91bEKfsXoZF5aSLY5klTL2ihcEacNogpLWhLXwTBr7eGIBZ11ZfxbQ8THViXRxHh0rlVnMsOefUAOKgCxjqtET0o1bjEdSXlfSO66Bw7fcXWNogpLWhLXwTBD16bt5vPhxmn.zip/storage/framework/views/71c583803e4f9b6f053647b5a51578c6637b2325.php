

<?php $__env->startSection('content'); ?>
	<main>

		<div class="comentarios">
			
			<h2>Prediciones del partido</h2>
			<div class="banner-partido">
				<div class="fecha-partido"><?php echo e(date_format(date_create($match->date_time), 'd/m/Y H:i')); ?> HS</div>
				<div class="detalles-partido-comentario">
					<div class="equipo-comentario">
						<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($match->team_a->flag); ?>" alt="Bandera <?php echo e($match->team_a->country); ?>">
						<span><?php echo e($match->team_a->country); ?></span>
						<span class="resultado-comentario"><?php echo e(($match->team_a->score_a != null) ? $match->team_a->score_a : '--'); ?></span>
					</div>
					<strong class="vs">VS</strong>
					<div class="equipo-comentario">
						<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($match->team_b->flag); ?>" alt="Bandera <?php echo e($match->team_b->country); ?>">
						<span><?php echo e($match->team_b->country); ?></span>
						<span class="resultado-comentario"><?php echo e(($match->team_b->score_b != null) ? $match->team_b->score_b : '--'); ?></span>
					</div>
				</div>
			</div>
			<div class="body-comentarios">
				<?php $__currentLoopData = $match->predictions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $predicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="predicion">
						<div class="user">
							<div class="container-img">
								<img src="<?php echo e($predicion->user->avatar()); ?>" alt="Avatar">
							</div>
							<strong><?php echo e($predicion->user->name); ?></strong>
						</div>
						<div class="marca">
							<span class="marcaa"><?php echo e($predicion->a_score); ?></span>
							<span class="separador">:</span>
							<span class="marcaa"><?php echo e($predicion->b_score); ?></span>
						</div>
						<?php if($predicion->points != null): ?>
							<span class="puntos">Puntos: <?php echo e($predicion->points); ?></span>
						<?php endif; ?>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/comentarios.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/predictions/index.blade.php ENDPATH**/ ?>