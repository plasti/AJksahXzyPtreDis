

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Nueva trivia</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(route('trivias.store')); ?>" method="post">
					<?php echo e(csrf_field()); ?>


					<div class="fila-form<?php echo e($errors->has('titulo') ? ' has-error' : ''); ?>">
						<label for="titulo">Titulo de la trivia</label>
						<input type="text" name="titulo" id="titulo" placeholder="Titulo.." value="<?php echo e(old('titulo')); ?>">
						<?php if($errors->has('titulo')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('titulo')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('objetivo') ? ' has-error' : ''); ?>">
						<label for="objetivo">Objetivo de la trivia <small>(esto sera visible para los participantes)</small></label>
						<textarea name="objetivo" id="objetivo" cols="30" rows="10" placeholder="Objetivo.."><?php echo e(old('objetivo')); ?></textarea>
						<?php if($errors->has('objetivo')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('objetivo')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					

					<div class="btn-submit">
						<input type="submit" name="" value="Crear" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/trivias/create.blade.php ENDPATH**/ ?>