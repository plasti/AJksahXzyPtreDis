

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Lista de trivias</span></h1>
		</section>
		<section class="form-search">
			<a href="<?php echo e(route('trivias.create')); ?>" class="btn" style="float: right; margin-left: 15px;">Crear nueva trivia</a>
		</section>
		<section class="posiciones" style="width: 95%;">
			<?php if($trivias->count() > 0): ?>
			<p>Acción</p>
				<?php $__currentLoopData = $trivias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trivia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position">
						<div class="pos-info" style="padding-bottom: 20px; margin-left: 0;">
							<span class="puntos" style="margin-left: 50px;">
								<a href="<?php echo e(route('trivias.edit', $trivia->id)); ?>" class="btn">Editar</a>
							</span>
							<span class="puntos" 
								style="margin-left: 50px; 
								padding: 2px 10px;
								border-radius: 5px;
								background-color: <?php echo e(($trivia->estado == 'Activa') ? '#009d51' : '#e41c24'); ?>"
							><?php echo e($trivia->estado); ?></span>
							<span class="puntos">Preguntas: <?php echo e($trivia->preguntas->count()); ?></span>
							<span class="nombre-tabla">
								<a href="<?php echo e(route('trivias.edit', $trivia->id)); ?>" class="jugador"><?php echo e($trivia->titulo); ?></a>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($trivias->links()); ?>

			<?php else: ?>
				<h3 class="icon">No hay trivias disponibles.</h3>
			<?php endif; ?>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/trivias/index.blade.php ENDPATH**/ ?>