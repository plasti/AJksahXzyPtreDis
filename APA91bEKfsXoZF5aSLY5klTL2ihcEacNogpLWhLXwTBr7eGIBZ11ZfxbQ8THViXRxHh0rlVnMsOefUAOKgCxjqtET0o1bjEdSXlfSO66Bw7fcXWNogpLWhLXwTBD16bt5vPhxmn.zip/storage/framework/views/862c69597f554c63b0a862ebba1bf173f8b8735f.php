<div style="display: block; margin-top: 10px; text-align: left;">
	<a href="#" class="ayuda" id="abrir-modal-tutorial">¿Como funciona?</a>
</div>
<div class="modal-tutorial">
	<div class="cerrar" id="cerrar-modal-tutorial"></div>
	<div class="body-modal">
		<h2>Tutorial</h2>
		<div class="video">
			<iframe src="https://www.youtube.com/embed/dweprOPWYw4" title="Cómo jugar" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		</div>
		<div class="editado">
			<p>La polla américa es un juego en línea para la predicción de resultados de los partidos de La Copa América 2021.</p>
			<p>Los jugadores participan ingresando los marcadores hasta 3 minutos antes de iniciar el partido y acumulan puntos según su predicción.
				La tabla de posiciones se actualiza en tiempo real con cada gol que se marca en el campeonato.</p>
			<p>En la sección de perfil puedes visualizar tu información personal, los premios obtenidos, tu puntaje y posición en la tabla.</p>
			<br>
			
			<p>Para ingresar tu predicción das click en los botones de "+" y "-" para escojer el marcador que crees que finalizará el partido, por último das click en el botón de guardar </p>
			<img src="<?php echo e(asset('images/tut.png')); ?>" alt="">
			<p>¿Cuántos puntos ganaré?</p>
			<ul>
				<li>12 puntos si aciertas el marcador exacto</li>
				<li>7 puntos si aciertas el ganador y los goles de un equipo </li>
				<li>5 puntos si aciertas el ganador o un empate</li>
				<li>2 puntos si aciertas la cantidad de goles de un equipo</li>
			</ul>
			<p>Una vez comience el partido no podrás modificar tu marcador</p>
			<p>Puedes hacer comentarios en los partidos y discutirlos con los otros competidores</p>
		</div>
		<a href="#" id="cerrar-modal-tutorial-btn">Cerrar</a>
	</div>
</div><?php /**PATH C:\wamp64\www\polla_app\resources\views/partidos/partials/tutorial.blade.php ENDPATH**/ ?>