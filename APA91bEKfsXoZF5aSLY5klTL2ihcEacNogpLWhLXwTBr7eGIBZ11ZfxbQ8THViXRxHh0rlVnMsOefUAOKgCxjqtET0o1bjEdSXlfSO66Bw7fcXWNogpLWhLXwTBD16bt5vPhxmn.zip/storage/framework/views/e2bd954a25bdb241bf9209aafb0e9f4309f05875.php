<section class="popup condiciones">
	<span class="close-panel">x</span>
	<h3>Términos y condiciones</h3>
	<div class="in-pop">
		
	</div>
</section>

<?php /**PATH C:\wamp64\www\polla_app\resources\views/layouts/partials/terminos.blade.php ENDPATH**/ ?>