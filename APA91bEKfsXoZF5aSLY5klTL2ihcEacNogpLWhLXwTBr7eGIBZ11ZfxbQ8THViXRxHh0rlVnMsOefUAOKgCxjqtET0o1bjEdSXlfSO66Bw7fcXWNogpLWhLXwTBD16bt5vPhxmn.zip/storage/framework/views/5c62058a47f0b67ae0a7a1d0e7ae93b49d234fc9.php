

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Estructura del archivo de importación de codigos</span></h1>
			<h2>1 - Estructura</h2>
			<div class="editado">
				<p>La estructura del archivo debe llevar 1 columna (codigos)</p>	
				<p>La siguiente imagen se ve un ejemplo claro del archivo: </p>
			</div>
			<div class="container-imagen-estructura">
				<img src="<?php echo e(asset('images/estructura-csv-codigos.PNG')); ?>">
			</div>
			<h2>2 - Guardar archivo</h2>
			<div class="editado">
				<p>Una vez ya tengas tu archivo con la información de los codigos <strong>(Recuerda que nungun codigo debe estar repedito)</strong> , procederemos a guardar el archivo como CSV (archivo separado por comas)</p>
				<p>Ve el ejemplo en la siguiente imagen: </p>
			</div>
			<div class="container-imagen-estructura">
				<img src="<?php echo e(asset('images/exportar-csv-codigos.png')); ?>">
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/codes/howimport.blade.php ENDPATH**/ ?>