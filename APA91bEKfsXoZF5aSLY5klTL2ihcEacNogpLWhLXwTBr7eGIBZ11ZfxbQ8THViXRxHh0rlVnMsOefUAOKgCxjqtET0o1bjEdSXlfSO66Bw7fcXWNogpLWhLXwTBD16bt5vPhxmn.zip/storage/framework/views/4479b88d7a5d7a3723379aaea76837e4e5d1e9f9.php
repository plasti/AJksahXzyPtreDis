

<?php if(config('polla.groups')): ?>
	<?php $__env->startSection('menu-partidos'); ?>
		<ul class="other-view">
			<li>
				<a href="<?php echo e(url('partidos')); ?>" role="button" class="btn <?php echo e($currentMatch == 'personal' ? 'current':''); ?>">
					Mis partidos
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('group.index')); ?>" role="button" class="btn <?php echo e($currentMatch == 'grupo' ? 'current':''); ?>">
					Mi Grupo
				</a>
			</li>
		</ul>
	<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<main class="partidos">
	<article>
		<?php if(config('polla.widget')): ?>
			<?php echo $__env->make('partidos.partials.widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
		<?php if(config('polla.trivia')): ?>
			<?php echo $__env->make('partidos.partials.trivia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>

		<?php echo $__env->make('partidos.partials.tutorial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<h1><span>Partidos</span></h1>
		<?php echo $__env->make('partidos.partials.lista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
		<input type="hidden" value="<?php echo e(route('prediction.store')); ?>" name="urlsave">
	</article>

	<aside>

		<section class="data-user">
			<div class="avatar">
				<div>
					<img src="<?php if(strpos($user->avatar, 'https') === false): ?> <?php echo e(asset('/images/avatars')); ?>/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e($user->avatar); ?> <?php endif; ?>" alt="avatar">
				</div>
			</div>
			<div class="los-datos">
				<h3 class="nombre"><?php echo e($user->name); ?></h3>
				<div class="dato">
					<p>Puntaje</p>
					<span><?php echo e($user->points); ?></span>
				</div>
				<div class="dato">
					<p>Posición</p>
					<span><?php echo e($user->position); ?>°</span>
				</div>
				
				<?php if(config('polla.groups')): ?>
					<h4 class="grupo">Grupo: <?php echo e($user->group->name); ?></h4>
					<div class="dato">
						<p>Puntaje</p>
						<span class="dato"><?php echo e($user->group->points); ?></span>
					</div>
					<div class="dato">
						<p>Posición</p>
						<span class="dato"><?php echo e($user->group->position); ?>°</span>
					</div>
				<?php endif; ?>

			</div>
		</section>

		<section class="posiciones">
			<h2>Top 5</h2>
			<p>Puntos</p>
			<?php $__currentLoopData = $top5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="position <?php if($user->position == 1): ?> primero 
								<?php elseif($user->position == 2): ?> segundo <?php elseif($user->position == 3): ?> tercero <?php endif; ?>">
					<div class="circle">
						<div class="img"><img src="<?php if(strpos($user->avatar, 'https') === false): ?> <?php echo e(asset('/images/avatars')); ?>/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e($user->avatar); ?> <?php endif; ?>" alt="avatar"></div>
						<span class="in-circle"><?php echo e($user->position); ?></span>
					</div>
					<div class="pos-info">
						<span class="puntos"><?php echo e($user->points); ?></span>
						<span class="nombre-tabla"><?php echo e($user->name); ?></span>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			<a href="<?php echo e(url('posiciones')); ?>" class="link-seccion btn">Tabla completa</a>
		</section>

		<section class="premios text-center">
			<h2>Premios</h2>
			<?php $__currentLoopData = config('polla.premios'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="premio">
					<div class="circle-gift">
						<div class="img">
							<img src="<?php echo e(asset('/images')); ?>/<?php echo e($premio['img']); ?>">
						</div>
					</div>
					<div class="gift-info">
						<h3><?php echo e($premio['titulo']); ?></h3>
						<p><?php echo e($premio['descripcion']); ?></p>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e(url('plan-premios')); ?>" class="link-seccion btn">Ver más</a>
		</section> 
		
		<section class="banner">
			
			Paute aquí
		</section>

	</aside>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<script src="<?php echo e(asset('js/partidos.js')); ?>"></script>
	<?php if(config('polla.slider')): ?>
		<script src="<?php echo e(asset('slick/slick.js')); ?>"></script>
		<script src="<?php echo e(asset('js/slider.js')); ?>"></script>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php if(config('polla.slider')): ?>
	<?php $__env->startSection('styles'); ?>
		<link rel="stylesheet" href="<?php echo e(asset('slick/slick.css')); ?>">
	<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/partidos/index.blade.php ENDPATH**/ ?>