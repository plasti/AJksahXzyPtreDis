

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Lista de codigos</span></h1>
		</section>

		<section class="form-search">
			<a href="<?php echo e(route('codes.admin.import')); ?>" class="btn" style="float: right; margin-left: 15px;">Importar codigos ( .CSV )</a>
		</section>

		<article>
			<section class="posiciones">
				<?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position">
						<div class="pos-info" style="padding-bottom: 20px; margin-left: 0;">
							<span class="puntos">
								<a href="<?php echo e(route('codes.admin.delete', $codigo->id)); ?>" id="eliminar_codigo" class="btn">Eliminar</a>
							</span>
							<span class="nombre-tabla">
								<div class="jugador"><?php echo e($codigo->code); ?></div>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($codigos->links()); ?>

			</section>
		</article>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/codes/indexadmin.blade.php ENDPATH**/ ?>