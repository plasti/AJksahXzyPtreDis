

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Lista de grupos</span></h1>
		</section>

		
		<section class="form-search">
			<form action="<?php echo e(route('groups')); ?>" method="get" accept-charset="utf-8">
				<input type="text" name="buscar" value="<?php echo e($buscar); ?>" placeholder="Buscar..">
				<button type="submit" name="" value="" class="btn-buscar icon-search2"></button>
			</form>
		</section>
		

		<article>
			
			<section class="posiciones">
				<?php if(config('polla.groups')): ?>
					<h3 class="icon icon-user-group">Grupos</h3>
				<?php endif; ?>
				<p>Puntos</p>
				<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position <?php if($group->position == 1): ?> primero 
						<?php elseif($group->position == 2): ?> segundo <?php elseif($group->position == 3): ?> tercero <?php endif; ?>">
						<div class="circle">
							<span class="pos-grupo"><?php echo e($group->position); ?></span>
						</div>
						<div class="pos-info">
							<span class="puntos"><?php echo e($group->points); ?></span>
							<span class="nombre-tabla">
								<?php echo e($group->name); ?> - <div class="grupo">Identificador: <?php echo e($group->id); ?></div>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</section>
		</article>

	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/groups/all.blade.php ENDPATH**/ ?>