

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Nuevo premio</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(route('medals.store')); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>


					<div class="fila-form<?php echo e($errors->has('img') ? ' has-error' : ''); ?>">
						<label for="img">Subir imagen (300 x 300)</label>
						<input type="file" name="img" id="img">
						<?php if($errors->has('img')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('avatar')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name">Nombre del premio</label>
						<input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('name')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('desc') ? ' has-error' : ''); ?>">
						<label for="desc">Desccripción del premio</label>
						<textarea name="desc" cols="30" rows="10" placeholder="..."><?php echo e(old('desc')); ?></textarea>
						<?php if($errors->has('desc')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('desc')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('desc') ? ' has-error' : ''); ?>">
						<label for="match">Partido en el cual aplica el premio</label>
						<select name="id_match" required>
							<option value="">Seleccionar..</option>
							<?php $__currentLoopData = $matchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($match->id); ?>"><?php echo e($match->team_a->country); ?> - vs - <?php echo e($match->team_b->country); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('id_match')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('id_match')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/medals/create.blade.php ENDPATH**/ ?>