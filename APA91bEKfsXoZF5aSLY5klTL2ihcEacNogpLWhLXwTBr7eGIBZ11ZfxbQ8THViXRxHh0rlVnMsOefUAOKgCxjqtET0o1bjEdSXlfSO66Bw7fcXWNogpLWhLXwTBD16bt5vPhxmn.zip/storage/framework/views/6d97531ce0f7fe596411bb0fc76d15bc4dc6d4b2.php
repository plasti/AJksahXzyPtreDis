

<?php $__env->startSection('content'); ?>
	<main>
		
		<section>
			
			<h1><span>Perfil</span></h1>
			
			<section class="data-user perfil">
				<div class="contiene-avatar">
					<div class="avatar-perfil">
						<div>
							<img src="<?php if(strpos($user->avatar, 'https') === false): ?> <?php echo e(asset('/images/avatars')); ?>/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e($user->avatar); ?> <?php endif; ?>" alt="avatar">
						</div>
					</div>
				</div>
				<div class="datos-perfil">
					<a href="<?php echo e(url('configuracion')); ?>" class="btn btn-datos icon-edit-pencil">Configuración</a>
					<h2 class="nombre"><?php echo e($user->name); ?></h2>
					<?php if(config('polla.groups')): ?>
						<h3><?php echo e($user->group->name); ?></h3>
					<?php endif; ?>
					
					<div class="datos-contenedor">
						<div class="dato">
							<p>Mi puntaje</p>
							<span><?php echo e($user->points); ?></span>
						</div>
						<i class="separador icon-star"></i>
						<div class="dato">
							<p>Mi posición</p>
							<span><?php echo e($user->position); ?>°</span>
						</div>
						
						<?php if(config('polla.groups')): ?>
							<i class="separador icon-star medio"></i>
							<div class="dato">
								<p>Mi grupo</p>
								<span><?php echo e($user->group->points); ?></span>
							</div>
							<i class="separador icon-star"></i>
							<div class="dato">
								<p>Su posición</p>
								<span><?php echo e($user->group->position); ?>°</span>
							</div>
						<?php endif; ?>

					</div>
				</div> <!-- fin datos perfil -->

			</section>

			<?php if(config('polla.medals')): ?>
				<section class="logros">
					<h2 class="icon-trophy">Logros</h2>
					<div class="lista-logros">
						<?php $__currentLoopData = $user->medals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="logro">
								<div class="name">
									<div class="img-premio">
										<img src="<?php echo e($medal->medal->img()); ?>">
									</div>
									<strong><?php echo e($medal->medal->name); ?></strong>
								</div>
								<strong><?php echo e(App\Plastimedia::parse_fecha($medal->created_at)); ?></strong>
								<?php if($medal->delivered == 1): ?>
									<p>Redimido - <?php echo e(App\Plastimedia::parse_fecha($medal->updated_at)); ?></p>
								<?php else: ?>
									<p>Sin redimir</p>
								<?php endif; ?>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</section>
			<?php endif; ?>

		</section>

	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/users/index.blade.php ENDPATH**/ ?>