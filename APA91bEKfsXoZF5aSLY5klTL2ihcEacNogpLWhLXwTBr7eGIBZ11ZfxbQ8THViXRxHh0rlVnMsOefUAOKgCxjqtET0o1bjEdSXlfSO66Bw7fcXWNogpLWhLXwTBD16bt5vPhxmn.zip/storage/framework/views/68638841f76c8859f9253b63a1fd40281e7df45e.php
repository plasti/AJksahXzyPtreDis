

<?php $__env->startSection('content'); ?>
	<main>
		<section>
			<h1>App mobile</h1>
			<div class="qr-img">
				<?php
					$objet = [
						'name' => config('polla.name'),
						'generated' => "polla",
						'primary' => config('polla.primario'),
						'secondary' => config('polla.secundario'),
						'logo' => asset('images/logo.png'),
						'background' => asset('images/campo768.jpg'),
						'host' => $_SERVER['SERVER_NAME'],
					];
				?>
				<?php echo QrCode::size(400)->backgroundColor(0,0,0,0)->color(255,255,255)->generate(json_encode($objet));; ?>

			</div>
			<div class="btn-stores">
				<a href="#">
					<img src="<?php echo e(asset('images/googleplay.png')); ?>">
					Play store
				</a>
				<a href="#">
					<img src="<?php echo e(asset('images/apple.png')); ?>">
					App store
				</a>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/appmobile.blade.php ENDPATH**/ ?>