<section class="popup politicas">
	<span class="close-panel">x</span>
	<h3>Políticas de privacidad</h3>
	<div class="in-pop">
		
	</div>
</section><?php /**PATH C:\wamp64\www\polla_america\resources\views/layouts/partials/politicas.blade.php ENDPATH**/ ?>