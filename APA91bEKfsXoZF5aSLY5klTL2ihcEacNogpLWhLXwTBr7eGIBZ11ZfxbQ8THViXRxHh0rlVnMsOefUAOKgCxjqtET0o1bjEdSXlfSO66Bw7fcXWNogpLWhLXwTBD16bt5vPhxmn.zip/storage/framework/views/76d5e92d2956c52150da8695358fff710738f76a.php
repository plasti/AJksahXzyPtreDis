

<?php $__env->startSection('content'); ?>

<main>

	<div class="loader"></div>

	<section>
		
		<h1><span>Importar marcador</span></h1>
		
	</section>

	<section class="respuestas">
		<ul class="ul-respuesta">
			<li>Marcador importado</li>
		</ul>
	</section>

	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e(url('user-predictions')); ?>" class="urlPredUser">
	<input type="hidden" value="<?php echo e(url('user-points')); ?>" class="urlPointsUser">
	<input type="hidden" value="<?php echo e(url('user-positions')); ?>" class="urlPositionUser">
	<input type="hidden" value="<?php echo e(config('polla.groups') ? url('group-predictions') : ''); ?>" class="urlPredGroup">
	<input type="hidden" value="<?php echo e(config('polla.groups') ? url('group-points') : ''); ?>" class="urlPointsGroup">
	<input type="hidden" value="<?php echo e(config('polla.groups') ? url('group-positions') : ''); ?>" class="urlPositionGroup">
	<input type="hidden" value="<?php echo e(url('match/update')); ?>" class="urlMatchUpdate">

</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<script src="<?php echo e(asset('js/import.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/partidos/import.blade.php ENDPATH**/ ?>