<div style="display: block; margin-top: 10px; text-align: left;">
	<a href="#" class="ayuda" id="abrir-modal-tutorial">¿Como funciona?</a>
</div>
<div class="modal-tutorial">
	<div class="cerrar" id="cerrar-modal-tutorial"></div>
	<div class="body-modal">
		<h2>Tutorial</h2>
		<div class="video">
			<iframe src="https://www.youtube.com/embed/s6PUuGbi4EE" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		</div>
		<a href="#" id="cerrar-modal-tutorial-btn">Cerrar</a>
	</div>
</div><?php /**PATH C:\wamp64\www\polla_america\resources\views/partidos/partials/tutorial.blade.php ENDPATH**/ ?>