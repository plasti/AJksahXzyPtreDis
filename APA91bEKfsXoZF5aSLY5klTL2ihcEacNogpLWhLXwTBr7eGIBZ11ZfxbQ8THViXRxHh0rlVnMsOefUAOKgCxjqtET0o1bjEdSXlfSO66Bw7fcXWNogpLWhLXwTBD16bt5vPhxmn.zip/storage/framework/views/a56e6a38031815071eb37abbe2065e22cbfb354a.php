

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Editar premio</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(($medal->users->count() == 0) ? route('medals.update', $medal->id) : '#'); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>


					<?php if($medal->img != null): ?>
						<div class="avatar-edit">
							<img src="<?php echo e($medal->img()); ?>" alt="avatar">
						</div>
					<?php endif; ?>

					<div class="fila-form<?php echo e($errors->has('img') ? ' has-error' : ''); ?>">
						<label for="img">Subir imagen (300 x 300)</label>
						<input type="file" name="img" id="img">
						<?php if($errors->has('img')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('avatar')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name">Nombre del premio</label>
						<input type="text" name="name" id="name" value="<?php echo e($medal->name); ?>">
						<?php if($errors->has('name')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('desc') ? ' has-error' : ''); ?>">
						<label for="desc">Desccripción del premio</label>
						<textarea name="desc" cols="30" rows="10" placeholder="..."><?php echo e($medal->desc); ?></textarea>
						<?php if($errors->has('desc')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('desc')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('desc') ? ' has-error' : ''); ?>">
						<label for="match">Partido en el cual aplica el premio</label>
						<select name="id_match" required>
							<option value="">Seleccionar..</option>
							<?php $__currentLoopData = $matchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option <?php if($medal->id_match == $match->id): ?> selected <?php endif; ?> value="<?php echo e($match->id); ?>"><?php echo e($match->team_a->country); ?> - vs - <?php echo e($match->team_b->country); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('id_match')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('id_match')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="divider"></div>

					<div class="btn-submit">
						<?php if($medal->users->count() == 0): ?>
							<input type="submit" name="" value="Guardar cambios" class="btn">
							<a href="<?php echo e(route('medals.delete', $medal->id)); ?>" id="eliminar-premio-medal" class="btn">Eliminar premio</a>
						<?php endif; ?>
					</div>

				</form>
			</section>

		</section>

		<section>
			<h1><span>Lista de ganadores</span></h1>
		</section>

		<article>			
			<section class="posiciones">	
				<?php $__currentLoopData = $medal->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medal_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position">
						<div class="circle">
							<div class="img">
								<img src="<?php echo e($medal_user->user->avatar()); ?>" alt="avatar">
							</div>
						</div>
						<div class="pos-info" style="padding-bottom: 20px;">
							<a href="<?php echo e(route('users.edit', $medal_user->user->id)); ?>" class="btn puntos" style="float: right; margin-left: 30px;">Ver usuario</a>
							<span class="nombre-tabla">
								<a href="<?php echo e(route('users.edit', $medal_user->user->id)); ?>" class="jugador"><?php echo e($medal_user->user->name); ?></a>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</section>

		</article>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/medals/edit.blade.php ENDPATH**/ ?>