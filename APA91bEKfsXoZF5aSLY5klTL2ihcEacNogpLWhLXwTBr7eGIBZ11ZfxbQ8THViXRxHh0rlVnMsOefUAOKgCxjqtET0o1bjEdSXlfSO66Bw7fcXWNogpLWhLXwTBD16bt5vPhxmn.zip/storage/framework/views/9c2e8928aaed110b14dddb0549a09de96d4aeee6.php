

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Lista de premios</span></h1>
		</section>

		<section class="form-search">
			<a href="<?php echo e(route('medals.create')); ?>" class="btn" style="float: right; margin-left: 15px;">Nuevo premio</a>
		</section>	

		<article>
			
			<section class="posiciones">	
				<?php $__currentLoopData = $medals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position">
						<div class="circle">
							<div class="img">
								<img src="<?php echo e($medal->img()); ?>" alt="avatar">
							</div>
						</div>
						<div class="pos-info" style="padding-bottom: 20px;">
							<a href="<?php echo e(route('medals.edit', $medal->id)); ?>" class="btn puntos" style="float: right; margin-left: 30px;">Ver</a>
							<?php if($medal->generados != null): ?>
								<span class="puntos">Ganadores: <?php echo e($medal->users->count()); ?></span>
							<?php else: ?>
								<a href="<?php echo e(route('medals.calcular', $medal->id)); ?>" class="btn puntos" style="margin-left: 30px;">Calcular ganadores</a>
							<?php endif; ?>
							<span class="nombre-tabla">
								<a href="<?php echo e(route('medals.edit', $medal->id)); ?>" class="jugador"><?php echo e($medal->name); ?></a>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($medals->links()); ?>

			</section>

		</article>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/medals/index.blade.php ENDPATH**/ ?>