<?php if($widget->estado == 'Activo' && $widget->titulo != null && ($widget->wpp != null || $widget->tel != null)): ?>
	<div class="widget" style="background-color: <?php echo e($widget->color); ?>">
		<h2><?php echo e($widget->titulo); ?></h2>
		<div class="btns">
			<?php if($widget->tel != null): ?>
				<a href="tel:<?php echo e($widget->tel); ?>" class="icon-phone"><?php echo e($widget->tel); ?></a>
			<?php endif; ?>
			<?php if($widget->wpp != null): ?>
				<a href="https://api.whatsapp.com/send?phone=<?php echo e($widget->wpp); ?>" class="icon-whatsapp"><?php echo e($widget->wpp); ?></a>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/partidos/partials/widget.blade.php ENDPATH**/ ?>