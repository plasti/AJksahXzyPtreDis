

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Nuevo usurio</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(route('users.store')); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>


					<div class="fila-form<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name">Nombre *</label>
						<input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre del usuario">
						<?php if($errors->has('name')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
						<label for="email">E-mail</label>
						<input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="ejemplo@correo.com">
						<?php if($errors->has('email')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('email')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('id_group') ? ' has-error' : ''); ?>">
						<label for="<?php echo e('id_group'); ?>">Grupo *</label>
						<select name="<?php echo e('id_group'); ?>" id="<?php echo e('id_group'); ?>">
							<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($grupo->id); ?>"><?php echo e($grupo->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('id_group')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('id_group')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
						<label for="password">Contraseña</label>
						<input id="password" type="password" name="password" placeholder="*********">
						<?php if($errors->has('password')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('password')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form">
						<label for="password-confirm">Confirmar contraseña</label>
						<input id="password-confirm" type="password" name="password_confirmation" placeholder="*********">
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Registrar" class="btn">
					</div>

				</form>
			</section>
		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/users/create.blade.php ENDPATH**/ ?>