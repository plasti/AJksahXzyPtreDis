<header>
	<div class="ancho">
		
		<?php echo $__env->yieldContent('minialert'); ?>

		<div class="menu-sec">
			<input type="checkbox" id="menu-check" />
			<label for="menu-check" class="label-menu">
				<div class="btn-menu" role="button"> 
					<div class="stick1"></div><div class="stick2"></div><div class="stick3"></div>
				</div>
				<ul>
					<?php if(Auth::guest()): ?>
						<li><a href="<?php echo e(url('login')); ?>">Iniciar sesión</a></li>
					<?php endif; ?>
					<li><a href="<?php echo e(url('instrucciones')); ?>">Instrucciones</a></li>
					<li><a href=" <?php echo e(url('plan-premios')); ?> ">Plan de premios</a></li>
					<li><a href=" <?php echo e(url('la-polla')); ?> ">Sobre la polla</a></li>
					<?php if(config('polla.app_mobile')): ?>
						<li><a href="<?php echo e(url('app/mobile')); ?>">Aplicación mobile</a></li>
					<?php endif; ?>
					<?php if(!Auth::guest()): ?>
						<li><a href=" <?php echo e(url('configuracion')); ?> ">Configurar perfil</a></li>
						<?php if(Auth::user()->role == 'admin'): ?>
							<?php if(config('polla.medals')): ?>
								<li class="item-admin"><a href="<?php echo e(route('medals')); ?>">Configurar premios</a></li>
							<?php endif; ?>
							<?php if(config('polla.users_admin')): ?>
								<li class="item-admin"><a href=" <?php echo e(url('users')); ?> ">Configurar usuarios</a></li>
							<?php endif; ?>
							<?php if(config('polla.groups')): ?>
								<li class="item-admin"><a href=" <?php echo e(url('groups')); ?> ">Grupos</a></li>
							<?php endif; ?>
							<?php if(config('polla.code_section')): ?>
								<li class="item-admin"><a href=" <?php echo e(route('codes.admin')); ?> ">Configurar códigos</a></li>
							<?php endif; ?>
							<?php if(config('polla.slider')): ?>
								<li class="item-admin"><a href=" <?php echo e(url('sliders')); ?> ">Configurar sliders</a></li>
							<?php endif; ?>
							<?php if(config('polla.trivia')): ?>
								<li class="item-admin"><a href="<?php echo e(route('trivias')); ?>">Configurar trivia</a></li>
							<?php endif; ?>
							<?php if(config('polla.widget')): ?>
								<li class="item-admin"><a href="<?php echo e(route('widget.edit')); ?>">Configurar widget</a></li>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
					<?php if(!Auth::guest()): ?>
						<li>
							<a href="<?php echo e(route('logout')); ?>"
								onclick="event.preventDefault();
								document.getElementById('logout-form').submit();">
								Salir
							</a>

							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								<?php echo e(csrf_field()); ?>

							</form>
						</li>
					<?php endif; ?>
				</ul>
			</label>
		</div> 
		
		<?php if(auth()->guard()->check()): ?>
			<a href="<?php echo e(route('notificaciones')); ?>" class="notificaciones" id="icono_notificacion_header">
				<img src="<?php echo e(asset('images/bell.png')); ?>">
				<span style="display: <?php echo e((App\Plastimedia::check_notificaciones(Auth::user()->id)) ? 'block' : 'none'); ?>" class="bola" id="bola_notificacion"></span>
			</a>
			<div class="notificacion-fixed">
            	<a href="#" class="cerrar-notificacion">x</a>
            	<div class="banner-notificacion">
            		<div class="container-img">
            			<img id="icono_notificacion" src="">
            		</div>
            	</div>
            	<div class="body-notificacion">
            		<h3 id="title_notificacion">---</h3>
            		<p id="content_notificacion">---</p>
	            	<div class="footer">
	            		<a href="#" id="boton_notificacion">Ver más</a>
	            	</div>
            	</div>
        	</div>
		<?php endif; ?>

		

		<div class="logo <?php echo e((Auth::guest())?'no-menu':''); ?>">
			<a href="<?php echo e(url('partidos')); ?>">
				<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo la polla mundial">
			</a>
		</div>

		<?php if(!Auth::guest()): ?>
			
			<div class="menu-ppl">
				
				<?php echo $__env->yieldContent('menu-partidos'); ?>

				<nav>
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="<?php echo e(url('partidos')); ?>" class="icon-soccer-ball <?php if(isset($current)): ?> <?php echo e($current == 'partidos' ? 'current':''); ?> <?php endif; ?>">
								Partidos
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('posiciones')); ?>" class="icon-trophy <?php if(isset($current)): ?> <?php echo e($current == 'posiciones' ? 'current':''); ?> <?php endif; ?>">
								Posiciones
							</a>
						</li>
						<?php if(config('polla.code_section')): ?>
							<li>
								<a href="<?php echo e(url('codes')); ?>" class="icon-barcode <?php if(isset($current)): ?> <?php echo e($current == 'codes' ? 'current':''); ?> <?php endif; ?>">
									Códigos
								</a>
							</li>
						<?php endif; ?>
						<li>
							<a href="<?php echo e(url('perfil')); ?>" class="icon-user <?php if(isset($current)): ?> <?php echo e($current == 'perfil' ? 'current':''); ?> <?php endif; ?>">
								Perfil
							</a>
						</li>
					</ul>
				</nav>
			</div>

		<?php endif; ?>

	</div> 
</header> 


<?php if(session('status')): ?>
	<div class="alert <?php echo e(session('class')); ?>" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="icon-cerrar"></i></button>
		<?php echo e(session('status')); ?>

	</div>
<?php endif; ?>

<?php /**PATH C:\wamp64\www\polla_app\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>