

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Códigos</span></h1>
		</section>

		<section class="form-code">
			<form action="<?php echo e(url('codes')); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				<h3>Si tienes un código de la polla registralo aquí</h3>
				<div class="fila-form<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
					<input id="code" type="text" name="code" value="<?php echo e(old('code')); ?>" required autofocus placeholder="######">
					
				</div>

				<div class="btn-submit">
					<input type="submit" name="" value="Registrar código" class="btn">
				</div>
			</form>
			<?php if($errors->has('code')): ?>
				<span class="valida-msg">
					<strong><?php echo e($errors->first('code')); ?></strong>
				</span>
			<?php endif; ?>
		</section>

		<table class="codes-list">
			<caption>
				<h4>Códigos registrados: <?php echo e(count($codes)); ?></h4>
				<h4>Puntos acumulados: <?php echo e(count($codes) * config('polla.code_points')); ?></h4>
			</caption>
			<thead>
				<tr>
					<th>Código</th>
					<th>Fecha de registro</th>
					<th>Puntos ganados</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($code->code->used_code); ?></td>
						<td><?php echo e(\Carbon\Carbon::parse($code->created_at)->format('d/m/Y H:i')); ?></td>
						<td><?php echo e(config('polla.code_points')); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/codes/index.blade.php ENDPATH**/ ?>