<?php if($sliders->count() > 0): ?>
<div class="sliders">
	<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($slider->link != null): ?>
			<a href="<?php echo e($slider->link); ?>" target="_blank" class="slider">
				<img src="<?php echo e($slider->img()); ?>">
			</a>
		<?php else: ?>
			<div class="slider">
				<img src="<?php echo e($slider->img()); ?>">
			</div>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/partidos/partials/slider.blade.php ENDPATH**/ ?>