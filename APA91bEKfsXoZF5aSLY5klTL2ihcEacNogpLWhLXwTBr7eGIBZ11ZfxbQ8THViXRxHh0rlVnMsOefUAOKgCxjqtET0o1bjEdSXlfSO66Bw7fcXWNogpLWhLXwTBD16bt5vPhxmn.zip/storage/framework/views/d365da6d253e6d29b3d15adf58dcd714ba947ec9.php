

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Configuración de widget</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(route('widget.update')); ?>" method="post">
					<?php echo e(csrf_field()); ?>


					<?php $campo = 'titulo' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Titulo del widget</label>
						<input type="text" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="Titulo.." value="<?php echo e($widget->$campo); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'wpp' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Numero de Whatsapp</label>
						<input type="number" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="000 000 00 00" value="<?php echo e($widget->$campo); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>


					<?php $campo = 'tel' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Numero de teléfono</label>
						<input type="number" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="000 000 00 00" value="<?php echo e($widget->$campo); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'color' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Color de fondo del widget</label>
						<input type="color" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" value="<?php echo e($widget->$campo); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'estado' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Estado del widget</label>
						<select name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>">
							<option value="Activo" <?php if($widget->$campo == 'Activo'): ?> selected <?php endif; ?>>Activo</option>
							<option value="Inactivo" <?php if($widget->$campo == 'Inactivo'): ?> selected <?php endif; ?>>Inactivo</option>
						</select>
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/widget/edit.blade.php ENDPATH**/ ?>