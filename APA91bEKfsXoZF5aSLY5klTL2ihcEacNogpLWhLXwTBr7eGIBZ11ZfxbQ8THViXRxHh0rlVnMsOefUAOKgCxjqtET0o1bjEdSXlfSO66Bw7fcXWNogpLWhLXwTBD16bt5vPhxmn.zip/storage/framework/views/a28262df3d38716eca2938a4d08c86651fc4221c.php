

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Nueva pregunta</span></h1>

			<form action="<?php echo e(route('preguntas.store', $id)); ?>" method="post" style="text-align: center;" accept-charset="utf-8" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<section class="form-edit" style="display: inline-block; vertical-align: top; max-width: 400px; width: 95%; margin: 0 20px; text-align: left;">
        			<?php $campo = 'pregunta' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Pregunta *</label>
						<textarea name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" cols="30" rows="10" placeholder="Pregunta.."><?php echo e(old($campo)); ?></textarea>
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'tiempo' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Tiempo de respuesta ( en segundos ) *</label>
						<input type="number" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="0" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'puntos' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Puntos que suma la pregunta *</label>
						<input type="number" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="0" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'imagen' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Imagen ( opcional ) ( dimensiones 400 x 300 )</label>
						<input type="file" accept="image/*" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</section>
				<section class="form-edit" style="display: inline-block; vertical-align: top; max-width: 400px; width: 95%; margin: 0 20px; text-align: left;">
					<?php $campo = 'opcion_a' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Opción A</label>
						<input type="text" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="Opción A" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'opcion_b' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Opción B</label>
						<input type="text" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="Opción B" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'opcion_c' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Opción C</label>
						<input type="text" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="Opción C" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'opcion_d' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Opción D</label>
						<input type="text" name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>" placeholder="Opción D" value="<?php echo e(old($campo)); ?>">
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<?php $campo = 'respuesta' ?>
					<div class="fila-form<?php echo e($errors->has($campo) ? ' has-error' : ''); ?>">
						<label for="<?php echo e($campo); ?>">Respuesta corecta *</label>
						<select name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>">
							<option value="">Seleccionar..</option>
							<option value="A" <?php if(old($campo) == 'A'): ?> selected <?php endif; ?>>Opción A</option>
							<option value="B" <?php if(old($campo) == 'B'): ?> selected <?php endif; ?>>Opción B</option>
							<option value="C" <?php if(old($campo) == 'C'): ?> selected <?php endif; ?>>Opción C</option>
							<option value="D" <?php if(old($campo) == 'D'): ?> selected <?php endif; ?>>Opción D</option>
						</select>
						<?php if($errors->has($campo)): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first($campo)); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</section>

				<div class="divider"></div>

				<div class="btn-submit">
					<input type="submit" name="" value="Crear" class="btn">
				</div>
			</form>

		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/preguntas/create.blade.php ENDPATH**/ ?>