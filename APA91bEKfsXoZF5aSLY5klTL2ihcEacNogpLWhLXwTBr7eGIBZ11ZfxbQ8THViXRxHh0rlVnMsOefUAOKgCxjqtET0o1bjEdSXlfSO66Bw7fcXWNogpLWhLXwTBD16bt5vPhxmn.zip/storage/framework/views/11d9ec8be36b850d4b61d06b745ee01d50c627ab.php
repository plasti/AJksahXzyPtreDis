

<?php $__env->startSection('content'); ?>
	<main>

		<section style="text-align: center;">
			<h1><span>Editar trivia</span></h1>

			<form action="<?php echo e(route('trivias.update', $trivia->id)); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<section class="form-edit" style="display: inline-block; vertical-align: top; max-width: 400px; width: 95%; margin: 0 10px; text-align: left;">
					<div class="fila-form<?php echo e($errors->has('titulo') ? ' has-error' : ''); ?>">
						<label for="titulo">Titulo de la trivia</label>
						<input type="text" name="titulo" id="titulo" placeholder="Titulo.." value="<?php echo e($trivia->titulo); ?>">
						<?php if($errors->has('titulo')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('titulo')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="fila-form<?php echo e($errors->has('estado') ? ' has-error' : ''); ?>">
						<label for="estado">Estado</label>
						<select name="estado" id="estado">
							<option value="">Seleccionar..</option>
							<option value="Activa" <?php if($trivia->estado == 'Activa'): ?> selected <?php endif; ?>>Activa</option>
							<option value="Inactiva" <?php if($trivia->estado == 'Inactiva'): ?> selected <?php endif; ?>>Inactiva</option>
						</select>
						<?php if($errors->has('estado')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('estado')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</section>
				<section class="form-edit" style="display: inline-block; vertical-align: top; max-width: 400px; width: 95%; margin: 0 10px; text-align: left;">
					<div class="fila-form<?php echo e($errors->has('objetivo') ? ' has-error' : ''); ?>">
						<label for="objetivo">Objetivo de la trivia <small>(esto sera visible para los participantes)</small></label>
						<textarea name="objetivo" id="objetivo" cols="30" rows="10" placeholder="Objetivo.."><?php echo e($trivia->objetivo); ?></textarea>
						<?php if($errors->has('objetivo')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('objetivo')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
				</section>

				<div class="divider"></div>

				<section class="form-edit">
					<section class="form-search" style="display: block; width: 100%; text-align: right; margin: 10px auto;">
						<a href="<?php echo e(route('preguntas.create', $trivia->id)); ?>" class="btn">Nueva pregunta</a>
					</section>

					<section class="posiciones">
						<h3 class="icon">Preguntas</h3>
						<?php if($trivia->preguntas->count() > 0): ?>
							<?php $__currentLoopData = $trivia->preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="position">
									<div class="pos-info" style="padding-bottom: 20px; margin-left: 0;">
										<span class="puntos" style="margin-left: 50px;">
											<a href="<?php echo e(route('preguntas.edit', $pregunta->id)); ?>" class="btn">Editar</a>
										</span>
										<span class="puntos">Puntos: <?php echo e($pregunta->puntos); ?></span>
										<span class="nombre-tabla">
											<a href="#" class="jugador"><?php echo e($pregunta->pregunta); ?></a>
										</span>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<h3 class="icon">No hay preguntas disponibles.</h3>
						<?php endif; ?>
					</section>
				</section>

				<div class="divider"></div>
				<div class="btn-submit">
					<input type="submit" name="" value="Actualizar" class="btn">
				</div>
			</form>
		</section>
	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/trivias/edit.blade.php ENDPATH**/ ?>