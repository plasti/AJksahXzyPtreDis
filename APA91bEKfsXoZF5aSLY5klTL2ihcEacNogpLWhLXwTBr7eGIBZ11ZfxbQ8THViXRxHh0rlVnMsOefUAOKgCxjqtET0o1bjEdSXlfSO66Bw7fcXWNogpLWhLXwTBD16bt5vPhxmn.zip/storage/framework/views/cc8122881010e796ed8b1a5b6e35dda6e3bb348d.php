<?php if(config('polla.slider')): ?>
	<div class="banner-big">
		<?php echo $__env->make('partidos.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>	
<?php endif; ?>

<?php $__currentLoopData = $etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h2 class="etapa-titulo"><?php echo e($etapa['titulo']); ?></h2>
	
	<?php
		$dia = '';
	?>
	
	<?php $__currentLoopData = $etapa['partidos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($dia == ''): ?>
			<a class="<?php echo e(Carbon\Carbon::parse($partido->date_time)->format('n-j')); ?>" ></a>
			<section class="dia"> 
		<?php endif; ?>
		
		<?php if($dia != $partido->date ): ?>
			<?php if($dia != ''): ?>
				</section>
				<a class="<?php echo e(Carbon\Carbon::parse($partido->date_time)->format('n-j')); ?>" ></a>
				<section class="dia">
			<?php endif; ?>
			<?php
				$dia = $partido->date;
			?>
			<?php if(config('polla.slider')): ?>
				<?php if( Carbon\Carbon::parse($partido->date_time)->format('n-j') == Carbon\Carbon::now()->format('n-j') ): ?>
					<div class="banner-big">
						<?php echo $__env->make('partidos.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				<?php endif; ?>
			<?php endif; ?>

			<div class="fecha">
				<i class="icon-calendar2"></i>
				<?php echo e($partido->date); ?>

			</div>
		<?php endif; ?>
		
		
		<?php if($partido->cerrado): ?> 
			<div class="partido">
				<div class="time"><i class="icon-clock"></i><?php echo e($partido->time); ?> HS</div>
				<div class="datos">
					<div>
						
						<div class="team-l">
							<div class="flag">
								<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($partido->team_a->flag); ?>" alt="Bandera <?php echo e($partido->team_a->country); ?>">
							</div>
							<div class="nombre <?php if(!is_null($partido->nombres)): ?> <?php echo e($partido->nombres ? 'win':'fail'); ?> <?php endif; ?>">
								<?php echo e($partido->team_a->country); ?>

							</div>
						</div>
						
						<div class="marcador cerrado">
							<div class="m-left">
								<input type="text" name="p<?php echo e($partido->id_match); ?>-t1" min="0" placeholder="-" value="<?php echo e($partido->a_score); ?>" 
									class="p<?php echo e($partido->id_match); ?>-t1 <?php if(!is_null($partido->marcador_a)): ?> <?php echo e($partido->marcador_a ? 'win':'fail'); ?> <?php endif; ?>" 
									readonly />
							</div>
							<div class="separa-teams">
								<i class="icon-star"></i><i class="icon-star"></i>
							</div>
							<div class="m-right">
								<input type="text" name="p<?php echo e($partido->id_match); ?>-t2" min="0" placeholder="-" value="<?php echo e($partido->b_score); ?>" 
									class="p<?php echo e($partido->id_match); ?>-t2 <?php if(!is_null($partido->marcador_b)): ?> <?php echo e($partido->marcador_b ? 'win':'fail'); ?> <?php endif; ?>" 
									readonly />
							</div>
						</div>
						
						<div class="team-r">
							<div class="nombre <?php if(!is_null($partido->nombres)): ?> <?php echo e($partido->nombres ? 'win':'fail'); ?> <?php endif; ?>">
								<?php echo e($partido->team_b->country); ?>

							</div>
							<div class="flag">
								<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($partido->team_b->flag); ?>" alt="Bandera <?php echo e($partido->team_b->country); ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="save-div"></div>
				
				<?php if( !is_null($partido->score_a) && !is_null($partido->score_b) ): ?>
					<div class="resultado">
						<span><?php echo e($partido->team_a->country); ?> <?php echo e($partido->score_a); ?> : <?php echo e($partido->score_b); ?> <?php echo e($partido->team_b->country); ?></span> 
						<?php if($partido->points > 0): ?> <span class="puntos">+ <?php echo e($partido->points); ?> pts</span> <?php endif; ?>
					</div>
				<?php endif; ?>
				<br>
				<a href="<?php echo e(route('comentarios', $partido->id_match)); ?>" class="link-comentarios">Ver comentarios</a>
				<a href="<?php echo e(route('marcadores', $partido->id_match)); ?>" class="link-comentarios">Ver marcadores</a>
			</div>
		<?php else: ?> 
			<div class="partido">
				<div class="time"><i class="icon-clock"></i><?php echo e($partido->time); ?> HS</div>
				<div class="datos p<?php echo e($partido->id_match); ?>-t1 p<?php echo e($partido->id_match); ?>-t2">
					<div>
						
						<div class="team-l">
							<div class="flag">
								<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($partido->team_a->flag); ?>" alt="Bandera <?php echo e($partido->team_a->country); ?>">
							</div>
							<div class="nombre"><?php echo e($partido->team_a->country); ?></div>
						</div>
						
						<div class="marcador">
							<div class="m-left">
								<button type="button" class="btn-plus" value="p<?php echo e($partido->id_match); ?>-t1"><i class="icon-plus"></i></button>
								<input type="text" name="p<?php echo e($partido->id_match); ?>-t1" class="score p<?php echo e($partido->id_match); ?>-t1" min="0" placeholder="-" 
									value="<?php echo e($partido->a_score); ?>" maxlength="1" />
								<button type="button" class="btn-minus" value="p<?php echo e($partido->id_match); ?>-t1"><i class="icon-minus"></i></button>
							</div>
							<div class="separa-teams"><i class="icon-star"></i><i class="icon-star"></i></div>
							<div class="m-right">
								<button type="button" class="btn-plus" value="p<?php echo e($partido->id_match); ?>-t2"><i class="icon-plus"></i></button>
								<input type="text" name="p<?php echo e($partido->id_match); ?>-t2" class="score p<?php echo e($partido->id_match); ?>-t2" min="0" placeholder="-" 
									value="<?php echo e($partido->b_score); ?>" maxlength="1" />
								<button type="button" class="btn-minus" value="p<?php echo e($partido->id_match); ?>-t2"><i class="icon-minus"></i></button>
							</div>
						</div>
						
						<div class="team-r">
							<div class="nombre"><?php echo e($partido->team_b->country); ?></div>
							<div class="flag">
								<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($partido->team_b->flag); ?>" alt="Bandera <?php echo e($partido->team_b->country); ?>">
							</div>
						</div>
						<label class="p<?php echo e($partido->id_match); ?>-t1 p<?php echo e($partido->id_match); ?>-t2 "></label>
					</div>
				</div> 

				<div class="save-div">
					<button class="save-match p<?php echo e($partido->id_match); ?>-t1 p<?php echo e($partido->id_match); ?>-t2" name="p<?php echo e($partido->id_match); ?>-t1" id="p<?php echo e($partido->id_match); ?>">
						Guardar
					</button>
				</div>
				<a href="<?php echo e(route('comentarios', $partido->id_match)); ?>" class="link-comentarios">Ver comentarios</a>
				
			</div> 
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</section> 

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e(csrf_field()); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/partidos/partials/lista.blade.php ENDPATH**/ ?>