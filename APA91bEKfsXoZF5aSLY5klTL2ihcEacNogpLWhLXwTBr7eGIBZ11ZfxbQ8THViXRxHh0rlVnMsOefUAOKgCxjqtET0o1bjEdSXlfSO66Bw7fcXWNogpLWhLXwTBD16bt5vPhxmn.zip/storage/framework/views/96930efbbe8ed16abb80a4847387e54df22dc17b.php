<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('head_title'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('/images/favicon.png')); ?>" />

    <!-- Styles -->
    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
    <!-- Fuente de google -->
    <link href="https://fonts.googleapis.com/css?family=Saira+Condensed:300,500" rel="stylesheet">
    <meta name="theme-color" content="<?php echo e(config('polla.primario')); ?>" />
</head>
<body asset="<?php echo e(asset('/')); ?>" id_polla="<?php echo e(config('polla.id')); ?>">    
    <div class="fondo-sitio"></div>
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="ancho">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plastimedia.js')); ?>"></script>
    <?php echo $__env->make('layouts.partials.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\polla_america\resources\views/layouts/app.blade.php ENDPATH**/ ?>