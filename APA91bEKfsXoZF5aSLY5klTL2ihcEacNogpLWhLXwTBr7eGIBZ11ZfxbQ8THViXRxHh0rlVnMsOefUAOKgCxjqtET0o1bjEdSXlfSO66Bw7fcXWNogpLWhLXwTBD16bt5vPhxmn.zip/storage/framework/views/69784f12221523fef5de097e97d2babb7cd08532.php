

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Lista de usuarios</span></h1>
		</section>

		
		<section class="form-search">
			<a href="<?php echo e(route('users.export')); ?>" class="btn" style="float: right; margin-left: 15px;">Exportar usuarios ( .CSV )</a>
			<a href="<?php echo e(route('users.import')); ?>" class="btn" style="float: right; margin-left: 15px;">Importar usuarios ( .CSV )</a>
			<form action="<?php echo e(route('users')); ?>" method="get" accept-charset="utf-8">
				<input type="text" name="buscar" value="<?php echo e($buscar); ?>" placeholder="Buscar..">
				<button type="submit" name="" value="" class="btn-buscar icon-search2"></button>
			</form>
		</section>
		

		<article>
			
			<section class="posiciones">
				
				<?php if(config('polla.groups')): ?>
					<h3 class="icon icon-user">Individual</h3>
				<?php endif; ?>
				<p>Puntos</p>
				
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position <?php echo e($user->position == 1 ? 'primero':''); ?>">
						<div class="circle">
							<div class="img">
								<img src="<?php if(strpos($user->avatar, 'https') === false): ?> <?php echo e(asset('/images/avatars')); ?>/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e($user->avatar); ?> <?php endif; ?>" alt="avatar">
							</div>

							<span class="in-circle"><?php echo e($user->position); ?></span>
						</div>
						<div class="pos-info">
							<span class="puntos"><?php echo e($user->points); ?></span>
							<span class="nombre-tabla">
								<a href="<?php echo e(route('users.edit', $user->id)); ?>" class="jugador"><?php echo e($user->name); ?><small style="font-size: 0.8rem"> (<?php echo e($user->email); ?>) </small></a>
								<?php if(config('polla.groups')): ?>
									<div class="grupo"><?php echo e($user->group->name); ?></div>
								<?php endif; ?>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
				<?php echo e($users->appends(['buscar' => $buscar])->links()); ?>

			</section>
				
		</article>

			<?php if(config('polla.groups')): ?>
				<aside>
					<section class="posiciones">
						<h3 class="icon icon-user-group">Grupal</h3>
						<p>Puntos</p>
						
						<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="position <?php if($group->position == 1): ?> primero 
								<?php elseif($group->position == 2): ?> segundo <?php elseif($group->position == 3): ?> tercero <?php endif; ?>">
								<div class="circle">
									<span class="pos-grupo"><?php echo e($group->position); ?></span>
								</div>
								<div class="pos-info">
									<span class="puntos"><?php echo e($group->points); ?></span>
									<span class="nombre-tabla"><?php echo e($group->name); ?></span>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</section>
					
				</aside>
				
			<?php endif; ?>

	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/users/all.blade.php ENDPATH**/ ?>