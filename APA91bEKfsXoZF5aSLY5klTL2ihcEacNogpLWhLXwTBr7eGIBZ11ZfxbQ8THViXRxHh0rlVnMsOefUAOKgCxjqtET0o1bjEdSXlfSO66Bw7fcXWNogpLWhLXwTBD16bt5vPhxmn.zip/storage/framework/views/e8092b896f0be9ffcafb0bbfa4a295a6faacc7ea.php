<table>
    <thead>
    <tr>
        <th><strong>Nombre</strong></th>
        <th><strong>Correo</strong></th>
        <th><strong>Puntos</strong></th>
        <th><strong>Posición</strong></th>
        <th><strong>Grupo</strong></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->points); ?></td>
            <td><?php echo e($user->position); ?></td>
            <td><?php echo e($user->group->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\wamp64\www\polla_america\resources\views/exports/users.blade.php ENDPATH**/ ?>