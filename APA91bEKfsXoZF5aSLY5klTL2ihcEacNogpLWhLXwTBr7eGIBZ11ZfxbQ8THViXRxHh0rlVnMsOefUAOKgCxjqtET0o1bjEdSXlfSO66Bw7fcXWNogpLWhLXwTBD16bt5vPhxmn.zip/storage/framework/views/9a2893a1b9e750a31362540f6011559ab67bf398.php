

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Instrucciones</span></h1>
			<h2>Cómo jugar</h2>
			<div class="editado">
				<iframe style="width: 100%; min-height: 500px;" src="https://www.youtube.com/embed/dweprOPWYw4" title="Cómo jugar" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</section>
		
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/instrucciones.blade.php ENDPATH**/ ?>