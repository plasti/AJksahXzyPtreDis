

<?php $__env->startSection('content'); ?>
<main>
	
	<section>

		<h1>¡Hola!</h1>
		<section class="acceso">
			
			<div class="btn-ingreso">
				<button type="button" class="btn btn-sesion">Inicia sesión</button>
				<?php if(config('polla.register')): ?>
					<button type="button" class="btn btn-register">Regístrate</button>
				<?php endif; ?>
			</div>

			<div class="form-login <?php echo e(old('email') ? ' open' : ''); ?>" style="display: block;">
				<div class="head-login">Acceder</div>
				<form action="<?php echo e(route('login')); ?>" method="POST" accept-charset="utf-8">
					<?php echo e(csrf_field()); ?>


					<div class="fila-form<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
						<label for="email">E-mail</label>
						<input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="ejemplo@correo.com">
						<?php if($errors->has('email')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('email')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
						<label for="password">Contraseña</label>
						<input type="password" name="password" id="password" placeholder="*******" required>
						<?php if($errors->has('password')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('password')); ?></strong>
							</span>
						<?php endif; ?>
					</div>


					<?php if(config('polla.login_redes')): ?>
						<div class="fila-form">
							<a href="register/google" class="btn-redes-login google">Continuar con Google</a>
							<a href="register/facebook" class="btn-redes-login facebook">Continuar con Facebook</a>
						</div>
					<?php endif; ?>


					<div class="remember">
						<input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
						<label for="remember">Recordarme</label>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Ingresar" class="btn">
					</div>

				</form>

				<div class="after-form-login">
					<p><a href="<?php echo e(route('password.request')); ?>">¿Olvidaste tu contraseña?</a></p>
					<p>¿No estás registrado? <a href="#" class="btn-register">Regístrate aquí</a></p>
				</div>

			</div> 

			<div class="form-register <?php echo e(old('name') ? ' open' : ''); ?>">
				<div class="head-login">Registrarse</div>					
				<form action="<?php echo e(route('register')); ?>" method="POST" accept-charset="utf-8">
					<?php echo e(csrf_field()); ?>


					
					<div class="fila-form<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name">Nombre</label>
						<input id="name" type="text" placeholder="Nombre" name="name" value="<?php echo e(old('name')); ?>" required>
						<?php if($errors->has('name')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('email-reg') ? ' has-error' : ''); ?>">
						<label for="email-reg">E-mail</label>
						<input name="email-reg" id="email-reg" type="email" placeholder="ejemplo@correo.com" value="<?php echo e(old('email-reg')); ?>" required>
						<?php if($errors->has('email-reg')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('email-reg')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					
					<div class="fila-form<?php echo e($errors->has('password-reg') ? ' has-error' : ''); ?>">
						<label for="password-reg">Contraseña</label>
						<input id="password-reg" type="password" name="password-reg" placeholder="********" required>
						<?php if($errors->has('password-reg')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('password-reg')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form">
						<label for="password-confirm">Confirmar contraseña</label>
						<input id="password-confirm" type="password" name="password-reg_confirmation" placeholder="********" required>
					</div>

					<?php if(config('polla.login_redes')): ?>
						<div class="fila-form">
							<a href="register/google" class="btn-redes-login google">Continuar con Google</a>
							<a href="register/facebook" class="btn-redes-login facebook">Continuar con Facebook</a>
						</div>
					<?php endif; ?>

					<?php if(config('polla.code_reg')): ?>
						<div class="fila-form<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
							<label for="code">Código</label>
							<input type="text" id="code" name="code" value="<?php echo e(old('code')); ?>" required>
							<?php if($errors->has('code')): ?>
								<span class="valida-msg">
									<strong><?php echo e($errors->first('code')); ?></strong>
								</span>
							<?php endif; ?>
						</div>
					<?php endif; ?>
					<?php if(!(config('polla.debug'))): ?>
						<?php echo app('captcha')->render(); ?>
					<?php endif; ?>

					<div class="<?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>">
						<?php if($errors->has('g-recaptcha-response')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('terms') ? ' has-error' : ''); ?>">
						<label for="terms">
							<input type="checkbox" name="terms" id="terms" <?php echo e(old('terms') ? 'checked' : ''); ?>>
							<span>Acepto los <a href="#" class="a-cond">términos y condiciones</a> y las <a href="#" class="a-poli">políticas de privacidad</a></span>
						</label>
						
						<?php if($errors->has('terms')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('terms')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Regístrate" class="btn">
					</div>
				</form>
			</div> 

			<div class="login-note">
				Si tienes incovenientes con el sistema puedes comunicarte al correo <a href="mailto:joe@example.com?subject=feedback">soporte@lapollamundial.com</a>
			</div>

			<?php echo $__env->make('layouts.partials.terminos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('layouts.partials.politicas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		</section>
	</section>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/auth/login.blade.php ENDPATH**/ ?>