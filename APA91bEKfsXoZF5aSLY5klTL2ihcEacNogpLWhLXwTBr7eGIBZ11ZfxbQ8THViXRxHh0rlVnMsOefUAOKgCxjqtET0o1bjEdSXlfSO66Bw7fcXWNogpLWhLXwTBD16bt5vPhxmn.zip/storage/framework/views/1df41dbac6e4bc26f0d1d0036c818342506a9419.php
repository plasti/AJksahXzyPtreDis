

<?php $__env->startSection('content'); ?>
	<main>
		<div class="bar-btns">
			<a href="<?php echo e(route('sliders.create')); ?>" class="btn">Nuevo slider</a>
		</div>
		<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e(route('sliders.edit', $slider->id)); ?>" class="slider-index <?php if($slider->status == 'No'): ?> diseable <?php endif; ?>">
				<img src="<?php echo e($slider->img()); ?>">
				<span><?php echo e($slider->name); ?></span>
			</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($sliders->links()); ?>

	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/sliders/index.blade.php ENDPATH**/ ?>