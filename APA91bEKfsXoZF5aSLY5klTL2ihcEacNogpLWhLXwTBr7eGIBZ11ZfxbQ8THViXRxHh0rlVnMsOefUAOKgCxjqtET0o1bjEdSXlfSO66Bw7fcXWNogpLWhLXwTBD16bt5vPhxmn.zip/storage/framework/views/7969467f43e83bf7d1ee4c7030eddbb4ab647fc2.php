

<?php $__env->startSection('content'); ?>
	<main>

		<div class="comentarios">
			
			<h2>Comentarios</h2>
			<div class="banner-partido">
				<div class="fecha-partido"><?php echo e(date_format(date_create($match->date_time), 'd/m/Y H:i')); ?> HS</div>
				<div class="detalles-partido-comentario">
					<div class="equipo-comentario">
						<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($match->team_a->flag); ?>" alt="Bandera <?php echo e($match->team_a->country); ?>">
						<span><?php echo e($match->team_a->country); ?></span>
						<span class="resultado-comentario"><?php echo e(($match->team_a->score_a != null) ? $match->team_a->score_a : '--'); ?></span>
					</div>
					<strong class="vs">VS</strong>
					<div class="equipo-comentario">
						<img src="<?php echo e(asset('/images/flags')); ?>/<?php echo e($match->team_b->flag); ?>" alt="Bandera <?php echo e($match->team_b->country); ?>">
						<span><?php echo e($match->team_b->country); ?></span>
						<span class="resultado-comentario"><?php echo e(($match->team_b->score_b != null) ? $match->team_b->score_b : '--'); ?></span>
					</div>
				</div>
			</div>
			<div class="body-comentarios">
				
				<div class="form-comentario">
					<textarea name="comentario" id="comentario" placeholder="Comentar.."></textarea>	
					<a href="#" url="<?php echo e(route('comentarios.store', $match->id)); ?>" class="comentar-btn">Comentar ></i></a>
				</div>

				<div id="comentarios-all">
					<?php if($match->comentarios->count() > 0): ?>
						<?php $__currentLoopData = $match->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="comentario" id="comentario_app_<?php echo e($comentario->id); ?>">
								<?php if($comentario->id_user == Auth::user()->id): ?>
									<span class="eliminar-comentario" title="Eliminar comentario" item="<?php echo e(route('comentarios.delete', $comentario->id)); ?>">x</span>
								<?php endif; ?>
								<div class="header-comentario">
									<div class="cintainer-avatar">
										<img src="<?php echo e($comentario->user->avatar()); ?>" alt="avatar">
									</div>
									<strong><?php echo e($comentario->user->name); ?></strong>
								</div>
								<div class="text"><?php echo e($comentario->text); ?></div>
								<span class="fecha"><?php echo e(date_format(date_create($comentario->created_at), 'd/m/Y H:i')); ?> HS</span>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<span class="nothing">No hay comentarios, sé el primero en comentar algo sobre este partido.</span>
					<?php endif; ?>

				</div>
			</div>
		</div>
	</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/comentarios.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/comentarios/show.blade.php ENDPATH**/ ?>