 <?php if(auth()->guard()->check()): ?>
    <?php
        $n = env('CHANNEL_PUSHER');
        $id_event = env('PUSHER_APP_ID_EVENT_'.$n);
    ?>
    <script src="<?php echo e(asset('js/notificaciones.js')); ?>"></script>
    <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
    <script>
        var pusher = new Pusher('<?php echo e($id_event); ?>', {cluster: 'us2'});
        var channel = pusher.subscribe('NotificacionesCanal');
        channel.bind('NotificacionesEvento', function(data) {
            Notificacion(data, '<?php echo e(Auth::user()->id); ?>');
        });
    </script>
<?php endif; ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/layouts/partials/notificaciones.blade.php ENDPATH**/ ?>