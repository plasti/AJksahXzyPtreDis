

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Nuevo slider</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(route('sliders.store')); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>


					<div class="fila-form<?php echo e($errors->has('img') ? ' has-error' : ''); ?>">
						<label for="img">Imagen ( Dimensiones 900 x 300 )</label>
						<input type="file" name="img" id="img">
						<?php if($errors->has('img')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('img')); ?></strong>
							</span>
						<?php endif; ?>
						<?php if($error_extension): ?>
							<span class="valida-msg">
								<strong>Solo se aceptan imágenes .jpg o .png</strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name">Nombre</label>
						<input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
						<?php if($errors->has('name')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('link') ? ' has-error' : ''); ?>">
						<label for="link">Enlace (opcional)</label>
						<input type="text" name="link" placeholder="https://" id="link" value="<?php echo e(old('link')); ?>">
						<?php if($errors->has('link')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('link')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
						<label for="status">Estado</label>
						<select name="status" id="status">
							<option value="">Seleccionar..</option>
							<option value="Si">Activo</option>
							<option value="No">Inactivo</option>
						</select>
						<?php if($errors->has('status')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('status')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/sliders/create.blade.php ENDPATH**/ ?>