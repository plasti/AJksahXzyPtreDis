

<?php $__env->startSection('content'); ?>
	<main>

		<div class="comentarios">
			
			<h2>Notificaciones</h2>
			<div class="body-comentarios">
				<div id="comentarios-all">
					<?php if($notificaciones->count() > 0): ?>
						<?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="<?php echo e($notificacion->link); ?>" class="comentario">
								<div class="header-comentario">
									<div class="cintainer-avatar" style="background-color: <?php echo e(config('polla.primario')); ?>">
										<img style="display: block; width: 36px; height: 36px;" src="<?php echo e($notificacion->icono()); ?>" alt="avatar">
									</div>
									<strong><?php echo e($notificacion->titulo); ?></strong>
								</div>
								<div class="text"><?php echo e($notificacion->descripcion); ?></div>
								<span class="fecha"><?php echo e(App\Plastimedia::parse_fecha($notificacion->created_at)); ?> HS</span>
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($notificaciones->links()); ?>

					<?php else: ?>
						<span class="nothing" style="font-size: 1.5rem; color: <?php echo e(config('polla.primario')); ?>">No tienes notificaciones aún.</span>
					<?php endif; ?>

				</div>
			</div>
		</div>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/notificaciones/index.blade.php ENDPATH**/ ?>