

<?php $__env->startSection('content'); ?>
	<main>

		<section class="text-center">
			<h1>Oops!</h1>
			<h2>La página que buscas no existe</h2>
		</section>
		
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/errors/404.blade.php ENDPATH**/ ?>