<?php if($trivia != null): ?>
	<div class="trivia-letrero">
		<h2><?php echo e($trivia->titulo); ?></h2>
		<div class="spanes">
			<span>Pueder ganar hasta <?php echo e($trivia->getPuntos()); ?> puntos</span>
			<span>En total son <?php echo e($trivia->preguntas->count()); ?> preguntas</span>
		</div>
		<a href="<?php echo e(route('trivia.comenzar', $trivia->id)); ?>" class="btn">¡Realizar trivia!</a>
	</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\polla_app\resources\views/partidos/partials/trivia.blade.php ENDPATH**/ ?>