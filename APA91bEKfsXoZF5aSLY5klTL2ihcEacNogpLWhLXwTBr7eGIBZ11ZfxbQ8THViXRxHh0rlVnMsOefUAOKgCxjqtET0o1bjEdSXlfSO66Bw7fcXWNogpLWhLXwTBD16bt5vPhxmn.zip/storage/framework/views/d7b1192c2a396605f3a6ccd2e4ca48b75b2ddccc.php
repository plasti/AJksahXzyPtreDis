

<?php $__env->startSection('content'); ?>
	<main>
		<section>
			<h1 style="margin: 0;"><span><?php echo e($trivia->titulo); ?></span></h1>
		</section>
		<div class="contador-modal"><span></span></div>

		<div id="cards-trivias">
			<?php $__currentLoopData = $trivia->preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($pregunta->respuesta(Auth::user()->id) == null): ?>
					<div class="card-trivia" item="<?php echo e($pregunta->id); ?>" time="<?php echo e($pregunta->tiempo); ?>" id="trivia_<?php echo e($pregunta->id); ?>">
						<?php if($pregunta->imagen != null): ?>
							<div class="container-img">
								<img src="<?php echo e($pregunta->imagen()); ?>" alt="">
							</div>
						<?php endif; ?>
						<p><?php echo e($pregunta->pregunta); ?></p>
						<span class="time icon-clock" id="clock_<?php echo e($pregunta->id); ?>"><?php echo e($pregunta->tiempo); ?> Segundos</span>
						<div class="progreso"><span id="bar_<?php echo e($pregunta->id); ?>"></span></div>
						<div class="respuestas">
							<a class="A" item="<?php echo e($pregunta->id); ?>" id="selecet_respuesta" href="#">
								<span>A</span> <?php echo e($pregunta->opcion_a); ?>

							</a>
							<a class="B" item="<?php echo e($pregunta->id); ?>" id="selecet_respuesta" href="#">
								<span>B</span> <?php echo e($pregunta->opcion_b); ?>

							</a>
							<a class="C" item="<?php echo e($pregunta->id); ?>" id="selecet_respuesta" href="#">
								<span>C</span> <?php echo e($pregunta->opcion_c); ?>

							</a>
							<a class="D" item="<?php echo e($pregunta->id); ?>" id="selecet_respuesta" href="#">
								<span>D</span> <?php echo e($pregunta->opcion_d); ?>

							</a>
						</div>
					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</main>
	
	<div class="mensaje-trivia">
	</div>

	<div class="modal-loader"><span></span></div>
	<?php echo $__env->make('trivias.partials.confeti', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<input type="hidden" id="ruta_respuesta" value="<?php echo e(route('trivia.respuesta')); ?>">
	<input type="hidden" id="ruta_fin" value="<?php echo e(route('trivia.calcular')); ?>">
	<?php echo e(csrf_field()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/trivia.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/trivias/play.blade.php ENDPATH**/ ?>