

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Tabla de posiciones</span></h1>
		</section>

		

		<article>
			
			<section class="posiciones">
				
				<?php if(config('polla.groups')): ?>
					<h3 class="icon icon-user">Individual</h3>
				<?php endif; ?>
				<p>Puntos</p>
				
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="position <?php echo e($user->position == 1 ? 'primero':''); ?>">
						<div class="circle">
							<div class="img">
								<img src="<?php if(strpos($user->avatar, 'https') === false): ?> <?php echo e(asset('/images/avatars')); ?>/<?php echo e($user->avatar); ?> <?php else: ?> <?php echo e($user->avatar); ?> <?php endif; ?>" alt="avatar">
							</div>

							<span class="in-circle"><?php echo e($user->position); ?></span>
						</div>
						<div class="pos-info">
							<span class="puntos"><?php echo e($user->points); ?></span>
							<span class="nombre-tabla">
								<div class="jugador"><?php echo e($user->name); ?></div>
								<?php if(config('polla.groups')): ?>
									<div class="grupo"><?php echo e($user->group->name); ?></div>
								<?php endif; ?>
							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
				<?php echo e($users->links()); ?>

			</section>
				
		</article>

			<?php if(config('polla.groups')): ?>
				<aside>
					<section class="posiciones">
						<h3 class="icon icon-user-group">Grupal</h3>
						<p>Puntos</p>
						
						<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="position <?php if($group->position == 1): ?> primero 
								<?php elseif($group->position == 2): ?> segundo <?php elseif($group->position == 3): ?> tercero <?php endif; ?>">
								<div class="circle">
									<span class="pos-grupo"><?php echo e($group->position); ?></span>
								</div>
								<div class="pos-info">
									<span class="puntos"><?php echo e($group->points); ?></span>
									<span class="nombre-tabla"><?php echo e($group->name); ?></span>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</section>
					
				</aside>
				
			<?php endif; ?>

	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/posiciones/index.blade.php ENDPATH**/ ?>