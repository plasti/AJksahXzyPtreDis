

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Configuración</span></h1>

			<section class="form-edit">
				<form action="<?php echo e(route('users.update', $user->id)); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<div class="avatar-edit">
						<img src="<?php echo e($user->avatar()); ?>" alt="avatar">
					</div>

					<div class="fila-form<?php echo e($errors->has('avatar') ? ' has-error' : ''); ?>">
						<label for="avatar">Cambiar imagen de perfil</label>
						<input type="file" name="avatar" id="avatar">
						<?php if($errors->has('avatar')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('avatar')); ?></strong>
							</span>
						<?php endif; ?>
						<?php if($error_extension): ?>
							<span class="valida-msg">
								<strong>Solo se aceptan imágenes .jpg o .png</strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name">Nombre</label>
						<input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>">
						<?php if($errors->has('name')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
						<label for="password">Contraseña</label>
						<input id="password" type="password" name="password" placeholder="*********">
						<?php if($errors->has('password')): ?>
							<span class="valida-msg">
								<strong><?php echo e($errors->first('password')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="fila-form">
						<label for="password-confirm">Confirmar contraseña</label>
						<input id="password-confirm" type="password" name="password_confirmation" placeholder="*********">
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

			<?php if(config('polla.medals')): ?>
				<section class="logros">
					<h2 class="icon-trophy">Logros</h2>
					<div class="lista-logros">
						<?php $__currentLoopData = $user->medals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="logro">
								<div class="name">
									<div class="img-premio">
										<img src="<?php echo e($medal->medal->img()); ?>">
									</div>
									<strong><?php echo e($medal->medal->name); ?></strong>
								</div>
								<strong><?php echo e(App\Plastimedia::parse_fecha($medal->created_at)); ?></strong>
								<?php if($medal->delivered == 1): ?>
									<p>Redimido - <?php echo e(App\Plastimedia::parse_fecha($medal->updated_at)); ?></p>
								<?php else: ?>
									<a href="<?php echo e(route('medals.redimir', $medal->id.'-'.$user->id )); ?>" class="btn">Redimir premio</a>
								<?php endif; ?>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</section>
			<?php endif; ?>

		</section>

	</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/users/edit.blade.php ENDPATH**/ ?>