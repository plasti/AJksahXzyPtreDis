<?php 
// Array de configuracion
// ---------------------
return [
	'id' => 'polla_america_pruebas', // id para las notificaciones de cada polla
	'name' => 'Demo', //-> nombre que aparecera en la app
	'register' => true, // -> registro de usuarios
	'code_reg' => false, // -> si requiere un codigo para poder registrarse
	'code_section' => true, // -> si tiene seccion de codigos para acumular puntos
	'groups' => true, // -> si se juega por grupos 
	'widget' => true,
	'slider' => true, // -> si cuenta con slider para pautas y promociones dentro de la app
	'trivia' => true, // -> si cuenta con trivia
	'users_admin' => true, // -> si cuenta con administracion de usuarios
	'login_redes' => true, // -> si cuenta con login con rede sociales
	'app_mobile' => true, // -> si cuenta con app mobile
	'debug' => false,
	'primario' => '#eec211', // -> color para la aplicación mobile
	'secundario' => '#001f26', // -> color para la aplicación mobile
	'terciario' => '#de0209', // -> color para la aplicación mobile

	// --------------------------
	
	'code_points' => 3, // -> puntos por cada codigo que registr en la seccion de codigos
	'callback_facebook' => 'https://demo.lapollaamerica.com/register/callback-facebook',
	'callback_google' => 'https://demo.lapollaamerica.com/register/callback-google',
	'ruta_madre' => 'http://plastimedia.com/polla_madre/public/xml/example.xml', // -> ruta madre
	'url_tutorial_app' => 'https://demo.lapollaamerica.com/instruciones',
	'url_soporte' => 'https://demo.lapollaamerica.com',
	'medals' => true,
	'horas_diferencia' => 0,
	'premios' => [
		[
			'img' => 'premio-1.jpg',
			'titulo' => '1° Puesto',
			'descripcion' => 'Viaje para 2 personas a Europa',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
		[
			'img' => 'premio-2.jpg',
			'titulo' => '2° Puesto',
			'descripcion' => 'LED Full HD de 49 pulgadas',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
		[
			'img' => 'premio-3.jpg',
			'titulo' => '3° Puesto',
			'descripcion' => 'Celular Huawei P9',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
		[
			'img' => 'premio-3.jpg',
			'titulo' => '4° Puesto',
			'descripcion' => 'Celular apple P9',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
	],

	// canal 0
	// -----------------------
	// los accesos para administrar las cuentas de pusher
	// url: https://pusher.com
	// ----------------------

	// canal 1
	// user: soporte@lapollamundial.com
	// pass: plasti249

	// canal 2
	// user: contacto@lapollamundial.com
	// pass: plasti249

	// canal 3
	// user: ssl1@plastimedia.com
	// pass: plasti249

	// canal 4
	// user: ssl2@plastimedia.com
	// pass: plasti249

	// canal 5
	// user: ssl4@plastimedia.com
	// pass: plasti249
	// -------------------
];

?>