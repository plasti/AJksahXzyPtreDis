<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Code_app;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::get('get-polla', function()
{
	$objet = [
		'name' => config('polla.name'),
		'generated' => "polla",
		'primary' => config('polla.primario'),
		'secondary' => config('polla.secundario'),
		'tertiary' => config('polla.terciario'),
		'background' => asset('images/campo768.jpg'),
		'logo' => asset('images/logo.png'),
		'host' => $_SERVER['SERVER_NAME'],
		'register' => config('polla.register'),
		'login_redes' => config('polla.login_redes'),
		'grupos' => config('polla.groups'),
		'trivia' => config('polla.trivia'),
		'url_tutorial_app' => config('polla.url_tutorial_app'),
	];
	return response()->json($objet);
});

Route::post('set-polla-code', function(Request $request){
	$c = Code_app::find(1);
	if ($c != null) {
		$c->code = $request->code;
		$c->update();
	}else {
		$c = Code_app::create([
			'code' => $request->code,
		]);
	}
	return response()->json('Ok');
});



// login
Route::post('login', 'UserApiController@login');
Route::post('auth-social', 'UserApiController@authsocial');


// profile
Route::post('profile', 'UserApiController@profile');
Route::post('update-profile', 'UserApiController@update_profile');

// notificaciones
// ---
Route::post('get-notificaciones', 'NotificacionesApiController@index');
Route::post('set-token-notification', 'NotificacionesApiController@set_token');

// positions
Route::get('positions', 'PositionsApiController@positions');
Route::post('get-predictions', 'PositionsApiController@predictions');
Route::post('get-predictions-group', 'PositionsApiController@predictions_group');

// home
// ----
Route::post('get-home', 'MatchApiController@index');
Route::post('get-predictions-grupo', 'MatchApiController@index_grupo');

// set marcador
// -------------
Route::post('set-marcador', 'PredictionApiController@store');

// comentarios
Route::post('get-comentarios', 'ComentariosApiController@index');
Route::post('store-comentarios', 'ComentariosApiController@store');
Route::post('delete-comentario', 'ComentariosApiController@delete');
Route::post('get-match', 'ComentariosApiController@get_match');

// plan de premios
Route::get('premios', 'PremiosApiController@index');
Route::post('mine-premios', 'PremiosApiController@premios_user');

// trivia
Route::post('get-trivia', 'TriviaApiController@index');
Route::post('respuestas-store', 'TriviaApiController@store');