<?php

use App\Plastimedia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('prueba', function (){
	$data = [
		'id' => 1,
		'icono' => 'sube.png',
		'title' => 'Nueva notificacion',
		'content' => 'Notificacion de ejemplo',
		'link' => '#',
		'type' => ['type' => 'comentario'],
		'token' => 'dpWikuGaU0AzjkvfHeIslJ:APA91bFJsqjQRbxX3wAAuVHwTm59hw7w8svAva2tEJqaG1Hkx8A_O0jHH1lgx2QJXxpGsBNQwTLR2H5eQGbL5kAUVBqBL_nEiYA0KddHm71nSsYinb6qCO5zybbNKXujvyHs_r4DU-gO'
	];
	Plastimedia::notificar($data);
});

// codigo qr
Route::get('app/mobile', function()
{
	if (config('polla.app_mobile')) {
        return view('appmobile');
    }else {
        return redirect('/')->with('status', 'Url no encontrada.');
    }
});

//Auth::routes();
// Authentication Routes...
Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('login', 'Auth\LoginController@login');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
// Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
Route::get('register', 'Auth\LoginController@showLoginForm')->name('register');
Route::post('register', 'Auth\RegisterController@register')->name('register');

//registro con redes sociales
// facebook
Route::get('register/facebook', 'Auth\RegisterController@redirectToProvider')->name('register.facebook');
Route::get('register/callback-facebook', 'Auth\RegisterController@CallbackFacebook')->name('register.callbackfacebook');
// google
Route::get('register/google', 'Auth\RegisterController@redirectToProviderGoogle')->name('register.google');
Route::get('register/callback-google', 'Auth\RegisterController@CallbackGoogle')->name('register.callbackgoogle');
// twitter
Route::get('register/twitter', 'Auth\RegisterController@redirectToProviderTwitter')->name('register.twitter');
Route::get('register/callback-twitter', 'Auth\RegisterController@CallbackTwitter')->name('register.callbacktwitter');

// Password Reset Routes...
Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset');

Route::get('update-match', 'PointsController@import');

// Rutas de los puntos
Route::post('user-predictions', 'PointsController@predictionPoints');
Route::post('user-points', 'PointsController@allUserPoints');
Route::post('user-positions', 'PointsController@userPositions');
Route::post('group-predictions', 'PointsController@predictionGroupPoints');
Route::post('group-points', 'PointsController@groupPoints');
Route::post('group-positions', 'PointsController@groupPositions');
// Para actualizar el partido a ya acttualizado
Route::post('match/update', 'MatchController@update');


// Rutas varias
Route::get('instrucciones', function(){ return view('instrucciones'); });
Route::get('plan-premios', function(){ return view('plan-premios'); });
Route::get('la-polla', function(){ return view('la-polla'); });

// Rutas protegidas +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Route::group(['middleware' => 'auth'], function () {	
	
	// Rutas de los partidos
	Route::get('/', 'MatchController@index');
	Route::get('/partidos', 'MatchController@index')->name('partidos');
	Route::get('/home', 'MatchController@index');

	// Rutas de los grupos
	Route::get('grupo', 'GroupController@index')->name('group.index');
	
	// Rutas del perfil
	Route::get('configuracion', 'UserController@profile');
	Route::post('configuracion', 'UserController@update_profile');
	Route::get('perfil', 'UserController@index')->name('perfil');

	// Rutas de las posiciones
	Route::get('posiciones', 'PositionController@index')->name('posiciones');

	// Rutas de las predicciones
	Route::post('predictions', 'PredictionController@store')->name('prediction.store');
	Route::post('predictions-group', 'PredictionController@storeGroup')->name('grupo.store');

	// Ruta de los códigos
	Route::get('codes', 'CodeController@index');
	Route::post('codes', 'CodeController@store');

	// Ruta de comentarios
	Route::get('comentarios/{id}/partido', 'ComentariosController@show')->name('comentarios');
	Route::get('comentarios/{id}/comentar', 'ComentariosController@store')->name('comentarios.store');
	Route::get('comentarios/{id}/delete', 'ComentariosController@delete')->name('comentarios.delete');

	// Ruta de marcadores
	Route::get('marcadores/{id}/partido', 'PredictionController@marcadores')->name('marcadores');

	// Rutas para la trivia
	Route::get('trivia/{id}/comenzar', 'TriviasController@comenzar')->name('trivia.comenzar');
	Route::get('trivia/{id}/play', 'TriviasController@play')->name('trivia.play');
	Route::post('trivia/respuesta', 'TriviasController@respuesta')->name('trivia.respuesta');
	Route::get('trivia/calcular', 'TriviasController@calcular_trivia')->name('trivia.calcular');

	// Ruta de notificaciones
	Route::get('notificaciones', 'NotificacionesController@index')->name('notificaciones');

	Route::group(['middleware' => 'admin'], function () {
		// Ruta de los usuarios
		Route::get('users', 'UserController@all_users')->name('users');
		Route::get('users/create', 'UserController@create')->name('users.create');
		Route::post('users/store', 'UserController@store')->name('users.store');
		Route::get('users/{id}/edit', 'UserController@edit_user')->name('users.edit');
		Route::post('users/{id}/update', 'UserController@update_user')->name('users.update');
		Route::get('users/export', 'UserController@export')->name('users.export');
		Route::get('users/import', 'UserController@import')->name('users.import');
		Route::post('users/import', 'UserController@import_file')->name('users.import.file');
		Route::get('users/how-import', 'UserController@how_import')->name('users.import.how');

		// grupos
		Route::get('groups', 'GroupController@all_groups')->name('groups');

		// Ruta de los sliders
		Route::get('sliders', 'SliderController@index')->name('sliders');
		Route::get('sliders/create', 'SliderController@create')->name('sliders.create');
		Route::post('sliders/store', 'SliderController@store')->name('sliders.store');
		Route::get('sliders/{id}/edit', 'SliderController@edit')->name('sliders.edit');
		Route::post('sliders/{id}/update', 'SliderController@update')->name('sliders.update');
		Route::get('sliders/{id}/delete', 'SliderController@delete')->name('sliders.delete');

		// Ruta de los codigos
		Route::get('codes/admin', 'CodeController@index_admin')->name('codes.admin');
		Route::get('codes/import', 'CodeController@import')->name('codes.admin.import');
		Route::get('codes/how-import', 'CodeController@how_import')->name('codes.admin.howimport');
		Route::post('codes/import/file', 'CodeController@import_file')->name('codes.admin.import.file');
		Route::get('codes/{id}/delete', 'CodeController@delete_admin')->name('codes.admin.delete');

		// Ruta de los trivias
		Route::get('trivias', 'TriviasController@index')->name('trivias');
		Route::get('trivias/create', 'TriviasController@create')->name('trivias.create');
		Route::post('trivias/store', 'TriviasController@store')->name('trivias.store');
		Route::get('trivias/{id}/edit', 'TriviasController@edit')->name('trivias.edit');
		Route::post('trivias/{id}/update', 'TriviasController@update')->name('trivias.update');
		// Route::get('trivias/{id}/delete', 'TriviasController@delete')->name('trivias.delete');

		// Rutas para las preguntas de una trivia
		Route::get('preguntas/{id}/create', 'PreguntasController@create')->name('preguntas.create');
		Route::post('preguntas/{id}/store', 'PreguntasController@store')->name('preguntas.store');
		Route::get('preguntas/{id}/edit', 'PreguntasController@edit')->name('preguntas.edit');
		Route::post('preguntas/{id}/update', 'PreguntasController@update')->name('preguntas.update');
		Route::get('preguntas/{id}/delete', 'PreguntasController@delete')->name('preguntas.delete');

		// Rutas para el widget
		Route::get('widget/edit', 'WidgetController@edit')->name('widget.edit');
		Route::post('widget/update', 'WidgetController@update')->name('widget.update');

		// ruta para los premios
		Route::get('medals/index', 'MedalsController@index')->name('medals');
		Route::get('medals/create', 'MedalsController@create')->name('medals.create');
		Route::post('medals/store', 'MedalsController@store')->name('medals.store');
		Route::get('medals/{id}/edit', 'MedalsController@edit')->name('medals.edit');
		Route::post('medals/{id}/update', 'MedalsController@update')->name('medals.update');
		Route::get('medals/{id}/delete', 'MedalsController@delete')->name('medals.delete');
		Route::get('medals/{id}/calcular-ganadores', 'MedalsController@calcular')->name('medals.calcular');
		Route::get('medals/{id}/redimir', 'MedalsController@redimir')->name('medals.redimir');

	});

});
