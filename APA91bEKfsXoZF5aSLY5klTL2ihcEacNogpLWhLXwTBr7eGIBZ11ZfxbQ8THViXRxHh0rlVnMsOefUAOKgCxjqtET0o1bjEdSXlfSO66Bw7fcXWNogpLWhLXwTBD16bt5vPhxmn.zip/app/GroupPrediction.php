<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupPrediction extends Model
{
	protected $table = 'group_predictions';

	protected $fillable = [
		'group_id',
		'match_id',
		'a_score',
		'b_score',
		'points',
	];

	/**
	* Obtiene la info del partido
	*/
	public function match()
	{
		return $this->belongsTo('App\Match', 'match_id');
	}

}
