<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPrediction extends Model
{
	protected $table = 'user_predictions';

	protected $fillable = [
		'user_id',
		'match_id',
		'a_score',
		'b_score',
		'points',
	];

	/**
	* Obtiene la info del partido
	*/
	public function match()
	{
		return $this->hasOne('App\Match', 'match_id');
	}

	public function user()
	{
		return $this->belongsTo('App\User', 'user_id');
	}

}
