<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Notificaciones;
use App\Events\NotificacionPush;

class Plastimedia extends Model
{
    public static function sendmail($data, $html)
    {
        $payload = [
            'api_key' => 'apikey_b62468ba7fdtt78f8h4t2f15s54at5hb1fr',
            'email_from' => 'marinillaemprende@gmail.com',
            'name_from' => 'Marinilla City',
            'email_to' => $data['email'],
            'name_to' => $data['name'],
            'subject' => $data['asunto'],
            'type' => 'html',
            'message' => $html
        ];
        $c = curl_init();
        curl_setopt($c, CURLOPT_URL, "http://api.plastimedia.com/api/mail/send");
        curl_setopt($c, CURLOPT_POST, 1);
        curl_setopt($c, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($c, CURLOPT_RETURNTRANSFER , 1);
        $result = curl_exec($c);
        $result = json_decode($result);
        return $result; 
    }

    public static function oscurece_color($color,$cant){
        //voy a extraer las tres partes del color
        $rojo = substr($color,1,2);
        $verd = substr($color,3,2);
        $azul = substr($color,5,2);

        //voy a convertir a enteros los string, que tengo en hexadecimal
        $introjo = hexdec($rojo);
        $intverd = hexdec($verd);
        $intazul = hexdec($azul);

        //ahora verifico que no quede como negativo y resto
        if($introjo-$cant>=0) $introjo = $introjo-$cant;
        if($intverd-$cant>=0) $intverd = $intverd-$cant;
        if($intazul-$cant>=0) $intazul = $intazul-$cant;

        //voy a convertir a hexadecimal, lo que tengo en enteros
        $rojo = dechex($introjo);
        $verd = dechex($intverd);
        $azul = dechex($intazul);

        //voy a validar que los string hexadecimales tengan dos caracteres
        if(strlen($rojo)<2) $rojo = "0".$rojo;
        if(strlen($verd)<2) $verd = "0".$verd;
        if(strlen($azul)<2) $azul = "0".$azul;

        //voy a construir el color hexadecimal
        $oscuridad = "#".$rojo.$verd.$azul;

        //la función devuelve el valor del color hexadecimal resultante
        return $oscuridad;
    }

    public static function parse_fecha($f)
    {   
        $mes = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
        return $mes[date_format(date_create($f), 'm') - 1].' '.date_format(date_create($f), 'd').' de '.date_format(date_create($f), 'Y').' a las '. date_format(date_create($f), 'H:i');
    }

    public static function parse_fecha2($f)
    {   
        return date_format(date_create($f), 'Y/m/d');
    }

    public static function parse_hora($f)
    {   
        return date_format(date_create($f), 'H:i');
    }

    public static function notificar($data)
    {   
        Notificaciones::create([
            'id_user' => $data['id'],
            'titulo' => $data['title'],
            'descripcion' => $data['content'],
            'link' => $data['link'],
            'icono' => $data['icono'],
            'estado' => 'Nueva',
            'data' => (isset($data['data'])) ? $data['data'] : null,
        ]);
        event(new NotificacionPush([
            'id_polla' => config('polla.id'),
            'id_user' => $data['id'],
            'icono' => $data['icono'],
            'titulo' => $data['title'],
            'descripcion' => $data['content'],
            'link' => $data['link'],
        ]));

        if (isset($data['token'])) {
            if ($data['token'] != null) {
                Plastimedia::sendAndroidNotifications(
                    $data['token'],
                    $data['content'],
                    $data['title'],
                    $data['type'],
                    asset('images/banner_notificacion.png')
                );
                Plastimedia::sendIosNotification(
                    $data['token'],
                    $data['content'],
                    $data['title'],
                    $data['type'],
                    asset('images/banner_notificacion.png')
                );
            }
        }

    }

    public static function check_notificaciones($id){
        $n = Notificaciones::where('estado', '<>', null)->where('id_user', $id)->count();
        return $n > 0;
    }

    public static function sendIosNotification($token, $message, $title, $data = null, $imagen = null) {
        $key = 'AAAA8R9mTqQ:APA91bF4m34RT66yQN1KK3J2TtyiV7FrpTifyCdGIzuwCfFFNPKNNiIaYzREpKrlGvqYw_c8ThjD8AS5RsxOBVgQl-RK-9AZg1TPsgpuK8Ul1lkkrK1hl_hLti8G54KSZyTzC92YQG7T';
        $ch = curl_init("https://fcm.googleapis.com/fcm/send");

        $m = [
            "message" =>  [
                "token"  => $token,
                "notification"  => [
                    "body"  => "This is an FCM notification that displays an image.!",
                    "title"  => "FCM Notification",
                ],
                "apns" => [
                    "headers" => [
                        "apns-priority"=> "5",
                    ],
                    "payload" => [
                        "aps" => [
                            "mutable-content" => 1
                        ]
                    ],
                ],
                "fcm_options" => [
                    "image" => $imagen
                ]
            ]
        ];




        // $notification = array('title' =>$title , 'text' => $message);
        // $arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high', 'data' => $data);
        // $json = json_encode($arrayToSend);
        $json = json_encode($m);
        $headers = [
            'Content-Type: application/json',
            "Authorization: key=$key"
        ];
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);       
        $response = curl_exec($ch);
        dd(curl_error($ch));
        curl_close($ch);
    }

    public static function sendAndroidNotifications($token, $message, $title, $data = null, $imagen = null)
    {
        $api_key = 'AAAA8R9mTqQ:APA91bF4m34RT66yQN1KK3J2TtyiV7FrpTifyCdGIzuwCfFFNPKNNiIaYzREpKrlGvqYw_c8ThjD8AS5RsxOBVgQl-RK-9AZg1TPsgpuK8Ul1lkkrK1hl_hLti8G54KSZyTzC92YQG7T';
        $fcmUrl = 'https://fcm.googleapis.com/fcm/send';

        if ($imagen != null) {
            $notification = [
                "title" => $title,
                "body" => $message,
                "image" => $imagen,
            ];
        }else {
            $notification = [
                "title" => $title,
                "body" => $message,
            ];
        }


        $fcmNotification = [
            'to' => $token,
            'notification' => $notification,
            'data' => $data,
        ];
        $headers = [ 
            'Authorization: key='.$api_key,
            'Content-Type: application/json'
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$fcmUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}
