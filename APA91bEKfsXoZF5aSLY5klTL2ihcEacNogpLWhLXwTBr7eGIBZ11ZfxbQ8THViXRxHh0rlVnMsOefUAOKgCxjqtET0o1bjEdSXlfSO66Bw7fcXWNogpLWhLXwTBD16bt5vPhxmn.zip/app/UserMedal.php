<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserMedal extends Model
{
	protected $table = 'user_medals';

	protected $fillable = [
		'user_id',
		'medal_id',
		'delivered',
	];

	/**
	* Obtiene la información de la medalla
	*/
	public function medal()
	{
		return $this->belongsTo('App\Medal', 'medal_id');
	}

	public function user()
	{
		return $this->belongsTo('App\User', 'user_id');
	}
}
