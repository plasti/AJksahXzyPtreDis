<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
	protected $table = 'sliders';

	protected $fillable = [
		'name',
		'img',
		'status',
		'link',
	];
	public function img()
	{
		return asset('images/sliders').'/'.$this->img;
	}
}