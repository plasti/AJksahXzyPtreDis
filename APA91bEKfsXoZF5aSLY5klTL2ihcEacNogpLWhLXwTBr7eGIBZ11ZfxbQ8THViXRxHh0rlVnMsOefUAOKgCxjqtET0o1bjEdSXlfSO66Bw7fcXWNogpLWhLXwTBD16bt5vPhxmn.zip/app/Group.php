<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
	protected $table = 'groups';

	protected $fillable = [
		'name',
		'points',
		'position',
	];

	/**
	* Obtiene una lista de los usuarios que pertenecen a un grupo
	*/
	public function users()
	{
		return $this->hasMany('App\User', 'group_id');
	}

	/**
	* Obtiene la lista de las predicciones del grupo
	*/
	public function predictions()
	{
		return $this->hasMany('App\GroupPrediction', 'group_id');
	}

}
