<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notificaciones extends Model
{

	protected $table = 'notificaciones';

	protected $fillable = [
		'id_user',
		'titulo',
		'descripcion',
		'data',
		'link',
		'estado',
		'icono',
	];

	/**
	* Obtiene la información del usuario.
	*/
	public function fecha()
	{
		$mes = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
        $m = $mes[date_format(date_create($this->created_at), 'm') - 1];
        $d = date_format(date_create($this->created_at), 'd');
	    $y = date_format(date_create($this->created_at), 'Y');
        $h = date_format(date_create($this->created_at), 'g A');
		return $m.' '.$d.' del '.$y.' - '.$h;
	}

	public function user()
	{
		return $this->belongsTo('App\User', 'id_user');
	}

	public function icono()
	{
		return asset('images/notificaciones').'/'.$this->icono;
	}

}
