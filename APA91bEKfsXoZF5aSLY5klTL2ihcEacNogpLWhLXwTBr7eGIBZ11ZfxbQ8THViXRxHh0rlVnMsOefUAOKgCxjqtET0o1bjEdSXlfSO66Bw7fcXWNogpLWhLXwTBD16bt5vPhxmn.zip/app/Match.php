<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;
use DateTimeZone;
use DateTime;

class Match extends Model
{
	protected $table = 'matchs';

	protected $fillable = [
		'team_id_a',
		'score_a',
		'team_id_b',
		'score_b',
		'date_time',
		'date_zone',
		'updated',
	];

	/**
	* Obtiene la información del equipo A.
	*/
	public function team_a()
	{
		return $this->belongsTo('App\Team', 'team_id_a');
	}

	/**
	* Obtiene la información del equipo B.
	*/
	public function team_b()
	{
		return $this->belongsTo('App\Team', 'team_id_b');
	}

	/**
	* Obtiene las predicciones de los usuarios de un partido.
	*/
	public function predictions()
	{
		return $this->hasMany('App\UserPrediction', 'match_id');
	}

	/**
	* Obtiene las predicciones de los grupos de un partido.
	*/
	public function groupPredictions()
	{
		return $this->hasMany('App\GroupPrediction', 'match_id');
	}

	public function comentarios()
	{
		return $this->hasMany('App\Comentarios', 'id_match')->orderBy('id', 'DESC');
	}

	public function data_country()
	{
		$t = new DateTimeZone('UTC');
		$time_partido = new DateTime($this->date_time.' '.$this->date_zone);
		$time_partido->setTimezone($t);
		$time_cliente = $time_partido;
		$tt = new DateTimeZone(config('app.timezone'));
		$time_cliente->setTimezone($tt);
		return $time_cliente->format('Y-m-d H:i:s');
	}

}
