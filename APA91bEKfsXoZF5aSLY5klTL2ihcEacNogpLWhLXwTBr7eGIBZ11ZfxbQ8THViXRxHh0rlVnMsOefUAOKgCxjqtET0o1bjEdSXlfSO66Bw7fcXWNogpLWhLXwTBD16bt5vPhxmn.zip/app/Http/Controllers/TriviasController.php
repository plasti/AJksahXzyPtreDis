<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Plastimedia;
use App\Trivia;
use App\Pregunta;
use App\Pregunta_usuario;
use App\User;
use Auth;
use Image;
use DB;


class TriviasController extends PointsController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $trivias = Trivia::orderBy('id', 'DESC')->paginate(20);
        return view('trivias.index', ['trivias' => $trivias]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('trivias.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'titulo' => 'required|max:250',
        ], [
            'titulo.required' => 'Ingresa el titulo de la trivia',
            'titulo.max' => 'El titulo de la trivia no debe superar los 250 caracteres',
        ]);

        $trivia = Trivia::create([
            'titulo' => $request->titulo,
            'objetivo' => $request->objetivo,
            'estado' => 'Inactiva',
        ]);
        return redirect('trivias/'.$trivia->id.'/edit')
        ->with('status', 'Trivia creada, ahora puedes caracterizar las preguntas')
        ->with('class', 'succes');
    }

   
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $trivia = Trivia::find($id);
        return view('trivias.edit', ['trivia' => $trivia]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'titulo' => 'required|max:250',
        ], [
            'titulo.required' => 'Ingresa el titulo de la trivia',
            'titulo.max' => 'El titulo de la trivia no debe superar los 250 caracteres',
        ]);
        
        if ($request->estado == 'Activa') {
            $others = Trivia::where('estado', 'Activa')->get();
            foreach ($others as $other) {
                $other->estado = 'Inactiva';
                $other->update();
            }
        }
        
        $trivia = Trivia::find($id);
        $trivia->titulo = $request->titulo;
        $trivia->objetivo = $request->objetivo;
        $trivia->estado = $request->estado;
        $trivia->update();

        if ($trivia->estado == 'Activa') {
            $users = User::select('id', 'token_push')->get();
            foreach ($users as $user) {
                Plastimedia::notificar([
                    'id' => $user->id,
                    'icono' => 'trivia.png',
                    'title' => $trivia->titulo.' ya esta disponible',
                    'content' => $trivia->objetivo,
                    'link' => route('trivia.comenzar', $trivia->id),
                    'type' => ['type' => 'trivia'],
                    'token' => $user->token_push
                ]);
            }
        }



        return redirect('trivias')
        ->with('status', 'Trivia actualizada')
        ->with('class', 'succes');
    }

    
    public function comenzar($id)
    {
        $trivia = Trivia::find($id);
        return view('trivias.comenzar', ['trivia' => $trivia]);
    }

    public function play($id)
    {
        $trivia = Trivia::find($id);
        $total_preguntas = 0;
        foreach ($trivia->preguntas as $p) {
            $total_preguntas += ($p->respuesta(Auth::user()->id) == null) ? 1 : 0;
        }
        if ($total_preguntas > 0) {
            return view('trivias.play', ['trivia' => $trivia]);
        }else {
            return redirect('/partidos')->with('status', 'Url no encontrada');
        }
    }

    public function respuesta(Request $request)
    {
        $p = Pregunta::find($request->id);
        if ($p->respuesta(Auth::user()->id) == null) {
            $puntos = 0;
            $tipo = 'Pierde';
            $mensaje = '';
            if ($request->respuesta != 'TimeOut') {
                $puntos = ($p->respuesta == $request->respuesta) ? $p->puntos : 0;
                $tipo = ($p->respuesta == $request->respuesta) ? 'Gana' : 'Pierde';
                $mensaje = ($p->respuesta == $request->respuesta) ? '¡Genial ya vas sumando '.$puntos.' puntos más!' : 'Ooh no, respuesta incorrecta :(';
            }else {
                $tipo = 'TimeOut';
                $mensaje = '¡Tiempo fuera!';
            }
            Pregunta_usuario::create([
                'id_pregunta' => $request->id,
                'id_user' => Auth::user()->id,
                'respuesta' => $request->respuesta,
                'puntos' => $puntos,
            ]);
            return response()->json(['status' => 'Ok', 'data' => $tipo, 'msg' => $mensaje]);
        }else {
            return response()->json(['status' => 'Ok', 'data' => 'No puede']);
        }
    }

    public function calcular_trivia()
    {
        $puntos_trivia = Pregunta_usuario::where('id_user',Auth::user()->id)->sum('puntos');
        $mensaje = '';
        if ($puntos_trivia != null && $puntos_trivia != 0) {
            $points = $this->userPoints(Auth::user()->id);
            $user = User::find(Auth::user()->id);
            $user->points = $points;
            $user->update();
            $mensaje = '¡Genial, ganaste '.$puntos_trivia.' puntos!';
            Plastimedia::notificar([
                'id' => Auth::user()->id,
                'icono' => 'copa.png',
                'data' => $puntos_trivia,
                'title' => $mensaje,
                'content' => '¡Sigue asi y llegarás muy lejos!',
                'link' => '#',
                'type' => ['type' => 'trivia'],
                'token' => Auth::user()->token_push
            ]);
        }else {
            $mensaje = 'Trivia realizada, no ganaste puntos, mejor suerte la proxima';
        }
        $this->userPositions();
        return redirect('/partidos')->with('status', $mensaje)->with('class', 'succes');
    }

}
