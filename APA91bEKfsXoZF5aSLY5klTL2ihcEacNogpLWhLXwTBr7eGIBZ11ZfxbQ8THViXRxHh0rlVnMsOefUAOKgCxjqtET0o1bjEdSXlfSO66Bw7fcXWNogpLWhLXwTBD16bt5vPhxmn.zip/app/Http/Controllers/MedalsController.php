<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserPrediction;
use App\Plastimedia;
use App\UserMedal;
use App\Medal;
use App\Match;
use Image;

class MedalsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $medals = Medal::orderBy('id', 'DESC')->paginate(20);
        return view('medals.index', ['medals' => $medals]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $matchs = Match::all();
        return view('medals.create', ['matchs' => $matchs]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $data = $request->validate([
          'img' => 'image|max:1024000',
          'name' => 'required|max:250',
          'desc' => 'required|max:500',
          'id_match' => 'required',
        ], [
            'img.image' => 'El archivo debe ser una imagen',
            'img.max' => 'El archivo no debe pesar más de 1024 kilobytes',
            'name.required' => 'Ingresa el nombre del premio',
            'name.max' => 'El nombre del premio no debe superar los 250 caracteres',
            'desc.required' => 'Ingresa la descripcion del premio',
            'desc.max' => 'La descripcion del premio no debe superar los 500 caracteres',
            'id_match.required' => 'Selecciona un partido',
        ]);


       $medal = Medal::create([
            'name' => $data['name'],
            'desc' => $data['desc'],
            'id_match' => $data['id_match']
       ]);

       $msg = '';
        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ( $img->getClientOriginalExtension() == 'jpg' || $img->getClientOriginalExtension() == 'png' || $img->getClientOriginalExtension() == 'jpeg' ) {
                $filename = time().'.'.$img->getClientOriginalExtension();
                // Creo la imagen
                Image::make($img)->fit(250)->save( public_path( 'images/medals/' . $filename ) );
                // Borro la imagen anterior si no es la imagen default
                $medal->img = $filename;
                $medal->update();
            } else {
                return redirect('medals/create')->with('status', 'La extención de la imagen no es válida, solo se aceptan los siguientes formatos: jpg, png, jpeg');
            }
        }
        return redirect('medals/index')->with('status', 'Premio creado')->with('class', 'succes');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $medal = Medal::find($id);
        $matchs = Match::all();
        return view('medals.edit', ['medal' => $medal, 'matchs' => $matchs]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->validate([
          'img' => 'image|max:1024000',
          'name' => 'required|max:250',
          'desc' => 'required|max:500',
          'id_match' => 'required',
        ], [
            'img.image' => 'El archivo debe ser una imagen',
            'img.max' => 'El archivo no debe pesar más de 1024 kilobytes',
            'name.required' => 'Ingresa el nombre del premio',
            'name.max' => 'El nombre del premio no debe superar los 250 caracteres',
            'desc.required' => 'Ingresa la descripcion del premio',
            'desc.max' => 'La descripcion del premio no debe superar los 500 caracteres',
            'id_match.required' => 'Selecciona un partido',
        ]);
        $medal = Medal::find($id);
        $medal->name = $data['name'];
        $medal->desc = $data['desc'];
        $medal->id_match = $data['id_match'];
        $msg = '';
        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ( $img->getClientOriginalExtension() == 'jpg' || $img->getClientOriginalExtension() == 'png' || $img->getClientOriginalExtension() == 'jpeg' ) {
                $filename = time().'.'.$img->getClientOriginalExtension();
                // Creo la imagen
                if ($medal->img != null) {
                    if (file_exists( public_path( 'images/medals/' . $medal->img ) )) {
                        unlink( public_path( 'images/medals/' . $medal->img ) );
                    }
                }
                Image::make($img)->fit(250)->save( public_path( 'images/medals/' . $filename ) );
                // Borro la imagen anterior si no es la imagen default
                $medal->img = $filename;
            } else {
                return redirect('medals/create')->with('status', 'La extención de la imagen no es válida, solo se aceptan los siguientes formatos: jpg, png, jpeg');
            }
        }
        $medal->update();
        return redirect('medals/index')->with('status', 'Premio guardado')->with('class', 'succes');
    }

    /** 
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $medal = Medal::find($id);
        if ($medal->users->count() > 0) {
            return redirect('medals/index')->with('status', 'No puedes eliminar este premio por que ya hay usuarios que lo ganarón');
        }else {
            $medal->delete();
            return redirect('medals/index')->with('status', 'Premio eliminado')->with('class', 'succes');
        }
    }

    public function calcular($id)
    {
        $medal = Medal::find($id);
        $predicciones = UserPrediction::where('match_id', $medal->id_match)
        ->where('a_score', $medal->match->score_a)
        ->where('b_score', $medal->match->score_b)
        ->get();
        $i = 0;
        foreach ($predicciones as $p) {
            $i++;
            $m = UserMedal::create([
                'user_id' => $p->user_id,
                'medal_id' => $medal->id,
                'delivered' => 0,
            ]);
            Plastimedia::notificar([
                'id' => $m->user->id,
                'icono' => 'copa.png',
                'data' => null,
                'title' => '¡Genial, ganaste un premio!',
                'content' => 'Por asertar en el partido '.$medal->match->team_a->country.' - vs - '.$medal->match->team_b->country. ', ganaste el siguiente premio: '.$medal->name,
                'link' => route('perfil'),
                'type' => ['type' => 'refresh-home'],
                'token' => $m->user->token_push
            ]);
        }
        $medal->generados = 'Si';
        $medal->update();
        return redirect('medals/index')->with('status', 'Ganadores calculados, total de ganadores: '.$i)->with('class', 'succes');
    }

    public function redimir($data)
    {
        $data = explode('-', $data);
        $medal_user = UserMedal::find($data[0]);
        $medal_user->delivered = 1;
        $medal_user->update();
        Plastimedia::notificar([
            'id' => $medal_user->user->id,
            'icono' => 'copa.png',
            'data' => null,
            'title' => '¡Has redimido un premio!',
            'content' => 'El premio: '.$medal_user->medal->name.' ha sido redimido',
            'link' => route('perfil'),
            'type' => ['type' => 'refresh-home'],
            'token' => $medal_user->user->token_push
        ]);

        return redirect('users/'.$data[1].'/edit')->with('status', 'Premio redimido')->with('class', 'succes');
    }

}
