<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Widget;

class WidgetController extends Controller
{
	public function edit()
	{
		$widget = Widget::find(1);
		return view('widget.edit', ['widget' => $widget]);
	}

	public function update(Request $request)
	{
		$data = $request->validate([
			'titulo' => 'max:200',
			'wpp' => 'max:11',
			'tel' => 'max:11',
		],[
			'titulo.max' => 'El titulo no debe sobrepasar los 200 caracteres',
			'wpp.max' => 'El Whatsapp no debe sobrepasar las 11 cifras',
			'tel.max' => 'El numero de teléfono no debe sobrepasar las 11 cifras',
		]);
		$widget = Widget::find(1);
		$widget->estado = $request->estado;
		$widget->titulo = $request->titulo;
		$widget->wpp = $request->wpp;
		$widget->tel = $request->tel;
		$widget->color = $request->color;
		$widget->update();
		return redirect('widget/edit')->with('status', 'Widget actualizado')->with('class', 'succes');
	}

}
