<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Plastimedia;
use App\Trivia;
use App\Pregunta;
use App\Pregunta_usuario;
use App\User;

class TriviaApiController extends PointsController
{
    public function index(Request $request)
    {
    	$data = $request->data;
		$trivia = Trivia::where('estado', 'Activa')->first();
		if ($trivia != null) {
			$total_preguntas = 0;
			$escentas = [];
			foreach ($trivia->preguntas as $p) {
				if ($p->respuesta($data['id_user']) == null){
					$total_preguntas++;
				}else {
					$escentas[] = $p->id;
				}
			}
			$trivia->total_preguntas = $total_preguntas;
			$trivia->escentas = $escentas;
			$trivia->total_puntos = $trivia->getPuntos();
		}
		return response()->json($trivia);
    }

    public function store(Request $request)
    {
    	$data = $request->data;
    	foreach ($data['respuestas'] as $respuesta) {
    		$p = Pregunta::find($respuesta['id']);
        	$puntos = 0;
        	if ($p->respuesta($data['id_user']) == null) {       
	            if ($respuesta['respuesta'] != 'TimeOut') {
	                $puntos = ($p->respuesta == $respuesta['respuesta']) ? $p->puntos : 0;
	            }
	            Pregunta_usuario::create([
	                'id_pregunta' => $respuesta['id'],
	                'id_user' => $data['id_user'],
	                'respuesta' => $respuesta['respuesta'],
	                'puntos' => $puntos,
	            ]);
        	}
    	}
    	$puntos_trivia = Pregunta_usuario::where('id_user',$data['id_user'])->sum('puntos');

    	if ($puntos_trivia != null && $puntos_trivia != 0) {
            $points = $this->userPoints($data['id_user']);
            $user = User::find($data['id_user']);
            $user->points = $points;
            $user->update();
            $mensaje = '¡Genial, ganaste '.$puntos_trivia.' puntos!';
            Plastimedia::notificar([
                'id' => $data['id_user'],
                'icono' => 'copa.png',
                'data' => $puntos_trivia,
                'title' => $mensaje,
                'content' => '¡Sigue asi y llegarás muy lejos!',
                'link' => '#',
                'type' => ['type' => 'trivia'],
                'token' => $user->token_push
            ]);
        }
    	return response()->json(['status' => 'Ok', 'data' => $puntos_trivia]);
    }
}
