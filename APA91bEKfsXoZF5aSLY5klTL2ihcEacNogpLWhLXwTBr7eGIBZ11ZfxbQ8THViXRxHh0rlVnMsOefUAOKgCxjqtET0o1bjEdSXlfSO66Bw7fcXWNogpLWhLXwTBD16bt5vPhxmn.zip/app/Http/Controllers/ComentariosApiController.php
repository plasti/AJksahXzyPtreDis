<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comentarios;
use App\Match;
use App\Plastimedia;

class ComentariosApiController extends Controller
{
    public function index(Request $request)
    {
    	$data = $request->data;
		$comentarios = Comentarios::select('comentarios.*', 'users.name', 'users.avatar')
		->join('users', function ($join){ $join->on('comentarios.id_user', '=', 'users.id');	})
		->where('id_match', $data['id_match'])
		->orderBy('id', 'DESC')
		->paginate(15);
		return response()->json($comentarios);
    }

    public function store(Request $request)
    {
    	$data = $request->data;
    	$comentario = Comentarios::create([
			'id_user' => $data['id_user'],
			'id_match' => $data['id_match'],
			'text' => $data['text'],
    	]);
    	$ss = Comentarios::select('id_user')->where('id_match', $data['id_match'])->where('id_user', '<>', $data['id_user'])->groupBy('id_user')->get();
        foreach ($ss as $s) {
            Plastimedia::notificar([
                'id' => $s->id_user,
                'icono' => 'conversacion.png',
                'data' => $data['id_match'],
                'title' => $comentario->user->name.' comentó en el partido '.$comentario->match->team_a->country.' VS '.$comentario->match->team_b->country,
                'content' => 'Da click en el botón ver más para leer su comentario',
                'link' => route('comentarios', $data['id_match']),
                'type' => ['type' => 'comentario'],
                'token' => $s->user->token_push
            ]);
        }
    	return response()->json(['status' => 'Ok']);
    }

    public function delete(Request $request)
    {
    	$data = $request->data;
    	$comentario = Comentarios::find($data['id']);
    	$comentario->delete();
    	return response()->json(['status' => 'Ok', 'data' => 'Comentario eliminado']);
    }

    public function get_match(Request $request)
    {
        $data = $request->data;
        $match = Match::find($data['id']);
        $match->team_a = $match->team_a;
        $match->team_b = $match->team_b;
        return response()->json(['status' => 'Ok', 'data' => $match]);
    }

}
