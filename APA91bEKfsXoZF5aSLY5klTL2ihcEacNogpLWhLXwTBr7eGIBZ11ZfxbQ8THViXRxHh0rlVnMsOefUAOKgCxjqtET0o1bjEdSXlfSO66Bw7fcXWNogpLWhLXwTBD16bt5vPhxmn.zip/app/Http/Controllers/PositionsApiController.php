<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\User;
use App\Group;
use App\Match;
use Carbon\Carbon;
use DateTime;



class PositionsApiController extends Controller
{
	public $diasSemana = [
		'1' => 'Lunes',
		'2' => 'Martes',
		'3' => 'Miércoles',
		'4' => 'Jueves',
		'5' => 'Viernes',
		'6' => 'Sábado',
		'7' => 'Domingo',
	];
	public $meses = [
		'01' => 'Enero', 
		'02' => 'Febrero', 
		'03' => 'Marzo', 
		'04' => 'Abril', 
		'05' => 'Mayo', 
		'06' => 'Junio', 
		'07' => 'Julio', 
		'08' => 'Agosto', 
		'09' => 'Septiembre', 
		'10' => 'Octubre', 
		'11' => 'Noviembre', 
		'12' => 'Diciembre', 
	];

    public function positions()
    {
		// Obtengo los usuarios
		$users = User::where('role','<>','admin')->orderBy('points','desc')->paginate(10);
		
		// Obtengo los grupos
		$groups = Group::orderBy('points', 'desc')->get();
    	
		return response()->json(['status' => 'Ok', 'data' => ['users' => $users, 'groups' => $groups]]);
    }



    // traer las predicciones del usuario cuando el partido esta cerrado
    public function predictions(Request $request)
    {

    	$data = $request->data;
		$predictions = DB::raw('(SELECT * FROM user_predictions where user_id = '.$data['id'].') predictions');
		
		// Obtengo la lista de los partidos
		$matches = Match::select('matchs.*', 'matchs.id as id_match', 'predictions.*', 'predictions.id as id_prediction')
			->leftJoin($predictions, 'matchs.id', '=', 'predictions.match_id')
			->orderBy('date_time', 'ASC')
			->get();

		// inicializo etapas
		$etapas = [];
		$grupo1 = [];
		$grupo2 = [];
		$grupo3 = [];
		$cuartos = [];
		$semi = [];
		$tercer = [];
		$final = [];

		// Creo los array para las etapas
		foreach ($matches as $match) {
			// Comparo la hora actual con la del partido para ver si se muestra cerrado
			$hora_partido = new Carbon($match->date_time, $match->date_zone);
			$hora_partido = $hora_partido->subMinutes(3);
			$ahora = Carbon::now();
			if ($ahora->gte($hora_partido) && $match->a_score != null && $match->b_score != null) {
				$match->cerrado = $ahora->gte($hora_partido);

				// Doy formato a la fecha y a la hora
				$diaSemana = Carbon::parse($match->date_time)->format('N');
				$diaSemana = $this->diasSemana[$diaSemana];
				$mes = Carbon::parse($match->date_time)->format('m');
				$mes = $this->meses[$mes];
				$dia = Carbon::parse($match->date_time)->format('d');
				$anio = Carbon::parse($match->date_time)->format('Y');
				$match->date = $diaSemana . ' ' . $dia . ' de ' . $mes . ' - '. $anio;
				$match->time = Carbon::parse($match->date_time)->format('H:i');


				// Calculos para mostrar resultados por colores
				if (!is_null($match->score_a) && !is_null($match->score_b)) {
					$match->marcador_a = $match->a_score == $match->score_a ? true : false;
					$match->marcador_b = $match->b_score == $match->score_b ? true : false;
					if ( 
						($match->a_score > $match->b_score && $match->score_a > $match->score_b) ||
						($match->a_score < $match->b_score && $match->score_a < $match->score_b) ||
						($match->a_score == $match->b_score && $match->score_a == $match->score_b)
					){
						$match->nombres = true;
					} else {
						$match->nombres = false;
					}
				}

				// datos de los equipos para mostrar en la app
				$match->team_a = $match->team_a;
				$match->team_b = $match->team_b;
					
				if ($match->id_match >= 1 && $match->id_match <= 6) { // Ronda 1
					$grupo1[] = $match;
				} elseif ($match->id_match >= 7 && $match->id_match <= 12) { // Ronda 2
					$grupo2[] = $match;
				} elseif ($match->id_match >= 13 && $match->id_match <= 18) { // Ronda 3
					$grupo3[] = $match;
				} elseif ($match->id_match >= 19 && $match->id_match <= 22) { // Cuartos de final
					$cuartos[] = $match;
				} elseif ($match->id_match == 23 || $match->id_match == 24) { // Semifinales
					$semi[] = $match;
				} elseif ($match->id_match == 25) { // Tercer puesto
					$tercer[] = $match;
				} elseif ($match->id_match == 26) { // Final
					$final[] = $match;
				}


			}	

		} // End foreach partidos
		
		$etapas = [
			['titulo' => 'Fase de grupos - Ronda 1 de 3', 'partidos' => $grupo1],
			['titulo' => 'Fase de grupos - Ronda 2 de 3', 'partidos' => $grupo2],
			['titulo' => 'Fase de grupos - Ronda 3 de 3', 'partidos' => $grupo3],
			['titulo' => 'Cuartos de final', 'partidos' => $cuartos],
			['titulo' => 'Semifinales', 'partidos' => $semi],
			['titulo' => 'Tercer puesto', 'partidos' => $tercer],
			['titulo' => 'Final', 'partidos' => $final],
		];

    	return response()->json(['status' => 'Ok', 'data' => ['etapas' => $etapas]]);
    }


    public function predictions_group(Request $request)
    {
    	$data = $request->data;
		$predictions = DB::raw('(SELECT * FROM group_predictions where group_id = '.$data['id'].') predictions');
		
		// Obtengo la lista de los partidos
		$matches = Match::select('matchs.*', 'matchs.id as id_match', 'predictions.*', 'predictions.id as id_prediction')
			->leftJoin($predictions, 'matchs.id', '=', 'predictions.match_id')
			->orderBy('date_time', 'ASC')
			->get();

		// inicializo etapas
		$etapas = [];
		$grupo1 = [];
		$grupo2 = [];
		$grupo3 = [];
		$cuartos = [];
		$semi = [];
		$tercer = [];
		$final = [];

		// Creo los array para las etapas
		foreach ($matches as $match) {
			$hora_partido = new Carbon($match->date_time);
			$hora_partido = $hora_partido->subMinutes(3);
			$ahora = Carbon::now();
			if ($ahora->gte($hora_partido) && $match->a_score != null && $match->b_score != null) {
				// Comparo la hora actual con la del partido para ver si se muestra cerrado
				$match->cerrado = $ahora->gte($hora_partido);

				// Doy formato a la fecha y a la hora
				$diaSemana = Carbon::parse($match->date_time)->format('N');
				$diaSemana = $this->diasSemana[$diaSemana];
				$mes = Carbon::parse($match->date_time)->format('m');
				$mes = $this->meses[$mes];
				$dia = Carbon::parse($match->date_time)->format('d');
				$anio = Carbon::parse($match->date_time)->format('Y');
				$match->date = $diaSemana . ' ' . $dia . ' de ' . $mes . ' - '. $anio;
				$match->time = Carbon::parse($match->date_time)->format('H:i');

				// datos de los equipos para mostrar en la app
				$match->team_a = $match->team_a;
				$match->team_b = $match->team_b;

				if ($match->id_match >= 1 && $match->id_match <= 6) { // Ronda 1
					$grupo1[] = $match;
				} elseif ($match->id_match >= 7 && $match->id_match <= 12) { // Ronda 2
					$grupo2[] = $match;
				} elseif ($match->id_match >= 13 && $match->id_match <= 18) { // Ronda 3
					$grupo3[] = $match;
				} elseif ($match->id_match >= 19 && $match->id_match <= 22) { // Cuartos de final
					$cuartos[] = $match;
				} elseif ($match->id_match == 23 || $match->id_match == 24) { // Semifinales
					$semi[] = $match;
				} elseif ($match->id_match == 25) { // Tercer puesto
					$tercer[] = $match;
				} elseif ($match->id_match == 26) { // Final
					$final[] = $match;
				} 
			}
			
		} // End foreach partidos

		$etapas = [
			['titulo' => 'Fase de grupos - Ronda 1 de 3', 'partidos' => $grupo1],
			['titulo' => 'Fase de grupos - Ronda 2 de 3', 'partidos' => $grupo2],
			['titulo' => 'Fase de grupos - Ronda 3 de 3', 'partidos' => $grupo3],
			['titulo' => 'Cuartos de final', 'partidos' => $cuartos],
			['titulo' => 'Semifinales', 'partidos' => $semi],
			['titulo' => 'Tercer puesto', 'partidos' => $tercer],
			['titulo' => 'Final', 'partidos' => $final],
		];

		return response()->json(['status' => 'Ok', 'data' => ['etapas' => $etapas]]);
    }
}
