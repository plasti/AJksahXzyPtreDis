<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Image;
use Illuminate\Support\Facades\Mail;
use App\Mail\MensajePostRegistro;
use App\User;
use App\Group;
use App\Exports\UsersExport;
use Excel;

class UserController extends Controller
{
  
	// Muestra la vista de las posiciones
	public function index() 
	{
		$user = Auth::user();
		return view('users.index', ['current' => 'perfil', 'user' => $user]);
	}

  // Muestra la vista de la configuración de usuario
	public function profile() 
	{
  	$error_extension = false;
		return view('users.profile', ['user' => Auth::user(), 'error_extension' => $error_extension]);
	}

	// Método que guarda la configuración del usuario
	public function update_profile(Request $request) 
	{
		
		$this->validate($request, [
      'avatar' => 'image|max:1024',
      'name' => 'required',
      'password' => 'confirmed',
    ], [
    	'avatar.image' => 'El archivo debe ser una imagen',
    	'avatar.max' => 'El archivo no debe pesar más de 1024 kilobytes',
    	'name.required' => 'Ingresa tu nombre',
    	'password.confirmed' => 'Las contraseñas deben coincidir',
    ]);

		$user = Auth::user();
		// manejar la carga del avatar, pregunto si existe un archivo
		if ($request->hasFile('avatar')) {
			$avatar = $request->file('avatar');
			
			if ( $avatar->getClientOriginalExtension() == 'jpg' || $avatar->getClientOriginalExtension() == 'png' || $avatar->getClientOriginalExtension() == 'jpeg' ) {
				
				$filename = time().'.'.$avatar->getClientOriginalExtension();
				
				// Creo la imagen
				Image::make($avatar)->fit(250)->save( public_path( 'images/avatars/' . $filename ) );

				// Borro la imagen anterior si no es la imagen default
				if ($user->avatar != 'default.jpg') {
					if (file_exists( public_path( 'images/avatars/' . $user->avatar ) )) {
						unlink( public_path( 'images/avatars/' . $user->avatar ) );
					}
				}

				$user->avatar = $filename;
				
			} else {
				$error_extension = true;
				return view('users.profile', ['user' => Auth::user(), 'error_extension' => $error_extension]);
			}
		}

		$user->name = $request->name;
		if ($request->password != null) {
			$user->password = bcrypt($request->password);
		}

		$user->save();

		// Mail::to($user->email, $user->name)->send( new MensajePostRegistro() );

		return redirect('configuracion')->with('status', 'Cambios guardados!')->with('class', 'succes');
	}

	public function all_users(Request $request)
	{
		if (Auth::user()->role != 'admin') {
			return redirect('/')->with('status', 'Url no encontrada');
		}else {
			$buscar = $request->buscar;
			if ($buscar != null) {
				$users = User::where('name', 'like', "%$buscar%")
				->orwhere('email', 'like', "%$buscar%")
				->where('id', '<>', Auth::user()->id)
				->paginate(20);	
			}else {
				$users = User::where('id', '<>', Auth::user()->id)->paginate(20);
			}
			$grupos = Group::all();
			return view('users.all', ['users' => $users, 'grupos' => $grupos, 'buscar' => $buscar]);
		}
	}

	public function edit_user($id)
	{
		$user = User::find($id);
		$error_extension = false;
		return view('users.edit', ['user' => $user, 'error_extension' => $error_extension]);
	}
	public function update_user(Request $request, $id)
	{
		$this->validate($request, [
			'avatar' => 'image|max:1024',
			'name' => 'required',
			'password' => 'confirmed',
		], [
			'avatar.image' => 'El archivo debe ser una imagen',
			'avatar.max' => 'El archivo no debe pesar más de 1024 kilobytes',
			'name.required' => 'Ingresa tu nombre',
			'password.confirmed' => 'Las contraseñas deben coincidir',
		]);
		$user = User::find($id);
		// manejar la carga del avatar, pregunto si existe un archivo
		if ($request->hasFile('avatar')) {
			$avatar = $request->file('avatar');
			
			if ($avatar->getClientOriginalExtension() == 'jpg' ||
				$avatar->getClientOriginalExtension() == 'png' ||
				$avatar->getClientOriginalExtension() == 'jpeg') {
				$filename = time().'.'.$avatar->getClientOriginalExtension();
				// Creo la imagen
				Image::make($avatar)->fit(250)->save( public_path( 'images/avatars/' . $filename ) );
				// Borro la imagen anterior si no es la imagen default
				if ($user->avatar != 'default.jpg') {
					if (file_exists( public_path( 'images/avatars/' . $user->avatar ) )) {
						unlink( public_path( 'images/avatars/' . $user->avatar ) );
					}
				}
				$user->avatar = $filename;
			} else {
				$error_extension = true;
				return view('users.profile', ['user' => Auth::user(), 'error_extension' => $error_extension]);
			}
		}

		$user->name = $request->name;
		if ($request->password != null) {
			$user->password = bcrypt($request->password);
		}
		$user->update();
		return redirect('users/'.$id.'/edit')->with('status', 'Usuario actualizado')->with('class', 'succes');
	}

	public function export() 
	{
	    return Excel::download(new UsersExport, 'usuarios.xlsx');
	}

	public function import()
	{
		return view('users.import');
	}

	public function how_import()
	{
		return view('users.howimport');
	}

	public function import_file(Request $request)
	{
		$archivo = fopen($request->file,'r');
		$fila = 1; //ignoro los titulos del archivo de excel
		$importados = 0;
		while ($data = fgetcsv($archivo, 1000, ',')) {
			if (count($data) > 0) {
				if ($fila <> 1) {
					if (User::where('email', $data[1])->count() == 0) {
						User::create([
							'name' => $data[0], 
							'email' => $data[1], 
							'password' => bcrypt($data[2]),
							'group_id' => $data[3],
						]);
						$importados++;
					}
				}
				$fila++;
			}else {
				return redirect('users')->with('status', 'El archivo no es compatible o no tiene la estructura adecuada para la importación');
				break;
			}
		}

		return redirect('users')->with('status', 'Se importarón correctamente '.$importados.' usuarios')->with('class', 'succes');
	}

}
