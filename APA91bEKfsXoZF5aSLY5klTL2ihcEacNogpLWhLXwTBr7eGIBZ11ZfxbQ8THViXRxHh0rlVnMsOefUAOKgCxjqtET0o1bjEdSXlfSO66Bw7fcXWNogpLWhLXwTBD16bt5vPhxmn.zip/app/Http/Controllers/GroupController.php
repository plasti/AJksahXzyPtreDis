<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Match;
use Carbon\Carbon;
use Auth;
use App\Slider;
use App\Group;

class GroupController extends Controller
{
	public $diasSemana = ['1' => 'Lunes', '2' => 'Martes', '3' => 'Miércoles', '4' => 'Jueves', '5' => 'Viernes', '6' => 'Sábado', '7' => 'Domingo',];
	public $meses = [
		'01' => 'Enero', 
		'02' => 'Febrero', 
		'03' => 'Marzo', 
		'04' => 'Abril', 
		'05' => 'Mayo', 
		'06' => 'Junio', 
		'07' => 'Julio', 
		'08' => 'Agosto', 
		'09' => 'Septiembre', 
		'10' => 'Octubre', 
		'11' => 'Noviembre', 
		'12' => 'Diciembre', 
	];
		
	// Muestra la lista de los partidos del grupo
	public function index()
	{
		$user = Auth::user();

		$predictions = DB::raw('(SELECT * FROM group_predictions where group_id = '.$user->group->id.') predictions');
		
		// Obtengo la lista de los partidos
		$matches = Match::select('matchs.*', 'matchs.id as id_match', 'predictions.*', 'predictions.id as id_prediction')
			->leftJoin($predictions, 'matchs.id', '=', 'predictions.match_id')
			->get();

		// Creo los array para las etapas
		foreach ($matches as $match) {
			// Doy formato a la fecha y a la hora
			$diaSemana = Carbon::parse($match->date_time)->format('N');
			$diaSemana = $this->diasSemana[$diaSemana];
			$mes = Carbon::parse($match->date_time)->format('m');
			$mes = $this->meses[$mes];
			$dia = Carbon::parse($match->date_time)->format('d');
			$anio = Carbon::parse($match->date_time)->format('Y');
			$match->date = $diaSemana . ' ' . $dia . ' de ' . $mes . ' - '. $anio;
			$match->time = Carbon::parse($match->data_country())->format('H:i');

			// Comparo la hora actual con la del partido para ver si se muestra cerrado
			$hora_partido = new Carbon($match->date_time);
			$hora_partido = $hora_partido->subMinutes(3);
			$ahora = Carbon::now();
			$match->cerrado = $ahora->gte($hora_partido);
			
			// if ($match->id_match >= 1 && $match->id_match <= 16) { // Ronda 1
			// 	$grupo1[] = $match;
			// } elseif ($match->id_match >= 17 && $match->id_match <= 32) { // Ronda 2
			// 	$grupo2[] = $match;
			// } elseif ($match->id_match >= 33 && $match->id_match <= 48) { // Ronda 3
			// 	$grupo3[] = $match;
			// } elseif ($match->id_match >= 49 && $match->id_match <= 56) { // Octavos de final
			// 	$octavos[] = $match;
			// } elseif ($match->id_match >= 57 && $match->id_match <= 60) { // Cuartos de final
			// 	$cuartos[] = $match;
			// } elseif ($match->id_match == 61 || $match->id_match == 62) { // Semifinales
			// 	$semi[] = $match;
			// } elseif ($match->id_match == 63) { // Tercer puesto
			// 	$tercer[] = $match;
			// } elseif ($match->id_match == 64) { // Final
			// 	$final[] = $match;
			// } 


			if ($match->id_match >= 1 && $match->id_match <= 4) { // Ronda 1
				$grupo1[] = $match;
			} elseif ($match->id_match >= 5 && $match->id_match <= 8) { // Ronda 2
				$grupo2[] = $match;
			} elseif ($match->id_match >= 9 && $match->id_match <= 12) { // Ronda 3
				$grupo3[] = $match;
			} elseif ($match->id_match >= 13 && $match->id_match <= 16) { // Ronda 4
				$grupo4[] = $match;
			} elseif ($match->id_match >= 17 && $match->id_match <= 20) { // Ronda 5
				$grupo5[] = $match;
			} elseif ($match->id_match >= 21 && $match->id_match <= 24) { // Cuartos de final
				$cuartos[] = $match;
			} elseif ($match->id_match == 25 || $match->id_match == 26) { // Semifinales
				$semi[] = $match;
			} elseif ($match->id_match == 27) { // Tercer puesto
				$tercer[] = $match;
			} elseif ($match->id_match == 28) { // Final
				$final[] = $match;
			} 
			
		} // End foreach partidos

		$user->puntos = 0;
		$user->position = 1;
		$user->grupo_puntos = 0;
		$user->grupo_position = 1; 

		$etapas = [
			['titulo' => 'Fase de grupos - Ronda 1 de 5', 'partidos' => $grupo1],
			['titulo' => 'Fase de grupos - Ronda 2 de 5', 'partidos' => $grupo2],
			['titulo' => 'Fase de grupos - Ronda 3 de 5', 'partidos' => $grupo3],
			['titulo' => 'Fase de grupos - Ronda 4 de 5', 'partidos' => $grupo4],
			['titulo' => 'Fase de grupos - Ronda 5 de 5', 'partidos' => $grupo5],
			['titulo' => 'Cuartos de final', 'partidos' => $cuartos],
			['titulo' => 'Semifinales', 'partidos' => $semi],
			['titulo' => 'Tercer puesto', 'partidos' => $tercer],
			['titulo' => 'Final', 'partidos' => $final],
		];

		//return view('partidos.index', ['current' => 'partidos', 'etapas' => $etapas, 'user' => $user]);
		$sliders = Slider::where('status', 'Si')->get();
		return view('groups.index', [
			'current' => 'partidos',
			'currentMatch' => 'grupo',
			'etapas' => $etapas,
			'user' => $user,
			'sliders' => $sliders
		]);
	}



	public function all_groups(Request $request)
	{	
		if (config('polla.groups')) {
			$buscar = $request->buscar;
			if ($buscar != null) {
				$groups = Group::where('name', 'like', "%$buscar%")->get();	
			}else {
				$groups = Group::all();
			}
			return view('groups.all', ['grupos' => $groups, 'buscar' => $buscar]);
		}else {
			return redirect('/')->with('status', 'Url no encontrada');
		}
	}
}
