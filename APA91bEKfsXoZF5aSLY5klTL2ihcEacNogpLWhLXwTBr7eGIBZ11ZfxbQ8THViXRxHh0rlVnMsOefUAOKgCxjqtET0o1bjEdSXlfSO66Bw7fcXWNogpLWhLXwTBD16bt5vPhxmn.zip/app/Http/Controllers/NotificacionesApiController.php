<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notificaciones;
use App\User;

class NotificacionesApiController extends Controller
{
    public function index(Request $request)
    {
    	$data = $request->data;
    	$notificaciones = Notificaciones::orderBy('id', 'DESC')->where('id_user', $data['id'])->paginate(10);
    	$notificaciones_new = Notificaciones::where('estado', '<>', null)->where('id_user', $data['id'])->get();
    	foreach ($notificaciones_new as $old) {
    		$old->estado = null;
    		$old->update();
    	}
    	return response()->json($notificaciones);
    }

    public function set_token(Request $request)
    {
        $data = $request->data;
        $user = User::find($data['id']);
        $user->token_push = $data['token'];
        $user->update();
        return response()->json(['status' => 'Ok']);
    }
}
