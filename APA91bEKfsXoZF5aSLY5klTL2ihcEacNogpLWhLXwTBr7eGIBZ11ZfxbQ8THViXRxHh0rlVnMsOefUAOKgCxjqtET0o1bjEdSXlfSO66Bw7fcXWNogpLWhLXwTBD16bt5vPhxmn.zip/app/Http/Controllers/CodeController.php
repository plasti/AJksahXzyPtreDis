<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Code;
use App\UserCode;
use App\Match;

class CodeController extends PointsController
{
	/*
	 * Muestra la lista de los códigos y un formulario para agregar más
	 */
	public function index()
	{
		$user = Auth::user();

		return view('codes.index', ['current' => 'codes', 'codes' => $user->codes]);
	}

	/*
	 * Guardo los códigos registrados por el usuario
	 */
	public function store(Request $request)
	{
		$this->validate($request, [
			'code' => 'required|exists:codes,code',
		],[
			'code.required' => 'Ingresa un código válido',
			'code.exists' => 'Ingresa un código válido',
		]);

		$user = Auth::user();

		// Obtengo el código
		$codigo = Code::where('code',$request['code'])->first();
		
		// pongo el código como usado
		$code = Code::find($codigo->id);
		$code->code = '';
		$code->used_code = $codigo->code;
		$code->save();
		
		// Guardo el codigo registrado
		$userCode = new UserCode();
		$userCode->user_id = $user->id;
		$userCode->code_id = $codigo->id;
		$userCode->save();

		// Obtengo la nueva cantidad de puntos del usuario
		$user->points = $this->userPoints($user->id);

		// Guardo los puntos del usuario
		$user->save();

		$this->userPositions();

		return redirect('codes')->with('status', 'Código registrado!')->with('class', 'succes');
	}


	public function index_admin() {
		$codigos = Code::where('used_code', null)->paginate(20);
		return view('codes.indexadmin', ['codigos' => $codigos]);
	}

	public function import() {
		return view('codes.import');
	}

	public function how_import() {
		return view('codes.howimport');
	}

	public function import_file(Request $request) {
		$archivo = fopen($request->file,'r');
		$fila = 1; //ignoro los titulos del archivo de excel
		$importados = 0;
		while ($data = fgetcsv($archivo, 1000, ',', 'r')) {
			if (count($data) > 0) {
				if ($fila <> 1) {
					if (Code::where('code', $data[0])->count() == 0) {
						Code::create(['code' => $data[0]]);
						$importados++;
					}
				}
				$fila++;
			}else {
				return redirect('codes/admin')->with('status', 'El archivo no es compatible o no tiene la estructura adecuada para la importación');
				break;
			}
		}
		return redirect('codes/admin')->with('status', 'Se importarón correctamente '.$importados.' codigos')->with('class', 'succes');
	}

	public function delete_admin($id) {
		$code = Code::find($id);
		$code->delete();
		return redirect('codes/admin')->with('status', 'Codigo eliminado')->with('class', 'succes');
	}


}
