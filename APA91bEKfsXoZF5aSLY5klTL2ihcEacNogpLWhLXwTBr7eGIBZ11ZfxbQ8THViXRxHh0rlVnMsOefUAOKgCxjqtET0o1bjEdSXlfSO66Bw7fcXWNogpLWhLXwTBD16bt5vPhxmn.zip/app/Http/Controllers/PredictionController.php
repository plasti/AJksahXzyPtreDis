<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validator;
use App\UserPrediction;
use App\GroupPrediction;
use App\Match;
use Carbon\Carbon;

class PredictionController extends Controller
{
	/**
	 * Guarda la prediccion de un partido para un usuario
	 */
	public function store(Request $request)
	{
		// Valido con la hora del partido si es posible guardar
		$validar = $request->all();
		if ($request->match_id) {
			$match = Match::find($request->match_id);
			$hora_partido = new Carbon($match->date_time);
			$hora_partido = $hora_partido->subMinutes(3);
			$ahora = Carbon::now();
			$validar['date_time'] = $ahora->gte($hora_partido)?'':'yes';
		}
		
		// Reglas de validacion
		$validator = Validator::make($validar, [
			'match_id' => 'required',
			'a_score' => 'required|numeric',
			'b_score' => 'required|numeric',
			'date_time' => 'required'
		],[
			'match_id.required' => 'Algo falló, intenta nuevamente',
			'a_score.required' => 'Falta un marcador', 
			'a_score.numeric' => 'Solo ingresa números en el marcador', 
			'b_score.required' => 'Falta un marcador', 
			'b_score.numeric' => 'Solo ingresa números en el marcador', 
			'date_time.required' => 'Este partido ya está cerrado', //'Este partido ya está cerrado'
		]);

		// Si la validación pasó
		if ($validator->passes()) {
			
			// Consulto en busca de la predicción
			$user = Auth::user();
			$match_id = $validar['match_id'];
			$prediccion = UserPrediction::where([['user_id',$user->id], ['match_id',$match_id]])->first();
			
			if( is_null($prediccion) ) {
				
				$user_prediction = new UserPrediction($request->all());
				$user_prediction->user_id = $user->id;
				$user_prediction->save();

				return response()->json(['success'=>'Marcador guardado.']);

			} else {
				
				$user_prediction = UserPrediction::find($prediccion->id);
				$user_prediction->a_score = $request->a_score;
				$user_prediction->b_score = $request->b_score;
				$user_prediction->save();

				return response()->json(['success'=>'Marcador actualizado.']);
			}
			
		}

		return response()->json(['error'=>$validator->errors()->all()]);
		
	}

	/**
	 * Guarda la prediccion de un partido para un GRUPO
	 */
	public function storeGroup(Request $request)
	{
		// Valido con la hora del partido si es posible guardar
		$validar = $request->all();
		if ($request->match_id) {
			$match = Match::find($request->match_id);
			$hora_partido = new Carbon($match->date_time);
			$hora_partido = $hora_partido->subMinutes(3);
			$ahora = Carbon::now();
			$validar['date_time'] = $ahora->gte($hora_partido)?'':'yes';
		}
		
		// Reglas de validacion
		$validator = Validator::make($validar, [
			'match_id' => 'required',
			'a_score' => 'required',
			'b_score' => 'required',
			'date_time' => 'required'
		],[
			'match_id.required' => 'Algo falló, intenta nuevamente',
			'a_score.required' => 'Falta un marcador', 
			'b_score.required' => 'Falta un marcador', 
			'date_time.required' => 'Este partido ya está cerrado', //'Este partido ya está cerrado'
		]);

		// Si la validación pasó
		if ($validator->passes()) {
			
			// Consulto en busca de la predicción
			$user = Auth::user();
			$match_id = $validar['match_id'];
			$prediccion = GroupPrediction::where([['group_id',$user->group->id], ['match_id',$match_id]])->first();
			
			if( is_null($prediccion) ) {
				
				$group_prediction = new GroupPrediction($request->all());
				$group_prediction->group_id = $user->group->id;
				$group_prediction->save();

				return response()->json(['success'=>'Marcador guardado.']);

			} else {
				
				$group_prediction = GroupPrediction::find($prediccion->id);
				$group_prediction->a_score = $request->a_score;
				$group_prediction->b_score = $request->b_score;
				$group_prediction->save();

				return response()->json(['success'=>'Marcador actualizado.']);
			}
			
		}

		return response()->json(['error'=>$validator->errors()->all()]);
		
	}


	public function marcadores($id)
	{
		$match = Match::find($id);
		$hora_partido = new Carbon($match->date_time, $match->date_zone);
		$hora_partido = $hora_partido->subMinutes(3);
		$ahora = Carbon::now();
		$match->cerrado = $ahora->gte($hora_partido);
		if ($match->cerrado) {
			return view('predictions.index', ['match' => $match]);
		}else {
			return redirect('/')->with('status', 'Url no encontrada');
		}
	}

}
