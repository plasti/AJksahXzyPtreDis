<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserPrediction;
use App\GroupPrediction;
use App\Match;
use App\User;
use Carbon\Carbon;

class PredictionApiController extends Controller
{
    public function store(Request $request)
    {
		$data = $request->data;

    	// Valido con la hora del partido si es posible guardar
		$match = Match::find($data['id_match']);
		$hora_partido = new Carbon($match->date_time);
		$hora_partido = $hora_partido->subMinutes(3);
		$ahora = Carbon::now();
		if ($ahora->gte($hora_partido)) {
			return response()->json(['status' => 'Fail', 'data' => 'Este partido ya está cerrado.']);
		}else {
			if ($data['tipo'] == 'user') {
				$user = User::find($data['id_user']);
				$prediccion = UserPrediction::where([['user_id',$user->id], ['match_id',$match->id]])->first();
				if( is_null($prediccion) ) {
					$user_prediction = UserPrediction::create([
						'user_id' => $user->id,
						'match_id' => $match->id,
						'a_score' => $data['score_a'],
						'b_score' => $data['score_b'],
					]);
					return response()->json(['status' => 'Ok', 'data'=>'Marcador guardado.']);

				} else {
					$user_prediction = UserPrediction::find($prediccion->id);
					$user_prediction->a_score = $data['score_a'];
					$user_prediction->b_score = $data['score_b'];
					$user_prediction->update();
					return response()->json(['status' => 'Ok', 'data'=> 'Marcador actualizado.']);
				}	
			}else {					
				// Consulto en busca de la predicción
				$user = User::find($data['id_user']);
				$prediccion = GroupPrediction::where([['group_id',$user->group->id], ['match_id',$match->id]])->first();
				if( is_null($prediccion) ) {
					$user_prediction = GroupPrediction::create([
						'group_id' => $user->group->id,
						'match_id' => $match->id,
						'a_score' => $data['score_a'],
						'b_score' => $data['score_b'],
					]);
					return response()->json(['status' => 'Ok', 'data'=>'Marcador guardado.']);

				} else {
					$user_prediction = GroupPrediction::find($prediccion->id);
					$user_prediction->a_score = $data['score_a'];
					$user_prediction->b_score = $data['score_b'];
					$user_prediction->update();
					return response()->json(['status' => 'Ok', 'data'=> 'Marcador actualizado.']);
				}		
			}
		}
    }
}
