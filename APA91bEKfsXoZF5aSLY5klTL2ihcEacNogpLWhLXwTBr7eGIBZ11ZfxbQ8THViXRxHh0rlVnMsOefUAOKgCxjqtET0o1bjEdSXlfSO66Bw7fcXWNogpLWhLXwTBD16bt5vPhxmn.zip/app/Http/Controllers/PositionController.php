<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Group;

class PositionController extends Controller
{

	// Muestra la vista de las posiciones
	public function index() 
	{
		// Obtengo los usuarios
		$users = User::where('role','<>','admin')->orderBy('points','desc')->paginate(50);
		
		// Obtengo los grupos
		$groups = Group::orderBy('points', 'desc')->get();
		

		return view('posiciones.index', ['current' => 'posiciones', 'users' => $users, 'groups' => $groups]);
	}

}
