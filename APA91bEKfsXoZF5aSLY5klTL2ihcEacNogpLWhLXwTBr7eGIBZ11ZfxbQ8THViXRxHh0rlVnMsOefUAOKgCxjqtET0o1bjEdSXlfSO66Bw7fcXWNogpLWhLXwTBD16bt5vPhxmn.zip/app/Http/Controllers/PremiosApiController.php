<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserMedal;

class PremiosApiController extends Controller
{
    public function index()
    {
    	return response()->json(config('polla.premios'));
    }

    public function premios_user(Request $request)
    {
    	$data = $request->data;
    	$premios_user = UserMedal::where('user_id', $data['id'])->get();
    	$premios = [];
    	foreach ($premios_user as $p) {
    		$p->medal->img = $p->medal->img();
    		$premios[] = $p;
    	}
    	return response()->json(['status' => 'Ok', 'data' => $premios]);
    }
}
