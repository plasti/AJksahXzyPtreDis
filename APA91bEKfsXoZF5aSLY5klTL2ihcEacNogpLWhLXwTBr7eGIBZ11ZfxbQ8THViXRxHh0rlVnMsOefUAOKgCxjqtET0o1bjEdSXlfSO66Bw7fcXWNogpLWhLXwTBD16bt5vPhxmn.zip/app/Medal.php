<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Medal extends Model
{
	protected $table = 'medals';

	protected $fillable = [
		'id',
		'name',
		'desc',
		'img',
		'id_match',
		'generados',
	];

	public function img()
	{
		if ($this->img != null) {
			return asset('images/medals').'/'.$this->img;
		}
	}

	public function users()
	{
		return $this->hasMany('App\UserMedal', 'medal_id');
	}

	public function match()
	{
		return $this->belongsTo('App\Match', 'id_match');
	}
}