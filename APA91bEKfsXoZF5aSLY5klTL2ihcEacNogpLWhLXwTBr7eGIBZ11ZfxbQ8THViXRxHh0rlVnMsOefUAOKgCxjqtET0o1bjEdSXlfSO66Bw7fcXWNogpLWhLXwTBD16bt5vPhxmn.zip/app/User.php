<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 
        'email', 
        'password',
        'points',
        'position',
        'role',
        'group_id',
        'avatar',
        'document',
        'token_push',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function avatar()
    {
        if(strpos($this->avatar, 'https') === false) {
            return asset('/images/avatars').'/'.$this->avatar;
        }else {
            return $this->avatar;
        }
    }


	/**
	* Obtiene el grupo al que pertenece el usuario.
	*/
	public function group()
	{
		return $this->belongsTo('App\Group');
	}

    /**
    * Obtiene la lista de las medallas del usuario
    */
    public function medals()
    {
        return $this->hasMany('App\UserMedal', 'user_id');
    }

    /**
    * Obtiene las predicciones del usuario
    */
    public function predictions()
    {
        return $this->hasMany('App\UserPrediction', 'user_id');
    }

    /**
    * Obtiene los codigos del usuario
    */
    public function codes()
    {
        return $this->hasMany('App\UserCode', 'user_id');
    }

}
