<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Code_app extends Model
{
    protected $table = 'code_app';

	protected $fillable = [
		'code',
	];
}
