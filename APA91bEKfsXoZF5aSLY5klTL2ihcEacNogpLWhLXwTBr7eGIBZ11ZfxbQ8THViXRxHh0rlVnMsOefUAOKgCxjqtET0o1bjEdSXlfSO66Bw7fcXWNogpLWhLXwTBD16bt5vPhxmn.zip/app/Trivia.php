<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trivia extends Model
{
	protected $table = 'trivias';

	protected $fillable = [
        'estado',
        'titulo',
        'objetivo',
	];

	public function preguntas()
	{
		return $this->hasMany('App\Pregunta', 'id_trivia')->orderBy('id', 'DESC');
	}

	public function getPuntos()
	{
		$puntos = 0;
		foreach ($this->preguntas as $p) {$puntos += $p->puntos;}
		return $puntos;
	}
}
