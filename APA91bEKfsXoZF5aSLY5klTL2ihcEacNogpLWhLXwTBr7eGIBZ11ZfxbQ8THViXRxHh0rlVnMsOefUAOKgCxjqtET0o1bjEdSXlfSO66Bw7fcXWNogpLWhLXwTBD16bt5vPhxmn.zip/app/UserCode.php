<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserCode extends Model
{
	protected $table = 'user_codes';

	protected $fillable = [
		'user_id',
		'code_id',
	];

	/**
	* Obtiene la info del codigo
	*/
	public function code()
	{
		return $this->belongsTo('App\Code', 'code_id');
	}

}
