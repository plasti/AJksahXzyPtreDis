<?php

use Illuminate\Database\Seeder;

class MatchsTableSeeder extends Seeder
{
	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		// primera fase
		DB::table('matchs')->insert([
			'team_id_a' => 3,
			'team_id_b' => 10,
			'date_time' => '2021-06-13 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 5,
			'team_id_b' => 6,
			'date_time' => '2021-06-13 19:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 1,
			'team_id_b' => 4,
			'date_time' => '2021-06-14 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 7,
			'team_id_b' => 2,
			'date_time' => '2021-06-14 19:00:00',
			'date_zone' => 'America/Bogota',
		]);

		// segunda fase
		DB::table('matchs')->insert([
			'team_id_a' => 5,
			'team_id_b' => 10,
			'date_time' => '2021-06-17 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 3,
			'team_id_b' => 8,
			'date_time' => '2021-06-17 19:00:00',
			'date_zone' => 'America/Bogota',
		]);

		DB::table('matchs')->insert([
			'team_id_a' => 4,
			'team_id_b' => 2,
			'date_time' => '2021-06-18 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 1,
			'team_id_b' => 9,
			'date_time' => '2021-06-18 19:00:00',
			'date_zone' => 'America/Bogota',
		]);


		// tercer fase
		DB::table('matchs')->insert([
			'team_id_a' => 10,
			'team_id_b' => 6,
			'date_time' => '2021-06-20 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 5,
			'team_id_b' => 8,
			'date_time' => '2021-06-20 19:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 9,
			'team_id_b' => 4,
			'date_time' => '2021-06-21 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 1,
			'team_id_b' => 7,
			'date_time' => '2021-06-21 19:00:00',
			'date_zone' => 'America/Bogota',
		]);


		// cuarta fase
		DB::table('matchs')->insert([
			'team_id_a' => 6,
			'team_id_b' => 8,
			'date_time' => '2021-06-23 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 3,
			'team_id_b' => 5,
			'date_time' => '2021-06-23 19:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 2,
			'team_id_b' => 9,
			'date_time' => '2021-06-24 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 4,
			'team_id_b' => 7,
			'date_time' => '2021-06-24 19:00:00',
			'date_zone' => 'America/Bogota',
		]);


		// quinta fase
		DB::table('matchs')->insert([
			'team_id_a' => 3,
			'team_id_b' => 6,
			'date_time' => '2021-06-27 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 10,
			'team_id_b' => 8,
			'date_time' => '2021-06-27 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 9,
			'team_id_b' => 7,
			'date_time' => '2021-06-28 19:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 2,
			'team_id_b' => 1,
			'date_time' => '2021-06-28 19:00:00',
			'date_zone' => 'America/Bogota',
		]);


		// *******************
		// cuartos de final
		// *******************
		DB::table('matchs')->insert([
			'team_id_a' => 11,
			'team_id_b' => 12,
			'date_time' => '2021-07-02 16:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 13,
			'team_id_b' => 14,
			'date_time' => '2021-07-02 19:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 15,
			'team_id_b' => 16,
			'date_time' => '2021-07-03 17:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 17,
			'team_id_b' => 18,
			'date_time' => '2021-07-03 20:00:00',
			'date_zone' => 'America/Bogota',
		]);


		// *******************
		// semifinales
		// *******************
		DB::table('matchs')->insert([
			'team_id_a' => 19,
			'team_id_b' => 20,
			'date_time' => '2021-07-05 18:00:00',
			'date_zone' => 'America/Bogota',
		]);
		DB::table('matchs')->insert([
			'team_id_a' => 21,
			'team_id_b' => 22,
			'date_time' => '2021-07-06 20:00:00',
			'date_zone' => 'America/Bogota',
		]);


		// *******************
		// tercer puesto
		// *******************
		DB::table('matchs')->insert([
			'team_id_a' => 23,
			'team_id_b' => 24,
			'date_time' => '2021-07-09 19:00:00',
			'date_zone' => 'America/Bogota',
		]);

		// *******************
		// final
		// *******************
		DB::table('matchs')->insert([
			'team_id_a' => 25,
			'team_id_b' => 26,
			'date_time' => '2021-07-10 19:00:00',
			'date_zone' => 'America/Bogota',
		]);
	}
}
