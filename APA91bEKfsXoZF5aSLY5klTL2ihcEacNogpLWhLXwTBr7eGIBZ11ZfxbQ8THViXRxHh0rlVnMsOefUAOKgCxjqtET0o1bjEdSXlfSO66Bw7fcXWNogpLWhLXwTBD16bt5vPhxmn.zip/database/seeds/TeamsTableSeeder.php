<?php

use Illuminate\Database\Seeder;


class TeamsTableSeeder extends Seeder
{
	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */

	/*
	
	__________________________________________________________________________

	 Aca va el registro de los equipos que van a participar en el campeonato  
	___________________________________________________________________________

	los ID son muy importantes para la creacion de los partidos en
	el seeder de MatchsTableSeeder

	debes revisar tambien el controlador en app/Http/Controllers/MatchController.php
	apartir de la linea 89 se comienza a calcular las rondas del torneo

	*/


	public function run()
	{
		DB::table('teams')->insert([
			'id' => 1,
			'country' => 'Argentina',
			'flag' => 'argentina.png',
			'group' => 'A',
		]);

		DB::table('teams')->insert([
			'id' => 2,
			'country' => 'Bolivia',
			'flag' => 'bolivia.png',
			'group' => 'A',
		]);
		DB::table('teams')->insert([
			'id' => 3,
			'country' => 'Brasil',
			'flag' => 'brazil.png',
			'group' => 'B',
		]);

		DB::table('teams')->insert([
			'id' => 4,
			'country' => 'Chile',
			'flag' => 'chile.png',
			'group' => 'A',
		]);

		DB::table('teams')->insert([
			'id' => 5,
			'country' => 'Colombia',
			'flag' => 'colombia.png',
			'group' => 'B',
		]);

		DB::table('teams')->insert([
			'id' => 6,
			'country' => 'Ecuador',
			'flag' => 'ecuador.png',
			'group' => 'B',
		]);

		DB::table('teams')->insert([
			'id' => 7,
			'country' => 'Paraguay',
			'flag' => 'paraguay.png',
			'group' => 'A',
		]);

		DB::table('teams')->insert([
			'id' => 8,
			'country' => 'Perú',
			'flag' => 'peru.png',
			'group' => 'B',
		]);

		DB::table('teams')->insert([
			'id' => 9,
			'country' => 'Uruguay',
			'flag' => 'uruguay.png',
			'group' => 'A',
		]);

		DB::table('teams')->insert([
			'id' => 10,
			'country' => 'Venezuela',
			'flag' => 'venezuela.png',
			'group' => 'B',
		]);
		

		// ***************************
		// PRIMEROS PUESTOS DE GRUPO
		// ***************************
		DB::table('teams')->insert([
			'id' => 11,
			'country' => '2° Grupo B',
		]);
		DB::table('teams')->insert([
			'id' => 12,
			'country' => '3° Grupo A',
		]);
		DB::table('teams')->insert([
			'id' => 13,
			'country' => '1° Grupo B',
		]);
		DB::table('teams')->insert([
			'id' => 14,
			'country' => '4° Grupo A',
		]);

		DB::table('teams')->insert([
			'id' => 15,
			'country' => '2° Grupo A',
		]);
		DB::table('teams')->insert([
			'id' => 16,
			'country' => '3° Grupo B',
		]);
		DB::table('teams')->insert([
			'id' => 17,
			'country' => '1° Grupo A',
		]);
		DB::table('teams')->insert([
			'id' => 18,
			'country' => '4° Grupo B',
		]);


		// ******************
		// SEMIFINAL
		// ******************
		DB::table('teams')->insert([
			'id' => 19,
			'country' => 'Ganador partido 2',
		]);
		DB::table('teams')->insert([
			'id' => 20,
			'country' => 'Ganador partido 1',
		]);


		DB::table('teams')->insert([
			'id' => 21,
			'country' => 'Ganador partido 4',
		]);
		DB::table('teams')->insert([
			'id' => 22,
			'country' => 'Ganador partido 3',
		]);


		// ****************************
		// TERCER PUESTO
		// ****************************

		DB::table('teams')->insert([
			'id' => 23,
			'country' => 'Perdedor partido II',
		]);
		DB::table('teams')->insert([
			'id' => 24,
			'country' => 'Perdedor partido I',
		]);

		// *******
		// FINAL
		// *******
		DB::table('teams')->insert([
			'id' => 25,
			'country' => 'Ganador partido II',
		]);
		DB::table('teams')->insert([
			'id' => 26,
			'country' => 'Ganador partido I',
		]);
	}
}
