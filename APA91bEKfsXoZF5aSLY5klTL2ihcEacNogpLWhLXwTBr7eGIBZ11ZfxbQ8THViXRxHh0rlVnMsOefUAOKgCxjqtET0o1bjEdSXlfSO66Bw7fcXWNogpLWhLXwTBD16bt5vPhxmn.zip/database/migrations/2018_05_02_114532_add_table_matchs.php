<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTableMatchs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('matchs', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('team_id_a')->unsigned();
            $table->tinyInteger('score_a')->nullable();
            $table->integer('team_id_b')->unsigned();
            $table->tinyInteger('score_b')->nullable();
            $table->dateTime('date_time');
            $table->string('date_zone', 150)->nullable();
            $table->tinyInteger('updated')->default(0);
            $table->timestamps();

            $table->foreign('team_id_a')->references('id')->on('teams');
            $table->foreign('team_id_b')->references('id')->on('teams');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('matchs');
    }
}
