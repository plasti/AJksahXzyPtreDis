$(document).ready(function () {
	function Confirm(text, callback) {
		var html = '<div class="confirm">';
		html += '<p>'+text+'</p>';
	    html += '<a href="#" id="cancelar_confirm">Cancelar</a>';
		html += '<a href="#" id="aceptar_confirm">Aceptar</a>';
	    html += '</div>';
	    $('body').append(html);

	    document.getElementById('aceptar_confirm').addEventListener('click',() => {
				callback();
				$('.confirm').hide(200);
				setTimeout(() => {
					$('.confirm').remove();
				}, 300);
		},false);

		document.getElementById('cancelar_confirm').addEventListener('click',() => {
				$('.confirm').hide(200);
				setTimeout(() => {
					$('.confirm').remove();
				}, 300);
		},false);
	}

	$(document).on('click', '#eliminar-algo', function (e) {
		e.preventDefault();
		var url = $(this).attr('href');
		Confirm('¿Realmente desea proceder?', () => window.location.href=url);
	});

	$('#cerrar-modal-tutorial').click(function () {
		$('.modal-tutorial').fadeOut(200);
	});

	$('#cerrar-modal-tutorial-btn').click(function (e) {
		e.preventDefault();
		$('.modal-tutorial').fadeOut(200);
	})

	$('#abrir-modal-tutorial').click(function (e) {
		e.preventDefault();
		$('.modal-tutorial').fadeIn(200);
	})

	$('#Eliminar_pregunta').click(function (e) {
		e.preventDefault();
		var url = $(this).attr('href');
		Confirm('¿Realmente desea eliminar esta pregunta?', () =>  {
			window.location.href=url;
		});
	});

	$('#eliminar_codigo').click(function (e) {
		e.preventDefault();
		var url = $(this).attr('href');
		Confirm('¿Realmente desea eliminar este codigo?', () =>  {
			window.location.href=url;
		});
	});


	$('#eliminar-premio-medal').click(function (e) {
		e.preventDefault();
		var url = $(this).attr('href');
		Confirm('¿Realmente desea eliminar este premio?', () => {
			window.location.href=url;
			console.log('eliminar')
		});
	});
});