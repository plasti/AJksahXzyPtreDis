$(document).ready(function(){

	$('.btn-datos').click(function(){
		$('.form-edit').slideToggle();
		$('html, body').animate({
			scrollTop: $('form').offset().top - 140
		}, 600);
	});

});