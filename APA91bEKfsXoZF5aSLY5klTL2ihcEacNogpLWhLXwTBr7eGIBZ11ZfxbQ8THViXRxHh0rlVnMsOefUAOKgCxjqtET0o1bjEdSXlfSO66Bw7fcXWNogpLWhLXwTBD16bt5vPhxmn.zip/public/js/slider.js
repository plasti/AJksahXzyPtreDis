$(document).ready(function () {
	$('.banner-big > .sliders').slick({
		dots: false,
		arrows: true,
		infinite: true,
		speed: 600,
		slidesToShow: 1,
		slidesToScroll: 1,
		autoplay: true,
		responsive: [
		]
	});
});