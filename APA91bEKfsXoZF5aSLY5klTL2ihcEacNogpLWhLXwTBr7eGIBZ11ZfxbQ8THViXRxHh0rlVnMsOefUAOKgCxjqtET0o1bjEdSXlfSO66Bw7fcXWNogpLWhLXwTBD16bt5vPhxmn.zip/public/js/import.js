$(document).ready(function() {
	
	function pointsPredictionUser() {
		$('.loader').show();
		var urlPredUser = $('.urlPredUser').val();
		var token = $('input[name=_token]').val();
		$('.ul-respuesta').append('<li>Calculando puntos de las predicciones de los usuarios');
		$.ajax({
			type: 'POST',
			url: urlPredUser,
			data: {
				_token: token,
			},
			success: function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				// Calcular puntos usuario
				pointsUser();
			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	} 

	function pointsUser() {
		var urlPointsUser = $('.urlPointsUser').val();
		var token = $('input[name=_token]').val();
		$('.ul-respuesta').append('<li>Calculando puntos de los usuarios');
		$.ajax({
			type: 'POST',
			url: urlPointsUser,
			data: {
				_token: token,
			},
			success:  function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				// Calcular las posiciones de los usuarios
				positionUser();
			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	}

	function positionUser() {
		var urlPositionUser = $('.urlPositionUser').val();
		var token = $('input[name=_token]').val();
		$('.ul-respuesta').append('<li>Calculando posiciones de los usuarios');
		$.ajax({
			type: 'POST',
			url: urlPositionUser,
			data: {
				_token: token,
			},
			success:  function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				// Si uso de grupos - Calcular puntos predicciones grupo
				if ($('.urlPredGroup').val()) {
					pointsPredictionGroup();
				}else{
					// Cambiar el estado del partido actualizado
					endImport();

				}
			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	}

	function pointsPredictionGroup() {
		var urlPredGroup = $('.urlPredGroup').val();
		var token = $('input[name=_token]').val();
		$('.ul-respuesta').append('<li>Calculando puntos de las predicciones de los grupos');
		$.ajax({
			type: 'POST',
			url: urlPredGroup,
			data: {
				_token: token,
			},
			success:  function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				// Si uso de grupos - Calcular puntos grupo
				pointsGroup();
			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	}

	function pointsGroup() {
		var urlPointsGroup = $('.urlPointsGroup').val();
		var token = $('input[name=_token]').val();
		$('.ul-respuesta').append('<li>Calculando puntos de los grupos');
		$.ajax({
			type: 'POST',
			url: urlPointsGroup,
			data: {
				_token: token,
			},
			success:  function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				// Si uso de grupos - Calcular posiciones grupo
				positionGroup();
			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	}

	function positionGroup() {
		var urlPositionGroup = $('.urlPositionGroup').val();
		var token = $('input[name=_token]').val();
		$('.ul-respuesta').append('<li>Calculando posiciones de los grupos');
		$.ajax({
			type: 'POST',
			url: urlPositionGroup,
			data: {
				_token: token,
			},
			success:  function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				// Cambiar el estado del partido actualizado
				endImport();

			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	}

	function endImport() {
		var urlMatchUpdate = $('.urlMatchUpdate').val();
		var token = $('input[name=_token]').val();
		$.ajax({
			type: 'POST',
			url: urlMatchUpdate,
			data: {
				_token: token,
			},
			success:  function(respuesta){  
				$('.ul-respuesta').append('<li>' + respuesta + '</li>');
				$('.loader').hide();
			},
			error: function(objXMLHttpRequest){ $('.loader').hide(); }
		});
	}

	// Inicio el proceso calculando los puntos de las predicciones por usuario
	pointsPredictionUser();


});