function sonido() {
	var r = document.querySelector('body').getAttribute("asset");
	var audio = new Audio();
	audio.src = r+"/sounds/notificacion.mp3";
	setTimeout(() => audio.play(), 100);
}

function unfade(element) {
    var op = 0.1;  // initial opacity
    element.style.display = 'block';
    var timer = setInterval(function () {
        if (op >= 1){
            clearInterval(timer);
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 10);
}
function fade(element) {
    var op = 1;  // initial opacity
    var timer = setInterval(function () {
        if (op <= 0.1){
            clearInterval(timer);
            element.style.display = 'none';
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op -= op * 0.1;
    }, 10);
}

function Notificacion(data, id) {
	if (data.data.id_polla == document.querySelector('body').getAttribute("id_polla") && data.data.id_user == id) {
		var r = document.querySelector('body').getAttribute("asset");
		sonido();
		setTimeout(() => {
			document.getElementById('icono_notificacion_header').animate([
				{ transform: 'translateX(0px)' },
				{ transform: 'translateX(-10px)' },
				{ transform: 'translateX(10px)' },
				{ transform: 'translateX(-5px)' },
				{ transform: 'translateX(5px)' },
				{ transform: 'translateX(0px)' },
			],{
				duration: 500,
			});
			unfade(document.getElementById('bola_notificacion'));
			document.getElementById("icono_notificacion").setAttribute('src', r+'/images/notificaciones/'+data.data.icono);
			document.getElementById("title_notificacion").innerHTML = data.data.titulo;
			document.getElementById("content_notificacion").innerHTML = data.data.descripcion;
			document.getElementById("boton_notificacion").setAttribute('href', data.data.link);
			unfade(document.querySelector('.notificacion-fixed'));
			setTimeout(() =>  {
				fade(document.querySelector('.notificacion-fixed'));
			}, 7000);
		}, 400);
	}
}

document.querySelector('.cerrar-notificacion').addEventListener('click', function (e) {
	e.preventDefault();
	fade(document.querySelector('.notificacion-fixed'));
});
