$(document).ready(function(){

	// Botón de aumentar marcador
	$('.btn-plus').click(function(){
		var campo = $(this).val();
		if ($('input.' + campo).val() == '') {
			$('input.' + campo).val( 0 );
			$('button.' + campo).show();
			$('div.' + campo).addClass('pendiente').removeClass('ok').removeClass('error');
		}
		if ($('input.' + campo).val() < 9) {
			$('input.' + campo).val( parseInt( $('input.' + campo).val() ) + 1 );
			$('button.' + campo).show();
			$('div.' + campo).addClass('pendiente').removeClass('ok').removeClass('error');
		}
	});
	// Botón de disminuir marcador
	$('.btn-minus').click(function(){
		var campo = $(this).val();
		
		if ($('input.' + campo).val() == '') {
			$('input.' + campo).val( 0 );
			$('button.' + campo).show();
			$('div.' + campo).addClass('pendiente').removeClass('ok').removeClass('error');
		}
		if ($('input.' + campo).val() > 0) {
			$('input.' + campo).val( parseInt( $('input.' + campo).val() ) - 1 );
			$('button.' + campo).show();
			$('div.' + campo).addClass('pendiente').removeClass('ok').removeClass('error');
		}
	});

	// Acción al cambiar marcador
	$('input.score').change(function(){
		if ($(this).val() > 9) {
			$(this).val(9);
		}
		if ($(this).val() < 0) {
			$(this).val(0);
		}
		var campo = $(this).attr('name');
		$('button.' + campo).show();
		$('div.' + campo).addClass('pendiente').removeClass('ok').removeClass('error');
	});

	// Guardar los datos del partido
	$('.save-match').click(function(){
		
		var campo = $(this).attr('name');
		var url = $('input[name=urlsave]').val();
		var match_id = $(this).attr('id').replace('p', '');
		var a_score = $('input.p' + match_id + '-t1').val();
		var b_score = $('input.p' + match_id + '-t2').val();
		
		$.post(
			url, 
			{
				_token: $('input[name=_token]').val(),
				match_id: match_id,
				a_score: a_score,
				b_score: b_score,
				date_time: '',
			}, 
			function(data){
				//$('label.' + campo).html(data.respuesta);
				if($.isEmptyObject(data.error)){
					$('label.' + campo).html(data.success).addTempClass( 'exito', 3000 );
					$('div.' + campo).addClass('ok').removeClass('pendiente').removeClass('error');
					$('button.' + campo).hide();
				}else{
					$('label.' + campo).html(data.error[0]).addTempClass( 'error', 3000 );
					$('div.' + campo).addClass('error').removeClass('ok').removeClass('pendiente');
				}
				
			}
		);
	});

	// Ir al dia de hoy
	var f = new Date();
	var ancla = '.' + (f.getMonth()+1) + '-' + f.getDate();
	if ($('a'+ancla).length) {
		$('html, body').animate({
			scrollTop: $(ancla).offset().top - 120
		}, 1000);	
	}

	// window.onbeforeunload = confirmExit;
 //  function confirmExit()
 //  {
 //    return "Ha intentado salir de esta pagina. Si ha realizado algun cambio en los campos sin hacer clic en el boton Guardar, los cambios se perderan. Seguro que desea salir de esta pagina? ";
 //  }

});

/*
 * addTempClass
 * jQuery plugin for add a class to an element for a custom time.
 * Support callbacks when class is removed.
 *
 * @param   {string}    className   The class to add
 * @param   {number}    expire      Time in miliseconds before remove the new class
 * @param   {function}  callback    The function invoked after remove the class
 * @return  void
 *
 * Ej.: $( 'body' ).addTempClass( 'myClass', 2000, function () { console.log( 'tada!') } );
 */
( function ( $ ) {
    'use strict';
    $.fn.addTempClass = function ( className, expire, callback ) {
        className || ( className = '' );
        expire || ( expire = 1500 );
        return this.each( function () {
            $( this ).addClass( className ).delay( expire ).queue( function () {
                $( this ).removeClass( className ).clearQueue();
                callback && callback();
            } );
        } );
    };
} ( jQuery ) );