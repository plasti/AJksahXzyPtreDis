$(document).ready(function(){
	var barra = null;
	var id = null;
	var url = $('#ruta_respuesta').val();
	var token = $('input[name="_token"]').val();

	function SonidoApp(sonido) {
		var r = $('body').attr('asset');
		var audio = new Audio();
		audio.src = r+"/sounds/"+sonido;
		setTimeout(() => audio.play(), 100);
	}
	function conteo() {
		var n = 3;
		var interval = setInterval(function () {
			SonidoApp('step.mp3');
			$('.contador-modal > span').text(n);
			if (n == 0) {
				clearInterval(interval);
				next();
				SonidoApp('timeout.mp3')
				$('.contador-modal').fadeOut(500);
			}
			n--
		}, 1000);		
	}
	conteo();

	function set_bar(time) {
		var w = 100;
		var newtime = time;
		barra = setInterval(() => {
			newtime--
			w = newtime * 100 / time; 
			$('#bar_'+id).css('width', w+'%');
			$('#clock_'+id).text(newtime+' Segundos');
			if (newtime == 3 || newtime == 2 || newtime == 1) {
				SonidoApp('step.mp3')
			}
			if (newtime == 0) {
				clearInterval(barra);
				barra = null;
				$('.modal-loader').fadeIn(100);
				sendRespuesta('TimeOut');
				SonidoApp('timeout.mp3')
			}
		}, 1000);
	}

	function next() {
		$('.contador-modal').fadeOut(100);
		$('.modal-loader').fadeOut(100);
		$('.wrapper-confeti').fadeOut(100);
		$('.mensaje-trivia').fadeOut(100);
		var element =  $('.card-trivia').first();
		if (element.length > 0) {
			element.fadeIn(500);
			id = element.attr('item');
			set_bar(element.attr('time'));
		}else {
			window.location.href = $('#ruta_fin').val();
		}
	}

	function mensajeTrivia(msg) {
		var html = '<p>'+msg+'</p>';
		$('.mensaje-trivia').html(html);
		$('.mensaje-trivia').fadeIn(100);
	}

	function sendRespuesta(respuesta) {
		$.post(url, {
			id: id,
			respuesta: respuesta,
			_token: token, 
		}, function (data) {
			if (data.status == 'Ok') {
				$('.modal-loader').fadeOut(100);
				if (data.data == 'Gana') {
					$('.wrapper-confeti').fadeIn(100);
					SonidoApp('winer.mp3')
					mensajeTrivia(data.msg);
					$('#trivia_'+id).fadeOut(500);
				}
				if (data.data == 'Pierde') {
					SonidoApp('loser.mp3')
					mensajeTrivia(data.msg);
					$('#trivia_'+id).fadeOut(500);
				}
				if (data.data == 'TimeOut') {
					mensajeTrivia(data.msg);
					$('.modal-loader').fadeIn(100);
					$('#trivia_'+id).fadeOut(500);
				}

				setTimeout(() => {
					$('#trivia_'+id).remove();
					id = null;
				}, 700);

				setTimeout(() => {
					next();
				}, 5000);
			}
		});
	}

	$(document).on('click', '#selecet_respuesta', function (e) {
		e.preventDefault();
		if (id != null) {
			clearInterval(barra);
			barra = null;
			$('.modal-loader').fadeIn(100);
			sendRespuesta($(this).attr('class'));
		}
	});

});