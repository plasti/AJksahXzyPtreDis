$(document).ready(function(){
	
	function Confirm(text, callback) {
		var html = '<div class="confirm">';
		html += '<p>'+text+'</p>';
	    html += '<a href="#" id="cancelar_confirm">Cancelar</a>';
		html += '<a href="#" id="aceptar_confirm">Aceptar</a>';
	    html += '</div>';
	    $('body').append(html);

	    document.getElementById('aceptar_confirm').addEventListener('click',(e) => {
				callback();
				$('.confirm').hide(200);
				setTimeout(() => {
					$('.confirm').remove();
				}, 300);
		},false);

		document.getElementById('cancelar_confirm').addEventListener('click',(e) => {
				$('.confirm').hide(200);
				setTimeout(() => {
					$('.confirm').remove();
				}, 300);
		},false);
	}


	$('.comentar-btn').click(function(e){
		e.preventDefault();
		if (!($(this).hasClass('loading'))) {
			if ($('#comentario').val() != '' && $('#comentario').val() != null) {
				$(this).addClass('loading');
				var url = $(this).attr('url');
				url+= '?text='+$('#comentario').val();
				$.get(url, function (data) {
					$('.comentar-btn').removeClass('loading');
					$('#comentario').val('');
					if (data.status == 'Ok') {
						var html = '';
						html += '<div class="comentario" id="comentario_app_'+data.data.id+'">'
						html += '<span class="eliminar-comentario" title="Eliminar comentario" item="'+data.data.ruta+'">x</span>'
							html += '<div class="header-comentario">'
								html += '<div class="cintainer-avatar">'
									html += '<img src="'+data.data.avatar+'" alt="avatar">'
								html += '</div>'
								html += '<strong>'+data.data.name+'</strong>'
							html += '</div>'
							html += '<div class="text">'+data.data.text+'</div>'
							html += '<span class="fecha">'+data.data.fecha+'</span>'
						html += '</div>'
						$('#comentarios-all').prepend(html);
					}
				})
			}
		}
	});

	$(document).on('click', '.eliminar-comentario', function (e) {
		e.preventDefault();
		var url = $(this).attr('item');
		Confirm('¿Realmente desea eliminar este comentario?', () =>  {
			$.get(url, function (data) {
				$('#comentario_app_'+data.data.id).remove();
			});
		});
	})
})