@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Intrucciones</span></h1>
			<h2>Cómo jugar</h2>
			{{-- <div class="editado">
				
			</div> --}}
			<h2>Plan de premios</h2>
			{{-- <div class="editado">
				
			</div> --}}
		</section>
		
	</main>
@endsection