@extends('layouts.app')

@section('content')
	<main>
		<section>
			<h1>App mobile</h1>
			<div class="qr-img">
				@php
					$objet = [
						'name' => config('polla.name'),
						'generated' => "polla",
						'primary' => config('polla.primario'),
						'secondary' => config('polla.secundario'),
						'tertiary' => config('polla.terciario'),
						'background' => asset('images/campo768.jpg'),
						'logo' => asset('images/logo-2.png'),
						'host' => $_SERVER['SERVER_NAME'],
						'register' => config('polla.register'),
					];
				@endphp
				{!! QrCode::size(400)->backgroundColor(0,0,0,0)->color(255,255,255)->generate(json_encode($objet)); !!}
			</div>
			<div class="btn-stores">
				<a href="#">
					<img src="{{asset('images/googleplay.png')}}">
					Play store
				</a>
				<a href="#">
					<img src="{{asset('images/apple.png')}}">
					App store
				</a>
			</div>
		</section>
	</main>
@endsection