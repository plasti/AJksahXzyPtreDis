@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Plan de premios</span></h1>
			@foreach(config('polla.premios') as $premio)
				<h2>{{$premio['titulo']}}</h2>
				<div class="editado">
					<img class="premio-plan" src="{{asset('images')}}/{{$premio['img']}}" alt="{{$premio['titulo']}}">
					<p>{{$premio['descripcion_larga']}}</p>
				</div>
			@endforeach

			{{-- <h2>CUARTO, QUINTO, SEXTO, S&Eacute;PTIMO, Y OCTAVO PUESTO:</h2> --}}
			{{-- <div class="editado">
				
			</div> --}}
		</section>
		
	</main>
@endsection