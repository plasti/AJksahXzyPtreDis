@if($sliders->count() > 0)
<div class="sliders">
	@foreach($sliders as $slider)
		@if($slider->link != null)
			<a href="{{$slider->link}}" target="_blank" class="slider">
				<img src="{{$slider->img()}}">
			</a>
		@else
			<div class="slider">
				<img src="{{$slider->img()}}">
			</div>
		@endif
	@endforeach
</div>
@endif