@if($widget->estado == 'Activo' && $widget->titulo != null && ($widget->wpp != null || $widget->tel != null))
	<div class="widget" style="background-color: {{$widget->color}}">
		<h2>{{$widget->titulo}}</h2>
		<div class="btns">
			@if($widget->tel != null)
				<a href="#" class="icon-phone">{{$widget->tel}}</a>
			@endif
			@if($widget->wpp != null)
				<a href="#" class="icon-whatsapp">{{$widget->wpp}}</a>
			@endif
		</div>
	</div>
@endif