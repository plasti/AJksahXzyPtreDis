@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Tabla de posiciones</span></h1>
		</section>

		{{--
		<section class="form-search">
			<form action="index.php?view=posiciones" method="post" accept-charset="utf-8">
				<input type="text" name="buscar" value="">
				<button type="submit" name="" value="" class="btn-buscar icon-search2"></button>
			</form>
		</section>
		--}}

		<article>
			
			<section class="posiciones">
				
				@if (config('polla.groups'))
					<h3 class="icon icon-user">Individual</h3>
				@endif
				<p>Puntos</p>
				
				@foreach ($users as $user)
					<div class="position {{ $user->position == 1 ? 'primero':'' }}">
						<div class="circle">
							<div class="img">
								<img src="@if(strpos($user->avatar, 'https') === false) {{ asset('/images/avatars') }}/{{ $user->avatar }} @else {{$user->avatar}} @endif" alt="avatar">
							</div>

							<span class="in-circle">{{ $user->position }}</span>
						</div>
						<div class="pos-info">
							<span class="puntos">{{ $user->points }}</span>
							<span class="nombre-tabla">
								<div class="jugador">{{ $user->name }}</div>
								@if (config('polla.groups'))
									<div class="grupo">{{ $user->group->name }}</div>
								@endif
							</span>
						</div>
					</div>
				@endforeach
				
				{{ $users->links() }}
			</section>
				
		</article>

			@if (config('polla.groups'))
				<aside>
					<section class="posiciones">
						<h3 class="icon icon-user-group">Grupal</h3>
						<p>Puntos</p>
						
						@foreach ($groups as $group)
							<div class="position @if ($group->position == 1) primero 
								@elseif($group->position == 2) segundo @elseif($group->position == 3) tercero @endif">
								<div class="circle">
									<span class="pos-grupo">{{ $group->position }}</span>
								</div>
								<div class="pos-info">
									<span class="puntos">{{ $group->points }}</span>
									<span class="nombre-tabla">{{ $group->name }}</span>
								</div>
							</div>
						@endforeach
						
					</section>
					
				</aside>
				
			@endif

	</main>
@endsection