@extends('layouts.app')

@section('content')
	<main>
		<section>
			<h1 style="margin: 0;"><span>{{$trivia->titulo}}</span></h1>
		</section>
		<div class="contador-modal"><span></span></div>

		<div id="cards-trivias">
			@foreach($trivia->preguntas as $pregunta)
				@if($pregunta->respuesta(Auth::user()->id) == null)
					<div class="card-trivia" item="{{$pregunta->id}}" time="{{$pregunta->tiempo}}" id="trivia_{{$pregunta->id}}">
						@if($pregunta->imagen != null)
							<div class="container-img">
								<img src="{{$pregunta->imagen()}}" alt="">
							</div>
						@endif
						<p>{{$pregunta->pregunta}}</p>
						<span class="time icon-clock" id="clock_{{$pregunta->id}}">{{$pregunta->tiempo}} Segundos</span>
						<div class="progreso"><span id="bar_{{$pregunta->id}}"></span></div>
						<div class="respuestas">
							<a class="A" item="{{$pregunta->id}}" id="selecet_respuesta" href="#">
								<span>A</span> {{$pregunta->opcion_a}}
							</a>
							<a class="B" item="{{$pregunta->id}}" id="selecet_respuesta" href="#">
								<span>B</span> {{$pregunta->opcion_b}}
							</a>
							<a class="C" item="{{$pregunta->id}}" id="selecet_respuesta" href="#">
								<span>C</span> {{$pregunta->opcion_c}}
							</a>
							<a class="D" item="{{$pregunta->id}}" id="selecet_respuesta" href="#">
								<span>D</span> {{$pregunta->opcion_d}}
							</a>
						</div>
					</div>
				@endif
			@endforeach
		</div>
	</main>
	
	<div class="mensaje-trivia">
	</div>

	<div class="modal-loader"><span></span></div>
	@include('trivias.partials.confeti')
	<input type="hidden" id="ruta_respuesta" value="{{route('trivia.respuesta')}}">
	<input type="hidden" id="ruta_fin" value="{{route('trivia.calcular')}}">
	{{ csrf_field() }}
@endsection
@section('scripts')
	<script src="{{ asset('js/trivia.js') }}"></script>
@endsection