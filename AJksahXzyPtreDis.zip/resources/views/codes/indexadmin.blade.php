@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Lista de codigos</span></h1>
		</section>

		<section class="form-search">
			<a href="{{route('codes.admin.import')}}" class="btn" style="float: right; margin-left: 15px;">Importar codigos ( .CSV )</a>
		</section>

		<article>
			<section class="posiciones">
				@foreach ($codigos as $codigo)
					<div class="position">
						<div class="pos-info" style="padding-bottom: 20px; margin-left: 0;">
							<span class="puntos">
								<a href="{{route('codes.admin.delete', $codigo->id)}}" id="eliminar_codigo" class="btn">Eliminar</a>
							</span>
							<span class="nombre-tabla">
								<div class="jugador">{{ $codigo->code }}</div>
							</span>
						</div>
					</div>
				@endforeach
				{{ $codigos->links() }}
			</section>
		</article>
	</main>
@endsection