@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Nuevo slider</span></h1>

			<section class="form-edit">
				<form action="{{ route('sliders.store') }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}

					<div class="fila-form{{ $errors->has('img') ? ' has-error' : '' }}">
						<label for="img">Imagen ( Dimensiones 900 x 300 )</label>
						<input type="file" name="img" id="img">
						@if ($errors->has('img'))
							<span class="valida-msg">
								<strong>{{ $errors->first('img') }}</strong>
							</span>
						@endif
						@if ($error_extension)
							<span class="valida-msg">
								<strong>Solo se aceptan imágenes .jpg o .png</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre</label>
						<input type="text" name="name" id="name" value="{{ old('name') }}">
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('link') ? ' has-error' : '' }}">
						<label for="link">Enlace (opcional)</label>
						<input type="text" name="link" placeholder="https://" id="link" value="{{ old('link') }}">
						@if ($errors->has('link'))
							<span class="valida-msg">
								<strong>{{ $errors->first('link') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('status') ? ' has-error' : '' }}">
						<label for="status">Estado</label>
						<select name="status" id="status">
							<option value="">Seleccionar..</option>
							<option value="Si">Activo</option>
							<option value="No">Inactivo</option>
						</select>
						@if ($errors->has('status'))
							<span class="valida-msg">
								<strong>{{ $errors->first('status') }}</strong>
							</span>
						@endif
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection