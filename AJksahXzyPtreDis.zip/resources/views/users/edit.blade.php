@extends('layouts.app')

@section('content')
	<main>

		<section>
			<h1><span>Configuración</span></h1>

			<section class="form-edit">
				<form action="{{ route('users.update', $user->id) }}" method="post" accept-charset="utf-8" enctype="multipart/form-data">
					{{ csrf_field() }}
					<div class="avatar-edit">
						<img src="{{$user->avatar()}}" alt="avatar">
					</div>

					<div class="fila-form{{ $errors->has('avatar') ? ' has-error' : '' }}">
						<label for="avatar">Cambiar imagen de perfil</label>
						<input type="file" name="avatar" id="avatar">
						@if ($errors->has('avatar'))
							<span class="valida-msg">
								<strong>{{ $errors->first('avatar') }}</strong>
							</span>
						@endif
						@if ($error_extension)
							<span class="valida-msg">
								<strong>Solo se aceptan imágenes .jpg o .png</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('name') ? ' has-error' : '' }}">
						<label for="name">Nombre</label>
						<input type="text" name="name" id="name" value="{{ old('name', $user->name) }}">
						@if ($errors->has('name'))
							<span class="valida-msg">
								<strong>{{ $errors->first('name') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form{{ $errors->has('password') ? ' has-error' : '' }}">
						<label for="password">Contraseña</label>
						<input id="password" type="password" name="password" placeholder="*********">
						@if ($errors->has('password'))
							<span class="valida-msg">
								<strong>{{ $errors->first('password') }}</strong>
							</span>
						@endif
					</div>

					<div class="fila-form">
						<label for="password-confirm">Confirmar contraseña</label>
						<input id="password-confirm" type="password" name="password_confirmation" placeholder="*********">
					</div>

					<div class="btn-submit">
						<input type="submit" name="" value="Guardar cambios" class="btn">
					</div>

				</form>
			</section>

		</section>

	</main>

@endsection