@extends('layouts.app')

@section('content')
	<main>
		
		<section>
			
			<h1><span>Perfil</span></h1>
			
			<section class="data-user perfil">
				<div class="contiene-avatar">
					<div class="avatar-perfil">
						<div>
							<img src="@if(strpos($user->avatar, 'https') === false) {{ asset('/images/avatars') }}/{{ $user->avatar }} @else {{$user->avatar}} @endif" alt="avatar">
						</div>
					</div>
				</div>
				<div class="datos-perfil">
					<a href="{{ url('configuracion') }}" class="btn btn-datos icon-edit-pencil">Configuración</a>
					<h2 class="nombre">{{ $user->name }}</h2>
					@if (config('polla.groups'))
						<h3>{{ $user->group->name }}</h3>
					@endif
					
					<div class="datos-contenedor">
						<div class="dato">
							<p>Mi puntaje</p>
							<span>{{ $user->points }}</span>
						</div>
						<i class="separador icon-star"></i>
						<div class="dato">
							<p>Mi posición</p>
							<span>{{ $user->position }}°</span>
						</div>
						
						@if (config('polla.groups'))
							<i class="separador icon-star medio"></i>
							<div class="dato">
								<p>Mi grupo</p>
								<span>{{ $user->group->points }}</span>
							</div>
							<i class="separador icon-star"></i>
							<div class="dato">
								<p>Su posición</p>
								<span>{{ $user->group->position }}°</span>
							</div>
						@endif

					</div>
				</div> <!-- fin datos perfil -->

			</section>

			@if (config('polla.logros'))
				<section class="logros">
					<h2 class="icon-trophy">Logros</h2>
					<div class="lista-logros">
						Aún no ha conseguido ningún logro
					</div>
				</section>
			@endif

		</section>

	</main>
@endsection