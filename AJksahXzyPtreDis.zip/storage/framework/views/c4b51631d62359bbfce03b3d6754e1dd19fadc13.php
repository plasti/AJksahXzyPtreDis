<style>
.wrapper-confeti {
  position: fixed;
  top: 0;
  z-index: 1000;
  min-width: 100vW;
  min-height: 100vh;
  display: none;
}

[class|=confetti] {
  position: absolute;
}

.confetti-0 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 78%;
  opacity: 0.9237874518;
  transform: rotate(81.9403027867deg);
  -webkit-animation: drop-0 4.3404679303s 0.8873675532s infinite;
          animation: drop-0 4.3404679303s 0.8873675532s infinite;
}

@-webkit-keyframes drop-0 {
  100% {
    top: 110%;
    left: 79%;
  }
}

@keyframes  drop-0 {
  100% {
    top: 110%;
    left: 79%;
  }
}
.confetti-1 {
  width: 2px;
  height: 0.8px;
  background-color: #263672;
  top: -10%;
  left: 48%;
  opacity: 0.988024523;
  transform: rotate(292.8079365026deg);
  -webkit-animation: drop-1 4.2699500219s 0.8059325644s infinite;
          animation: drop-1 4.2699500219s 0.8059325644s infinite;
}

@-webkit-keyframes drop-1 {
  100% {
    top: 110%;
    left: 53%;
  }
}

@keyframes  drop-1 {
  100% {
    top: 110%;
    left: 53%;
  }
}
.confetti-2 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 66%;
  opacity: 1.4455953581;
  transform: rotate(199.2142389066deg);
  -webkit-animation: drop-2 4.2330119927s 0.3449708141s infinite;
          animation: drop-2 4.2330119927s 0.3449708141s infinite;
}

@-webkit-keyframes drop-2 {
  100% {
    top: 110%;
    left: 71%;
  }
}

@keyframes  drop-2 {
  100% {
    top: 110%;
    left: 71%;
  }
}
.confetti-3 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 34%;
  opacity: 0.631858955;
  transform: rotate(317.1436971595deg);
  -webkit-animation: drop-3 4.7405458083s 0.4771603524s infinite;
          animation: drop-3 4.7405458083s 0.4771603524s infinite;
}

@-webkit-keyframes drop-3 {
  100% {
    top: 110%;
    left: 45%;
  }
}

@keyframes  drop-3 {
  100% {
    top: 110%;
    left: 45%;
  }
}
.confetti-4 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 52%;
  opacity: 0.5276831443;
  transform: rotate(351.7759068007deg);
  -webkit-animation: drop-4 4.1024776581s 0.6850943936s infinite;
          animation: drop-4 4.1024776581s 0.6850943936s infinite;
}

@-webkit-keyframes drop-4 {
  100% {
    top: 110%;
    left: 56%;
  }
}

@keyframes  drop-4 {
  100% {
    top: 110%;
    left: 56%;
  }
}
.confetti-5 {
  width: 1px;
  height: 0.4px;
  background-color: #d13447;
  top: -10%;
  left: 76%;
  opacity: 0.5710823246;
  transform: rotate(207.3491167706deg);
  -webkit-animation: drop-5 4.3085036053s 0.6046032046s infinite;
          animation: drop-5 4.3085036053s 0.6046032046s infinite;
}

@-webkit-keyframes drop-5 {
  100% {
    top: 110%;
    left: 88%;
  }
}

@keyframes  drop-5 {
  100% {
    top: 110%;
    left: 88%;
  }
}
.confetti-6 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 63%;
  opacity: 1.3631904033;
  transform: rotate(315.1366735919deg);
  -webkit-animation: drop-6 4.9371192246s 0.6117219419s infinite;
          animation: drop-6 4.9371192246s 0.6117219419s infinite;
}

@-webkit-keyframes drop-6 {
  100% {
    top: 110%;
    left: 73%;
  }
}

@keyframes  drop-6 {
  100% {
    top: 110%;
    left: 73%;
  }
}
.confetti-7 {
  width: 2px;
  height: 0.8px;
  background-color: #263672;
  top: -10%;
  left: 47%;
  opacity: 0.6545485226;
  transform: rotate(327.4490326912deg);
  -webkit-animation: drop-7 4.0002208721s 0.1253286343s infinite;
          animation: drop-7 4.0002208721s 0.1253286343s infinite;
}

@-webkit-keyframes drop-7 {
  100% {
    top: 110%;
    left: 50%;
  }
}

@keyframes  drop-7 {
  100% {
    top: 110%;
    left: 50%;
  }
}
.confetti-8 {
  width: 1px;
  height: 0.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 1%;
  opacity: 0.7397638959;
  transform: rotate(80.7694017624deg);
  -webkit-animation: drop-8 4.2661094964s 0.5398710925s infinite;
          animation: drop-8 4.2661094964s 0.5398710925s infinite;
}

@-webkit-keyframes drop-8 {
  100% {
    top: 110%;
    left: 16%;
  }
}

@keyframes  drop-8 {
  100% {
    top: 110%;
    left: 16%;
  }
}
.confetti-9 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 45%;
  opacity: 1.0560357975;
  transform: rotate(232.0965421111deg);
  -webkit-animation: drop-9 4.035851137s 0.8779918313s infinite;
          animation: drop-9 4.035851137s 0.8779918313s infinite;
}

@-webkit-keyframes drop-9 {
  100% {
    top: 110%;
    left: 48%;
  }
}

@keyframes  drop-9 {
  100% {
    top: 110%;
    left: 48%;
  }
}
.confetti-10 {
  width: 6px;
  height: 2.4px;
  background-color: #263672;
  top: -10%;
  left: 29%;
  opacity: 0.701095211;
  transform: rotate(152.6348810567deg);
  -webkit-animation: drop-10 4.0280021843s 0.6298745622s infinite;
          animation: drop-10 4.0280021843s 0.6298745622s infinite;
}

@-webkit-keyframes drop-10 {
  100% {
    top: 110%;
    left: 31%;
  }
}

@keyframes  drop-10 {
  100% {
    top: 110%;
    left: 31%;
  }
}
.confetti-11 {
  width: 8px;
  height: 3.2px;
  background-color: #263672;
  top: -10%;
  left: 55%;
  opacity: 1.3766872366;
  transform: rotate(135.423381293deg);
  -webkit-animation: drop-11 4.3511427463s 0.9916346988s infinite;
          animation: drop-11 4.3511427463s 0.9916346988s infinite;
}

@-webkit-keyframes drop-11 {
  100% {
    top: 110%;
    left: 67%;
  }
}

@keyframes  drop-11 {
  100% {
    top: 110%;
    left: 67%;
  }
}
.confetti-12 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 58%;
  opacity: 0.6786330614;
  transform: rotate(105.5189909216deg);
  -webkit-animation: drop-12 4.7604420949s 0.2650494326s infinite;
          animation: drop-12 4.7604420949s 0.2650494326s infinite;
}

@-webkit-keyframes drop-12 {
  100% {
    top: 110%;
    left: 66%;
  }
}

@keyframes  drop-12 {
  100% {
    top: 110%;
    left: 66%;
  }
}
.confetti-13 {
  width: 2px;
  height: 0.8px;
  background-color: #d13447;
  top: -10%;
  left: 39%;
  opacity: 1.003529572;
  transform: rotate(215.404230234deg);
  -webkit-animation: drop-13 4.9150302354s 0.1902528124s infinite;
          animation: drop-13 4.9150302354s 0.1902528124s infinite;
}

@-webkit-keyframes drop-13 {
  100% {
    top: 110%;
    left: 49%;
  }
}

@keyframes  drop-13 {
  100% {
    top: 110%;
    left: 49%;
  }
}
.confetti-14 {
  width: 2px;
  height: 0.8px;
  background-color: #d13447;
  top: -10%;
  left: 63%;
  opacity: 1.3466313184;
  transform: rotate(279.4183891989deg);
  -webkit-animation: drop-14 4.6728969451s 0.1874250495s infinite;
          animation: drop-14 4.6728969451s 0.1874250495s infinite;
}

@-webkit-keyframes drop-14 {
  100% {
    top: 110%;
    left: 78%;
  }
}

@keyframes  drop-14 {
  100% {
    top: 110%;
    left: 78%;
  }
}
.confetti-15 {
  width: 8px;
  height: 3.2px;
  background-color: #263672;
  top: -10%;
  left: 53%;
  opacity: 1.0209736738;
  transform: rotate(229.0410346814deg);
  -webkit-animation: drop-15 4.1438043133s 0.2763643904s infinite;
          animation: drop-15 4.1438043133s 0.2763643904s infinite;
}

@-webkit-keyframes drop-15 {
  100% {
    top: 110%;
    left: 61%;
  }
}

@keyframes  drop-15 {
  100% {
    top: 110%;
    left: 61%;
  }
}
.confetti-16 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 77%;
  opacity: 0.9069094816;
  transform: rotate(53.6301917659deg);
  -webkit-animation: drop-16 4.7520833679s 0.0554306398s infinite;
          animation: drop-16 4.7520833679s 0.0554306398s infinite;
}

@-webkit-keyframes drop-16 {
  100% {
    top: 110%;
    left: 88%;
  }
}

@keyframes  drop-16 {
  100% {
    top: 110%;
    left: 88%;
  }
}
.confetti-17 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 16%;
  opacity: 0.7004698535;
  transform: rotate(357.4513172423deg);
  -webkit-animation: drop-17 4.0230970124s 0.0262129295s infinite;
          animation: drop-17 4.0230970124s 0.0262129295s infinite;
}

@-webkit-keyframes drop-17 {
  100% {
    top: 110%;
    left: 18%;
  }
}

@keyframes  drop-17 {
  100% {
    top: 110%;
    left: 18%;
  }
}
.confetti-18 {
  width: 3px;
  height: 1.2px;
  background-color: #d13447;
  top: -10%;
  left: 49%;
  opacity: 0.819500285;
  transform: rotate(345.8458591167deg);
  -webkit-animation: drop-18 4.7471974024s 0.0908370455s infinite;
          animation: drop-18 4.7471974024s 0.0908370455s infinite;
}

@-webkit-keyframes drop-18 {
  100% {
    top: 110%;
    left: 61%;
  }
}

@keyframes  drop-18 {
  100% {
    top: 110%;
    left: 61%;
  }
}
.confetti-19 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 8%;
  opacity: 1.2534195791;
  transform: rotate(284.6857392879deg);
  -webkit-animation: drop-19 4.5517573988s 0.3524594444s infinite;
          animation: drop-19 4.5517573988s 0.3524594444s infinite;
}

@-webkit-keyframes drop-19 {
  100% {
    top: 110%;
    left: 21%;
  }
}

@keyframes  drop-19 {
  100% {
    top: 110%;
    left: 21%;
  }
}
.confetti-20 {
  width: 5px;
  height: 2px;
  background-color: #263672;
  top: -10%;
  left: 77%;
  opacity: 1.1855960329;
  transform: rotate(11.933018228deg);
  -webkit-animation: drop-20 4.6616705724s 0.1248687203s infinite;
          animation: drop-20 4.6616705724s 0.1248687203s infinite;
}

@-webkit-keyframes drop-20 {
  100% {
    top: 110%;
    left: 79%;
  }
}

@keyframes  drop-20 {
  100% {
    top: 110%;
    left: 79%;
  }
}
.confetti-21 {
  width: 7px;
  height: 2.8px;
  background-color: #263672;
  top: -10%;
  left: 11%;
  opacity: 0.8918668639;
  transform: rotate(134.4611960619deg);
  -webkit-animation: drop-21 4.2794995887s 0.7666668726s infinite;
          animation: drop-21 4.2794995887s 0.7666668726s infinite;
}

@-webkit-keyframes drop-21 {
  100% {
    top: 110%;
    left: 22%;
  }
}

@keyframes  drop-21 {
  100% {
    top: 110%;
    left: 22%;
  }
}
.confetti-22 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 60%;
  opacity: 0.5630906144;
  transform: rotate(294.4691176289deg);
  -webkit-animation: drop-22 4.3207550735s 0.3674106437s infinite;
          animation: drop-22 4.3207550735s 0.3674106437s infinite;
}

@-webkit-keyframes drop-22 {
  100% {
    top: 110%;
    left: 73%;
  }
}

@keyframes  drop-22 {
  100% {
    top: 110%;
    left: 73%;
  }
}
.confetti-23 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 90%;
  opacity: 0.9529845564;
  transform: rotate(274.977766573deg);
  -webkit-animation: drop-23 4.3273186552s 0.0196214417s infinite;
          animation: drop-23 4.3273186552s 0.0196214417s infinite;
}

@-webkit-keyframes drop-23 {
  100% {
    top: 110%;
    left: 93%;
  }
}

@keyframes  drop-23 {
  100% {
    top: 110%;
    left: 93%;
  }
}
.confetti-24 {
  width: 1px;
  height: 0.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 9%;
  opacity: 0.6381524478;
  transform: rotate(274.8664964269deg);
  -webkit-animation: drop-24 4.4616384013s 0.5217375982s infinite;
          animation: drop-24 4.4616384013s 0.5217375982s infinite;
}

@-webkit-keyframes drop-24 {
  100% {
    top: 110%;
    left: 19%;
  }
}

@keyframes  drop-24 {
  100% {
    top: 110%;
    left: 19%;
  }
}
.confetti-25 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 51%;
  opacity: 1.2183175479;
  transform: rotate(199.8471309414deg);
  -webkit-animation: drop-25 4.2066419186s 0.9542911419s infinite;
          animation: drop-25 4.2066419186s 0.9542911419s infinite;
}

@-webkit-keyframes drop-25 {
  100% {
    top: 110%;
    left: 57%;
  }
}

@keyframes  drop-25 {
  100% {
    top: 110%;
    left: 57%;
  }
}
.confetti-26 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 69%;
  opacity: 1.3112326236;
  transform: rotate(265.1871871644deg);
  -webkit-animation: drop-26 4.9396705049s 0.4032006465s infinite;
          animation: drop-26 4.9396705049s 0.4032006465s infinite;
}

@-webkit-keyframes drop-26 {
  100% {
    top: 110%;
    left: 80%;
  }
}

@keyframes  drop-26 {
  100% {
    top: 110%;
    left: 80%;
  }
}
.confetti-27 {
  width: 1px;
  height: 0.4px;
  background-color: #d13447;
  top: -10%;
  left: 100%;
  opacity: 1.4773544198;
  transform: rotate(251.2536952993deg);
  -webkit-animation: drop-27 4.3813083363s 0.5147166629s infinite;
          animation: drop-27 4.3813083363s 0.5147166629s infinite;
}

@-webkit-keyframes drop-27 {
  100% {
    top: 110%;
    left: 113%;
  }
}

@keyframes  drop-27 {
  100% {
    top: 110%;
    left: 113%;
  }
}
.confetti-28 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 34%;
  opacity: 1.4736931665;
  transform: rotate(87.1605132325deg);
  -webkit-animation: drop-28 4.1916675035s 0.5013336599s infinite;
          animation: drop-28 4.1916675035s 0.5013336599s infinite;
}

@-webkit-keyframes drop-28 {
  100% {
    top: 110%;
    left: 46%;
  }
}

@keyframes  drop-28 {
  100% {
    top: 110%;
    left: 46%;
  }
}
.confetti-29 {
  width: 6px;
  height: 2.4px;
  background-color: #263672;
  top: -10%;
  left: 24%;
  opacity: 0.5997167636;
  transform: rotate(114.7762100918deg);
  -webkit-animation: drop-29 4.9788829919s 0.8246304356s infinite;
          animation: drop-29 4.9788829919s 0.8246304356s infinite;
}

@-webkit-keyframes drop-29 {
  100% {
    top: 110%;
    left: 30%;
  }
}

@keyframes  drop-29 {
  100% {
    top: 110%;
    left: 30%;
  }
}
.confetti-30 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 71%;
  opacity: 1.0985166664;
  transform: rotate(339.7322463289deg);
  -webkit-animation: drop-30 4.7813217196s 0.2037460868s infinite;
          animation: drop-30 4.7813217196s 0.2037460868s infinite;
}

@-webkit-keyframes drop-30 {
  100% {
    top: 110%;
    left: 83%;
  }
}

@keyframes  drop-30 {
  100% {
    top: 110%;
    left: 83%;
  }
}
.confetti-31 {
  width: 1px;
  height: 0.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 54%;
  opacity: 0.6576272341;
  transform: rotate(68.2499240483deg);
  -webkit-animation: drop-31 4.4236774988s 0.7888365486s infinite;
          animation: drop-31 4.4236774988s 0.7888365486s infinite;
}

@-webkit-keyframes drop-31 {
  100% {
    top: 110%;
    left: 69%;
  }
}

@keyframes  drop-31 {
  100% {
    top: 110%;
    left: 69%;
  }
}
.confetti-32 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 23%;
  opacity: 1.1057590793;
  transform: rotate(64.0316926337deg);
  -webkit-animation: drop-32 4.2589464136s 0.6737050729s infinite;
          animation: drop-32 4.2589464136s 0.6737050729s infinite;
}

@-webkit-keyframes drop-32 {
  100% {
    top: 110%;
    left: 26%;
  }
}

@keyframes  drop-32 {
  100% {
    top: 110%;
    left: 26%;
  }
}
.confetti-33 {
  width: 8px;
  height: 3.2px;
  background-color: #263672;
  top: -10%;
  left: 42%;
  opacity: 1.1926032412;
  transform: rotate(226.3753916965deg);
  -webkit-animation: drop-33 4.4864161523s 0.758771076s infinite;
          animation: drop-33 4.4864161523s 0.758771076s infinite;
}

@-webkit-keyframes drop-33 {
  100% {
    top: 110%;
    left: 46%;
  }
}

@keyframes  drop-33 {
  100% {
    top: 110%;
    left: 46%;
  }
}
.confetti-34 {
  width: 5px;
  height: 2px;
  background-color: #263672;
  top: -10%;
  left: 25%;
  opacity: 0.7770846351;
  transform: rotate(46.4039670511deg);
  -webkit-animation: drop-34 4.5928023988s 0.1761399033s infinite;
          animation: drop-34 4.5928023988s 0.1761399033s infinite;
}

@-webkit-keyframes drop-34 {
  100% {
    top: 110%;
    left: 28%;
  }
}

@keyframes  drop-34 {
  100% {
    top: 110%;
    left: 28%;
  }
}
.confetti-35 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 99%;
  opacity: 0.6160153974;
  transform: rotate(168.3180383531deg);
  -webkit-animation: drop-35 4.344899201s 0.0042500714s infinite;
          animation: drop-35 4.344899201s 0.0042500714s infinite;
}

@-webkit-keyframes drop-35 {
  100% {
    top: 110%;
    left: 108%;
  }
}

@keyframes  drop-35 {
  100% {
    top: 110%;
    left: 108%;
  }
}
.confetti-36 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 35%;
  opacity: 1.4064428948;
  transform: rotate(120.0010609834deg);
  -webkit-animation: drop-36 4.5352332836s 0.78004135s infinite;
          animation: drop-36 4.5352332836s 0.78004135s infinite;
}

@-webkit-keyframes drop-36 {
  100% {
    top: 110%;
    left: 45%;
  }
}

@keyframes  drop-36 {
  100% {
    top: 110%;
    left: 45%;
  }
}
.confetti-37 {
  width: 8px;
  height: 3.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 72%;
  opacity: 0.7594551598;
  transform: rotate(258.5135170395deg);
  -webkit-animation: drop-37 4.3915198527s 0.3119705451s infinite;
          animation: drop-37 4.3915198527s 0.3119705451s infinite;
}

@-webkit-keyframes drop-37 {
  100% {
    top: 110%;
    left: 85%;
  }
}

@keyframes  drop-37 {
  100% {
    top: 110%;
    left: 85%;
  }
}
.confetti-38 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 8%;
  opacity: 0.9816079616;
  transform: rotate(220.0802689365deg);
  -webkit-animation: drop-38 4.6334275333s 0.9551211345s infinite;
          animation: drop-38 4.6334275333s 0.9551211345s infinite;
}

@-webkit-keyframes drop-38 {
  100% {
    top: 110%;
    left: 16%;
  }
}

@keyframes  drop-38 {
  100% {
    top: 110%;
    left: 16%;
  }
}
.confetti-39 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 79%;
  opacity: 0.7863447867;
  transform: rotate(220.8778935654deg);
  -webkit-animation: drop-39 4.1367070631s 0.4350403327s infinite;
          animation: drop-39 4.1367070631s 0.4350403327s infinite;
}

@-webkit-keyframes drop-39 {
  100% {
    top: 110%;
    left: 83%;
  }
}

@keyframes  drop-39 {
  100% {
    top: 110%;
    left: 83%;
  }
}
.confetti-40 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 14%;
  opacity: 1.1819203917;
  transform: rotate(216.6230259236deg);
  -webkit-animation: drop-40 4.8255014307s 0.9266969731s infinite;
          animation: drop-40 4.8255014307s 0.9266969731s infinite;
}

@-webkit-keyframes drop-40 {
  100% {
    top: 110%;
    left: 26%;
  }
}

@keyframes  drop-40 {
  100% {
    top: 110%;
    left: 26%;
  }
}
.confetti-41 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 59%;
  opacity: 0.527921134;
  transform: rotate(335.7484111123deg);
  -webkit-animation: drop-41 4.0341530896s 0.0825275124s infinite;
          animation: drop-41 4.0341530896s 0.0825275124s infinite;
}

@-webkit-keyframes drop-41 {
  100% {
    top: 110%;
    left: 68%;
  }
}

@keyframes  drop-41 {
  100% {
    top: 110%;
    left: 68%;
  }
}
.confetti-42 {
  width: 3px;
  height: 1.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 28%;
  opacity: 1.4147961516;
  transform: rotate(237.8479479229deg);
  -webkit-animation: drop-42 4.0821623011s 0.9458290702s infinite;
          animation: drop-42 4.0821623011s 0.9458290702s infinite;
}

@-webkit-keyframes drop-42 {
  100% {
    top: 110%;
    left: 32%;
  }
}

@keyframes  drop-42 {
  100% {
    top: 110%;
    left: 32%;
  }
}
.confetti-43 {
  width: 7px;
  height: 2.8px;
  background-color: #d13447;
  top: -10%;
  left: 51%;
  opacity: 1.0466377091;
  transform: rotate(134.1989381065deg);
  -webkit-animation: drop-43 4.3939207421s 0.4064885768s infinite;
          animation: drop-43 4.3939207421s 0.4064885768s infinite;
}

@-webkit-keyframes drop-43 {
  100% {
    top: 110%;
    left: 54%;
  }
}

@keyframes  drop-43 {
  100% {
    top: 110%;
    left: 54%;
  }
}
.confetti-44 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 20%;
  opacity: 0.6194575136;
  transform: rotate(313.4487354057deg);
  -webkit-animation: drop-44 4.4538378363s 0.7484878401s infinite;
          animation: drop-44 4.4538378363s 0.7484878401s infinite;
}

@-webkit-keyframes drop-44 {
  100% {
    top: 110%;
    left: 28%;
  }
}

@keyframes  drop-44 {
  100% {
    top: 110%;
    left: 28%;
  }
}
.confetti-45 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 36%;
  opacity: 0.6451657573;
  transform: rotate(11.0886450662deg);
  -webkit-animation: drop-45 4.3474401805s 0.8773252664s infinite;
          animation: drop-45 4.3474401805s 0.8773252664s infinite;
}

@-webkit-keyframes drop-45 {
  100% {
    top: 110%;
    left: 49%;
  }
}

@keyframes  drop-45 {
  100% {
    top: 110%;
    left: 49%;
  }
}
.confetti-46 {
  width: 3px;
  height: 1.2px;
  background-color: #d13447;
  top: -10%;
  left: 87%;
  opacity: 0.583936407;
  transform: rotate(163.3392111345deg);
  -webkit-animation: drop-46 4.3199944723s 0.0249602961s infinite;
          animation: drop-46 4.3199944723s 0.0249602961s infinite;
}

@-webkit-keyframes drop-46 {
  100% {
    top: 110%;
    left: 95%;
  }
}

@keyframes  drop-46 {
  100% {
    top: 110%;
    left: 95%;
  }
}
.confetti-47 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 46%;
  opacity: 1.2306269807;
  transform: rotate(7.6707248632deg);
  -webkit-animation: drop-47 4.4916058498s 0.8598453809s infinite;
          animation: drop-47 4.4916058498s 0.8598453809s infinite;
}

@-webkit-keyframes drop-47 {
  100% {
    top: 110%;
    left: 51%;
  }
}

@keyframes  drop-47 {
  100% {
    top: 110%;
    left: 51%;
  }
}
.confetti-48 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 31%;
  opacity: 0.9335043757;
  transform: rotate(43.7611170296deg);
  -webkit-animation: drop-48 4.6006679424s 0.3241803442s infinite;
          animation: drop-48 4.6006679424s 0.3241803442s infinite;
}

@-webkit-keyframes drop-48 {
  100% {
    top: 110%;
    left: 44%;
  }
}

@keyframes  drop-48 {
  100% {
    top: 110%;
    left: 44%;
  }
}
.confetti-49 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 34%;
  opacity: 1.4070697822;
  transform: rotate(298.9712890269deg);
  -webkit-animation: drop-49 4.7921147302s 0.9913989173s infinite;
          animation: drop-49 4.7921147302s 0.9913989173s infinite;
}

@-webkit-keyframes drop-49 {
  100% {
    top: 110%;
    left: 46%;
  }
}

@keyframes  drop-49 {
  100% {
    top: 110%;
    left: 46%;
  }
}
.confetti-50 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 43%;
  opacity: 1.2843650982;
  transform: rotate(267.6838961685deg);
  -webkit-animation: drop-50 4.9727758838s 0.6562021825s infinite;
          animation: drop-50 4.9727758838s 0.6562021825s infinite;
}

@-webkit-keyframes drop-50 {
  100% {
    top: 110%;
    left: 55%;
  }
}

@keyframes  drop-50 {
  100% {
    top: 110%;
    left: 55%;
  }
}
.confetti-51 {
  width: 7px;
  height: 2.8px;
  background-color: #d13447;
  top: -10%;
  left: 34%;
  opacity: 0.5310752846;
  transform: rotate(234.3501218983deg);
  -webkit-animation: drop-51 4.7687719341s 0.8019579272s infinite;
          animation: drop-51 4.7687719341s 0.8019579272s infinite;
}

@-webkit-keyframes drop-51 {
  100% {
    top: 110%;
    left: 43%;
  }
}

@keyframes  drop-51 {
  100% {
    top: 110%;
    left: 43%;
  }
}
.confetti-52 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 14%;
  opacity: 1.3002357467;
  transform: rotate(3.0698644656deg);
  -webkit-animation: drop-52 4.276882831s 0.1316715951s infinite;
          animation: drop-52 4.276882831s 0.1316715951s infinite;
}

@-webkit-keyframes drop-52 {
  100% {
    top: 110%;
    left: 29%;
  }
}

@keyframes  drop-52 {
  100% {
    top: 110%;
    left: 29%;
  }
}
.confetti-53 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 37%;
  opacity: 1.291414469;
  transform: rotate(214.7324791424deg);
  -webkit-animation: drop-53 4.680669306s 0.6657888426s infinite;
          animation: drop-53 4.680669306s 0.6657888426s infinite;
}

@-webkit-keyframes drop-53 {
  100% {
    top: 110%;
    left: 40%;
  }
}

@keyframes  drop-53 {
  100% {
    top: 110%;
    left: 40%;
  }
}
.confetti-54 {
  width: 2px;
  height: 0.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 60%;
  opacity: 0.9479762384;
  transform: rotate(189.7548469144deg);
  -webkit-animation: drop-54 4.3994527543s 0.0162513128s infinite;
          animation: drop-54 4.3994527543s 0.0162513128s infinite;
}

@-webkit-keyframes drop-54 {
  100% {
    top: 110%;
    left: 72%;
  }
}

@keyframes  drop-54 {
  100% {
    top: 110%;
    left: 72%;
  }
}
.confetti-55 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 54%;
  opacity: 1.2611328945;
  transform: rotate(93.5831767603deg);
  -webkit-animation: drop-55 4.9495600999s 0.9018938949s infinite;
          animation: drop-55 4.9495600999s 0.9018938949s infinite;
}

@-webkit-keyframes drop-55 {
  100% {
    top: 110%;
    left: 56%;
  }
}

@keyframes  drop-55 {
  100% {
    top: 110%;
    left: 56%;
  }
}
.confetti-56 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 54%;
  opacity: 1.3444966198;
  transform: rotate(238.1274880651deg);
  -webkit-animation: drop-56 4.6358114274s 0.1388451048s infinite;
          animation: drop-56 4.6358114274s 0.1388451048s infinite;
}

@-webkit-keyframes drop-56 {
  100% {
    top: 110%;
    left: 55%;
  }
}

@keyframes  drop-56 {
  100% {
    top: 110%;
    left: 55%;
  }
}
.confetti-57 {
  width: 6px;
  height: 2.4px;
  background-color: #263672;
  top: -10%;
  left: 99%;
  opacity: 1.3285846668;
  transform: rotate(30.4035514027deg);
  -webkit-animation: drop-57 4.5400995369s 0.6170301447s infinite;
          animation: drop-57 4.5400995369s 0.6170301447s infinite;
}

@-webkit-keyframes drop-57 {
  100% {
    top: 110%;
    left: 101%;
  }
}

@keyframes  drop-57 {
  100% {
    top: 110%;
    left: 101%;
  }
}
.confetti-58 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 69%;
  opacity: 1.0200550622;
  transform: rotate(197.8701032323deg);
  -webkit-animation: drop-58 4.4888709135s 0.7822695048s infinite;
          animation: drop-58 4.4888709135s 0.7822695048s infinite;
}

@-webkit-keyframes drop-58 {
  100% {
    top: 110%;
    left: 82%;
  }
}

@keyframes  drop-58 {
  100% {
    top: 110%;
    left: 82%;
  }
}
.confetti-59 {
  width: 3px;
  height: 1.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 56%;
  opacity: 1.275654428;
  transform: rotate(14.6893402412deg);
  -webkit-animation: drop-59 4.5219059333s 0.4036978375s infinite;
          animation: drop-59 4.5219059333s 0.4036978375s infinite;
}

@-webkit-keyframes drop-59 {
  100% {
    top: 110%;
    left: 65%;
  }
}

@keyframes  drop-59 {
  100% {
    top: 110%;
    left: 65%;
  }
}
.confetti-60 {
  width: 6px;
  height: 2.4px;
  background-color: #d13447;
  top: -10%;
  left: 83%;
  opacity: 0.6785756352;
  transform: rotate(92.5952942816deg);
  -webkit-animation: drop-60 4.9176097743s 0.0957531574s infinite;
          animation: drop-60 4.9176097743s 0.0957531574s infinite;
}

@-webkit-keyframes drop-60 {
  100% {
    top: 110%;
    left: 91%;
  }
}

@keyframes  drop-60 {
  100% {
    top: 110%;
    left: 91%;
  }
}
.confetti-61 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 54%;
  opacity: 1.3533732727;
  transform: rotate(250.1300930116deg);
  -webkit-animation: drop-61 4.6096276006s 0.5461977302s infinite;
          animation: drop-61 4.6096276006s 0.5461977302s infinite;
}

@-webkit-keyframes drop-61 {
  100% {
    top: 110%;
    left: 63%;
  }
}

@keyframes  drop-61 {
  100% {
    top: 110%;
    left: 63%;
  }
}
.confetti-62 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 1%;
  opacity: 1.4377845762;
  transform: rotate(155.692274692deg);
  -webkit-animation: drop-62 4.0801311183s 0.5913243207s infinite;
          animation: drop-62 4.0801311183s 0.5913243207s infinite;
}

@-webkit-keyframes drop-62 {
  100% {
    top: 110%;
    left: 13%;
  }
}

@keyframes  drop-62 {
  100% {
    top: 110%;
    left: 13%;
  }
}
.confetti-63 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 74%;
  opacity: 1.1090259585;
  transform: rotate(261.8903114536deg);
  -webkit-animation: drop-63 4.4111972193s 0.0464833791s infinite;
          animation: drop-63 4.4111972193s 0.0464833791s infinite;
}

@-webkit-keyframes drop-63 {
  100% {
    top: 110%;
    left: 76%;
  }
}

@keyframes  drop-63 {
  100% {
    top: 110%;
    left: 76%;
  }
}
.confetti-64 {
  width: 6px;
  height: 2.4px;
  background-color: #263672;
  top: -10%;
  left: 37%;
  opacity: 0.9767393862;
  transform: rotate(199.2252652543deg);
  -webkit-animation: drop-64 4.7782922017s 0.1833732596s infinite;
          animation: drop-64 4.7782922017s 0.1833732596s infinite;
}

@-webkit-keyframes drop-64 {
  100% {
    top: 110%;
    left: 42%;
  }
}

@keyframes  drop-64 {
  100% {
    top: 110%;
    left: 42%;
  }
}
.confetti-65 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 95%;
  opacity: 0.585401381;
  transform: rotate(116.5189962144deg);
  -webkit-animation: drop-65 4.2892781557s 0.9940087677s infinite;
          animation: drop-65 4.2892781557s 0.9940087677s infinite;
}

@-webkit-keyframes drop-65 {
  100% {
    top: 110%;
    left: 108%;
  }
}

@keyframes  drop-65 {
  100% {
    top: 110%;
    left: 108%;
  }
}
.confetti-66 {
  width: 5px;
  height: 2px;
  background-color: #ffbf00;
  top: -10%;
  left: 10%;
  opacity: 0.5950570841;
  transform: rotate(248.9072874533deg);
  -webkit-animation: drop-66 4.4108961524s 0.4173653959s infinite;
          animation: drop-66 4.4108961524s 0.4173653959s infinite;
}

@-webkit-keyframes drop-66 {
  100% {
    top: 110%;
    left: 22%;
  }
}

@keyframes  drop-66 {
  100% {
    top: 110%;
    left: 22%;
  }
}
.confetti-67 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 29%;
  opacity: 0.526874041;
  transform: rotate(239.6048461155deg);
  -webkit-animation: drop-67 4.4555752092s 0.2753247734s infinite;
          animation: drop-67 4.4555752092s 0.2753247734s infinite;
}

@-webkit-keyframes drop-67 {
  100% {
    top: 110%;
    left: 33%;
  }
}

@keyframes  drop-67 {
  100% {
    top: 110%;
    left: 33%;
  }
}
.confetti-68 {
  width: 6px;
  height: 2.4px;
  background-color: #d13447;
  top: -10%;
  left: 69%;
  opacity: 0.6252609187;
  transform: rotate(102.2871992109deg);
  -webkit-animation: drop-68 4.947035504s 0.2154520219s infinite;
          animation: drop-68 4.947035504s 0.2154520219s infinite;
}

@-webkit-keyframes drop-68 {
  100% {
    top: 110%;
    left: 83%;
  }
}

@keyframes  drop-68 {
  100% {
    top: 110%;
    left: 83%;
  }
}
.confetti-69 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 66%;
  opacity: 0.9903772046;
  transform: rotate(104.4935091119deg);
  -webkit-animation: drop-69 4.7431668684s 0.4698649106s infinite;
          animation: drop-69 4.7431668684s 0.4698649106s infinite;
}

@-webkit-keyframes drop-69 {
  100% {
    top: 110%;
    left: 70%;
  }
}

@keyframes  drop-69 {
  100% {
    top: 110%;
    left: 70%;
  }
}
.confetti-70 {
  width: 2px;
  height: 0.8px;
  background-color: #263672;
  top: -10%;
  left: 85%;
  opacity: 1.4643402085;
  transform: rotate(354.2488284038deg);
  -webkit-animation: drop-70 4.0988357162s 0.3416115892s infinite;
          animation: drop-70 4.0988357162s 0.3416115892s infinite;
}

@-webkit-keyframes drop-70 {
  100% {
    top: 110%;
    left: 91%;
  }
}

@keyframes  drop-70 {
  100% {
    top: 110%;
    left: 91%;
  }
}
.confetti-71 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 67%;
  opacity: 0.8411498981;
  transform: rotate(126.0212923963deg);
  -webkit-animation: drop-71 4.3307512227s 0.5108155682s infinite;
          animation: drop-71 4.3307512227s 0.5108155682s infinite;
}

@-webkit-keyframes drop-71 {
  100% {
    top: 110%;
    left: 70%;
  }
}

@keyframes  drop-71 {
  100% {
    top: 110%;
    left: 70%;
  }
}
.confetti-72 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 40%;
  opacity: 1.3983139746;
  transform: rotate(216.5809227789deg);
  -webkit-animation: drop-72 4.5113592134s 0.2838638203s infinite;
          animation: drop-72 4.5113592134s 0.2838638203s infinite;
}

@-webkit-keyframes drop-72 {
  100% {
    top: 110%;
    left: 45%;
  }
}

@keyframes  drop-72 {
  100% {
    top: 110%;
    left: 45%;
  }
}
.confetti-73 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 82%;
  opacity: 0.6124896869;
  transform: rotate(301.8377734535deg);
  -webkit-animation: drop-73 4.6394160287s 0.6057977593s infinite;
          animation: drop-73 4.6394160287s 0.6057977593s infinite;
}

@-webkit-keyframes drop-73 {
  100% {
    top: 110%;
    left: 96%;
  }
}

@keyframes  drop-73 {
  100% {
    top: 110%;
    left: 96%;
  }
}
.confetti-74 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 58%;
  opacity: 0.982197919;
  transform: rotate(88.1809031806deg);
  -webkit-animation: drop-74 4.4037302894s 0.0323857449s infinite;
          animation: drop-74 4.4037302894s 0.0323857449s infinite;
}

@-webkit-keyframes drop-74 {
  100% {
    top: 110%;
    left: 69%;
  }
}

@keyframes  drop-74 {
  100% {
    top: 110%;
    left: 69%;
  }
}
.confetti-75 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 67%;
  opacity: 1.2604151891;
  transform: rotate(0.4613702915deg);
  -webkit-animation: drop-75 4.5535754335s 0.8089710786s infinite;
          animation: drop-75 4.5535754335s 0.8089710786s infinite;
}

@-webkit-keyframes drop-75 {
  100% {
    top: 110%;
    left: 80%;
  }
}

@keyframes  drop-75 {
  100% {
    top: 110%;
    left: 80%;
  }
}
.confetti-76 {
  width: 8px;
  height: 3.2px;
  background-color: #263672;
  top: -10%;
  left: 4%;
  opacity: 0.7918801971;
  transform: rotate(139.8641900656deg);
  -webkit-animation: drop-76 4.6936524624s 0.4229888612s infinite;
          animation: drop-76 4.6936524624s 0.4229888612s infinite;
}

@-webkit-keyframes drop-76 {
  100% {
    top: 110%;
    left: 19%;
  }
}

@keyframes  drop-76 {
  100% {
    top: 110%;
    left: 19%;
  }
}
.confetti-77 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 5%;
  opacity: 0.9491443283;
  transform: rotate(245.4324377184deg);
  -webkit-animation: drop-77 4.7851328945s 0.1899259495s infinite;
          animation: drop-77 4.7851328945s 0.1899259495s infinite;
}

@-webkit-keyframes drop-77 {
  100% {
    top: 110%;
    left: 7%;
  }
}

@keyframes  drop-77 {
  100% {
    top: 110%;
    left: 7%;
  }
}
.confetti-78 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 71%;
  opacity: 0.8966184293;
  transform: rotate(96.3026391728deg);
  -webkit-animation: drop-78 4.8471817938s 0.7064407059s infinite;
          animation: drop-78 4.8471817938s 0.7064407059s infinite;
}

@-webkit-keyframes drop-78 {
  100% {
    top: 110%;
    left: 85%;
  }
}

@keyframes  drop-78 {
  100% {
    top: 110%;
    left: 85%;
  }
}
.confetti-79 {
  width: 8px;
  height: 3.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 30%;
  opacity: 0.8274262415;
  transform: rotate(272.9121841587deg);
  -webkit-animation: drop-79 4.8553008191s 0.5487749717s infinite;
          animation: drop-79 4.8553008191s 0.5487749717s infinite;
}

@-webkit-keyframes drop-79 {
  100% {
    top: 110%;
    left: 43%;
  }
}

@keyframes  drop-79 {
  100% {
    top: 110%;
    left: 43%;
  }
}
.confetti-80 {
  width: 1px;
  height: 0.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 46%;
  opacity: 1.0762614353;
  transform: rotate(214.3719432985deg);
  -webkit-animation: drop-80 4.5668919808s 0.5378879909s infinite;
          animation: drop-80 4.5668919808s 0.5378879909s infinite;
}

@-webkit-keyframes drop-80 {
  100% {
    top: 110%;
    left: 49%;
  }
}

@keyframes  drop-80 {
  100% {
    top: 110%;
    left: 49%;
  }
}
.confetti-81 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 53%;
  opacity: 0.5720330067;
  transform: rotate(137.394998476deg);
  -webkit-animation: drop-81 4.7031810022s 0.6169804671s infinite;
          animation: drop-81 4.7031810022s 0.6169804671s infinite;
}

@-webkit-keyframes drop-81 {
  100% {
    top: 110%;
    left: 59%;
  }
}

@keyframes  drop-81 {
  100% {
    top: 110%;
    left: 59%;
  }
}
.confetti-82 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 18%;
  opacity: 0.6872979057;
  transform: rotate(317.0662417171deg);
  -webkit-animation: drop-82 4.2382926883s 0.1091403698s infinite;
          animation: drop-82 4.2382926883s 0.1091403698s infinite;
}

@-webkit-keyframes drop-82 {
  100% {
    top: 110%;
    left: 24%;
  }
}

@keyframes  drop-82 {
  100% {
    top: 110%;
    left: 24%;
  }
}
.confetti-83 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 71%;
  opacity: 0.8100276199;
  transform: rotate(54.957153723deg);
  -webkit-animation: drop-83 4.21729438s 0.0603883414s infinite;
          animation: drop-83 4.21729438s 0.0603883414s infinite;
}

@-webkit-keyframes drop-83 {
  100% {
    top: 110%;
    left: 81%;
  }
}

@keyframes  drop-83 {
  100% {
    top: 110%;
    left: 81%;
  }
}
.confetti-84 {
  width: 5px;
  height: 2px;
  background-color: #263672;
  top: -10%;
  left: 58%;
  opacity: 1.1002292255;
  transform: rotate(102.8857716927deg);
  -webkit-animation: drop-84 4.04798363s 0.726113437s infinite;
          animation: drop-84 4.04798363s 0.726113437s infinite;
}

@-webkit-keyframes drop-84 {
  100% {
    top: 110%;
    left: 69%;
  }
}

@keyframes  drop-84 {
  100% {
    top: 110%;
    left: 69%;
  }
}
.confetti-85 {
  width: 2px;
  height: 0.8px;
  background-color: #263672;
  top: -10%;
  left: 51%;
  opacity: 0.6956705312;
  transform: rotate(267.0995323953deg);
  -webkit-animation: drop-85 4.6435518466s 0.852224441s infinite;
          animation: drop-85 4.6435518466s 0.852224441s infinite;
}

@-webkit-keyframes drop-85 {
  100% {
    top: 110%;
    left: 62%;
  }
}

@keyframes  drop-85 {
  100% {
    top: 110%;
    left: 62%;
  }
}
.confetti-86 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 82%;
  opacity: 1.4309088376;
  transform: rotate(346.6321866768deg);
  -webkit-animation: drop-86 4.0684683368s 0.5881964496s infinite;
          animation: drop-86 4.0684683368s 0.5881964496s infinite;
}

@-webkit-keyframes drop-86 {
  100% {
    top: 110%;
    left: 97%;
  }
}

@keyframes  drop-86 {
  100% {
    top: 110%;
    left: 97%;
  }
}
.confetti-87 {
  width: 1px;
  height: 0.4px;
  background-color: #d13447;
  top: -10%;
  left: 3%;
  opacity: 0.9050160542;
  transform: rotate(83.4775714525deg);
  -webkit-animation: drop-87 4.1378408073s 0.9853304495s infinite;
          animation: drop-87 4.1378408073s 0.9853304495s infinite;
}

@-webkit-keyframes drop-87 {
  100% {
    top: 110%;
    left: 5%;
  }
}

@keyframes  drop-87 {
  100% {
    top: 110%;
    left: 5%;
  }
}
.confetti-88 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 68%;
  opacity: 0.6056619071;
  transform: rotate(129.8082255226deg);
  -webkit-animation: drop-88 4.5957436411s 0.7617163687s infinite;
          animation: drop-88 4.5957436411s 0.7617163687s infinite;
}

@-webkit-keyframes drop-88 {
  100% {
    top: 110%;
    left: 77%;
  }
}

@keyframes  drop-88 {
  100% {
    top: 110%;
    left: 77%;
  }
}
.confetti-89 {
  width: 8px;
  height: 3.2px;
  background-color: #263672;
  top: -10%;
  left: 24%;
  opacity: 0.9993838167;
  transform: rotate(49.9004585839deg);
  -webkit-animation: drop-89 4.7392161943s 0.5705510435s infinite;
          animation: drop-89 4.7392161943s 0.5705510435s infinite;
}

@-webkit-keyframes drop-89 {
  100% {
    top: 110%;
    left: 29%;
  }
}

@keyframes  drop-89 {
  100% {
    top: 110%;
    left: 29%;
  }
}
.confetti-90 {
  width: 8px;
  height: 3.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 56%;
  opacity: 0.8459747721;
  transform: rotate(55.2269359761deg);
  -webkit-animation: drop-90 4.2444322413s 0.2171203113s infinite;
          animation: drop-90 4.2444322413s 0.2171203113s infinite;
}

@-webkit-keyframes drop-90 {
  100% {
    top: 110%;
    left: 57%;
  }
}

@keyframes  drop-90 {
  100% {
    top: 110%;
    left: 57%;
  }
}
.confetti-91 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 98%;
  opacity: 1.2849909326;
  transform: rotate(206.0789631725deg);
  -webkit-animation: drop-91 4.3734316853s 0.0670993162s infinite;
          animation: drop-91 4.3734316853s 0.0670993162s infinite;
}

@-webkit-keyframes drop-91 {
  100% {
    top: 110%;
    left: 100%;
  }
}

@keyframes  drop-91 {
  100% {
    top: 110%;
    left: 100%;
  }
}
.confetti-92 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 9%;
  opacity: 1.4983818884;
  transform: rotate(252.3261061912deg);
  -webkit-animation: drop-92 4.008163487s 0.9375968284s infinite;
          animation: drop-92 4.008163487s 0.9375968284s infinite;
}

@-webkit-keyframes drop-92 {
  100% {
    top: 110%;
    left: 18%;
  }
}

@keyframes  drop-92 {
  100% {
    top: 110%;
    left: 18%;
  }
}
.confetti-93 {
  width: 8px;
  height: 3.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 67%;
  opacity: 0.5653069702;
  transform: rotate(158.0019274043deg);
  -webkit-animation: drop-93 4.5237246635s 0.3119026095s infinite;
          animation: drop-93 4.5237246635s 0.3119026095s infinite;
}

@-webkit-keyframes drop-93 {
  100% {
    top: 110%;
    left: 81%;
  }
}

@keyframes  drop-93 {
  100% {
    top: 110%;
    left: 81%;
  }
}
.confetti-94 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 26%;
  opacity: 1.1447783063;
  transform: rotate(18.9923839681deg);
  -webkit-animation: drop-94 4.6994735131s 0.6510378235s infinite;
          animation: drop-94 4.6994735131s 0.6510378235s infinite;
}

@-webkit-keyframes drop-94 {
  100% {
    top: 110%;
    left: 30%;
  }
}

@keyframes  drop-94 {
  100% {
    top: 110%;
    left: 30%;
  }
}
.confetti-95 {
  width: 1px;
  height: 0.4px;
  background-color: #d13447;
  top: -10%;
  left: 87%;
  opacity: 0.8843950453;
  transform: rotate(203.6582821265deg);
  -webkit-animation: drop-95 4.8022362291s 0.4397964688s infinite;
          animation: drop-95 4.8022362291s 0.4397964688s infinite;
}

@-webkit-keyframes drop-95 {
  100% {
    top: 110%;
    left: 99%;
  }
}

@keyframes  drop-95 {
  100% {
    top: 110%;
    left: 99%;
  }
}
.confetti-96 {
  width: 3px;
  height: 1.2px;
  background-color: #d13447;
  top: -10%;
  left: 29%;
  opacity: 1.3859399701;
  transform: rotate(134.7806893961deg);
  -webkit-animation: drop-96 4.5839069078s 0.8741822342s infinite;
          animation: drop-96 4.5839069078s 0.8741822342s infinite;
}

@-webkit-keyframes drop-96 {
  100% {
    top: 110%;
    left: 30%;
  }
}

@keyframes  drop-96 {
  100% {
    top: 110%;
    left: 30%;
  }
}
.confetti-97 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 59%;
  opacity: 0.5796876062;
  transform: rotate(320.7906429393deg);
  -webkit-animation: drop-97 4.8916581963s 0.2464144525s infinite;
          animation: drop-97 4.8916581963s 0.2464144525s infinite;
}

@-webkit-keyframes drop-97 {
  100% {
    top: 110%;
    left: 60%;
  }
}

@keyframes  drop-97 {
  100% {
    top: 110%;
    left: 60%;
  }
}
.confetti-98 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 22%;
  opacity: 0.7370332303;
  transform: rotate(102.6307425508deg);
  -webkit-animation: drop-98 4.9069743885s 0.6174738699s infinite;
          animation: drop-98 4.9069743885s 0.6174738699s infinite;
}

@-webkit-keyframes drop-98 {
  100% {
    top: 110%;
    left: 28%;
  }
}

@keyframes  drop-98 {
  100% {
    top: 110%;
    left: 28%;
  }
}
.confetti-99 {
  width: 5px;
  height: 2px;
  background-color: #d13447;
  top: -10%;
  left: 64%;
  opacity: 1.4403128108;
  transform: rotate(336.9745961636deg);
  -webkit-animation: drop-99 4.3488786548s 0.5392678068s infinite;
          animation: drop-99 4.3488786548s 0.5392678068s infinite;
}

@-webkit-keyframes drop-99 {
  100% {
    top: 110%;
    left: 76%;
  }
}

@keyframes  drop-99 {
  100% {
    top: 110%;
    left: 76%;
  }
}
.confetti-100 {
  width: 7px;
  height: 2.8px;
  background-color: #d13447;
  top: -10%;
  left: 40%;
  opacity: 0.8515222626;
  transform: rotate(121.6447462203deg);
  -webkit-animation: drop-100 4.8709373258s 0.4232779612s infinite;
          animation: drop-100 4.8709373258s 0.4232779612s infinite;
}

@-webkit-keyframes drop-100 {
  100% {
    top: 110%;
    left: 49%;
  }
}

@keyframes  drop-100 {
  100% {
    top: 110%;
    left: 49%;
  }
}
.confetti-101 {
  width: 3px;
  height: 1.2px;
  background-color: #d13447;
  top: -10%;
  left: 7%;
  opacity: 1.1479864766;
  transform: rotate(288.9757274412deg);
  -webkit-animation: drop-101 4.3634404194s 0.4289411296s infinite;
          animation: drop-101 4.3634404194s 0.4289411296s infinite;
}

@-webkit-keyframes drop-101 {
  100% {
    top: 110%;
    left: 22%;
  }
}

@keyframes  drop-101 {
  100% {
    top: 110%;
    left: 22%;
  }
}
.confetti-102 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 97%;
  opacity: 1.4444100055;
  transform: rotate(157.3325978231deg);
  -webkit-animation: drop-102 4.6248188027s 0.1545378974s infinite;
          animation: drop-102 4.6248188027s 0.1545378974s infinite;
}

@-webkit-keyframes drop-102 {
  100% {
    top: 110%;
    left: 110%;
  }
}

@keyframes  drop-102 {
  100% {
    top: 110%;
    left: 110%;
  }
}
.confetti-103 {
  width: 3px;
  height: 1.2px;
  background-color: #263672;
  top: -10%;
  left: 71%;
  opacity: 0.7594411029;
  transform: rotate(2.6336275011deg);
  -webkit-animation: drop-103 4.1401019545s 0.0287828619s infinite;
          animation: drop-103 4.1401019545s 0.0287828619s infinite;
}

@-webkit-keyframes drop-103 {
  100% {
    top: 110%;
    left: 86%;
  }
}

@keyframes  drop-103 {
  100% {
    top: 110%;
    left: 86%;
  }
}
.confetti-104 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 74%;
  opacity: 0.6634322377;
  transform: rotate(278.9491239506deg);
  -webkit-animation: drop-104 4.5760156498s 0.109147943s infinite;
          animation: drop-104 4.5760156498s 0.109147943s infinite;
}

@-webkit-keyframes drop-104 {
  100% {
    top: 110%;
    left: 82%;
  }
}

@keyframes  drop-104 {
  100% {
    top: 110%;
    left: 82%;
  }
}
.confetti-105 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 91%;
  opacity: 1.005427442;
  transform: rotate(239.7652157557deg);
  -webkit-animation: drop-105 4.1784973176s 0.6842667055s infinite;
          animation: drop-105 4.1784973176s 0.6842667055s infinite;
}

@-webkit-keyframes drop-105 {
  100% {
    top: 110%;
    left: 93%;
  }
}

@keyframes  drop-105 {
  100% {
    top: 110%;
    left: 93%;
  }
}
.confetti-106 {
  width: 3px;
  height: 1.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 29%;
  opacity: 0.5798409456;
  transform: rotate(221.5640712301deg);
  -webkit-animation: drop-106 4.5309081143s 0.3459171368s infinite;
          animation: drop-106 4.5309081143s 0.3459171368s infinite;
}

@-webkit-keyframes drop-106 {
  100% {
    top: 110%;
    left: 36%;
  }
}

@keyframes  drop-106 {
  100% {
    top: 110%;
    left: 36%;
  }
}
.confetti-107 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 23%;
  opacity: 0.7816906511;
  transform: rotate(214.0632413173deg);
  -webkit-animation: drop-107 4.2630738707s 0.7832442615s infinite;
          animation: drop-107 4.2630738707s 0.7832442615s infinite;
}

@-webkit-keyframes drop-107 {
  100% {
    top: 110%;
    left: 34%;
  }
}

@keyframes  drop-107 {
  100% {
    top: 110%;
    left: 34%;
  }
}
.confetti-108 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 33%;
  opacity: 0.516792138;
  transform: rotate(138.9432869307deg);
  -webkit-animation: drop-108 4.7364419522s 0.2431707233s infinite;
          animation: drop-108 4.7364419522s 0.2431707233s infinite;
}

@-webkit-keyframes drop-108 {
  100% {
    top: 110%;
    left: 42%;
  }
}

@keyframes  drop-108 {
  100% {
    top: 110%;
    left: 42%;
  }
}
.confetti-109 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 60%;
  opacity: 1.0760044841;
  transform: rotate(107.591864986deg);
  -webkit-animation: drop-109 4.7602505821s 0.3499946406s infinite;
          animation: drop-109 4.7602505821s 0.3499946406s infinite;
}

@-webkit-keyframes drop-109 {
  100% {
    top: 110%;
    left: 62%;
  }
}

@keyframes  drop-109 {
  100% {
    top: 110%;
    left: 62%;
  }
}
.confetti-110 {
  width: 2px;
  height: 0.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 73%;
  opacity: 0.7195734182;
  transform: rotate(62.9980218223deg);
  -webkit-animation: drop-110 4.8725605959s 0.0273814149s infinite;
          animation: drop-110 4.8725605959s 0.0273814149s infinite;
}

@-webkit-keyframes drop-110 {
  100% {
    top: 110%;
    left: 77%;
  }
}

@keyframes  drop-110 {
  100% {
    top: 110%;
    left: 77%;
  }
}
.confetti-111 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 24%;
  opacity: 1.3683984759;
  transform: rotate(134.6755946336deg);
  -webkit-animation: drop-111 4.6942200885s 0.073664726s infinite;
          animation: drop-111 4.6942200885s 0.073664726s infinite;
}

@-webkit-keyframes drop-111 {
  100% {
    top: 110%;
    left: 39%;
  }
}

@keyframes  drop-111 {
  100% {
    top: 110%;
    left: 39%;
  }
}
.confetti-112 {
  width: 2px;
  height: 0.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 30%;
  opacity: 1.3400495249;
  transform: rotate(147.8294477987deg);
  -webkit-animation: drop-112 4.6424973134s 0.2344795397s infinite;
          animation: drop-112 4.6424973134s 0.2344795397s infinite;
}

@-webkit-keyframes drop-112 {
  100% {
    top: 110%;
    left: 31%;
  }
}

@keyframes  drop-112 {
  100% {
    top: 110%;
    left: 31%;
  }
}
.confetti-113 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 24%;
  opacity: 0.9324286167;
  transform: rotate(164.7589558636deg);
  -webkit-animation: drop-113 4.561393926s 0.9701023115s infinite;
          animation: drop-113 4.561393926s 0.9701023115s infinite;
}

@-webkit-keyframes drop-113 {
  100% {
    top: 110%;
    left: 39%;
  }
}

@keyframes  drop-113 {
  100% {
    top: 110%;
    left: 39%;
  }
}
.confetti-114 {
  width: 2px;
  height: 0.8px;
  background-color: #d13447;
  top: -10%;
  left: 100%;
  opacity: 0.6185080284;
  transform: rotate(131.7523838706deg);
  -webkit-animation: drop-114 4.0160028078s 0.4354901569s infinite;
          animation: drop-114 4.0160028078s 0.4354901569s infinite;
}

@-webkit-keyframes drop-114 {
  100% {
    top: 110%;
    left: 115%;
  }
}

@keyframes  drop-114 {
  100% {
    top: 110%;
    left: 115%;
  }
}
.confetti-115 {
  width: 6px;
  height: 2.4px;
  background-color: #263672;
  top: -10%;
  left: 76%;
  opacity: 0.5503677383;
  transform: rotate(284.4363377119deg);
  -webkit-animation: drop-115 4.583927432s 0.917570318s infinite;
          animation: drop-115 4.583927432s 0.917570318s infinite;
}

@-webkit-keyframes drop-115 {
  100% {
    top: 110%;
    left: 91%;
  }
}

@keyframes  drop-115 {
  100% {
    top: 110%;
    left: 91%;
  }
}
.confetti-116 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 61%;
  opacity: 1.3049321929;
  transform: rotate(290.0365562238deg);
  -webkit-animation: drop-116 4.1317347445s 0.3452099226s infinite;
          animation: drop-116 4.1317347445s 0.3452099226s infinite;
}

@-webkit-keyframes drop-116 {
  100% {
    top: 110%;
    left: 70%;
  }
}

@keyframes  drop-116 {
  100% {
    top: 110%;
    left: 70%;
  }
}
.confetti-117 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 60%;
  opacity: 1.2191075867;
  transform: rotate(346.9260230475deg);
  -webkit-animation: drop-117 4.6080655852s 0.8313145311s infinite;
          animation: drop-117 4.6080655852s 0.8313145311s infinite;
}

@-webkit-keyframes drop-117 {
  100% {
    top: 110%;
    left: 65%;
  }
}

@keyframes  drop-117 {
  100% {
    top: 110%;
    left: 65%;
  }
}
.confetti-118 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 45%;
  opacity: 0.8086599684;
  transform: rotate(102.9318353878deg);
  -webkit-animation: drop-118 4.8887575742s 0.7878432735s infinite;
          animation: drop-118 4.8887575742s 0.7878432735s infinite;
}

@-webkit-keyframes drop-118 {
  100% {
    top: 110%;
    left: 47%;
  }
}

@keyframes  drop-118 {
  100% {
    top: 110%;
    left: 47%;
  }
}
.confetti-119 {
  width: 2px;
  height: 0.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 51%;
  opacity: 1.4239280113;
  transform: rotate(68.6354390081deg);
  -webkit-animation: drop-119 4.7697121023s 0.639220278s infinite;
          animation: drop-119 4.7697121023s 0.639220278s infinite;
}

@-webkit-keyframes drop-119 {
  100% {
    top: 110%;
    left: 52%;
  }
}

@keyframes  drop-119 {
  100% {
    top: 110%;
    left: 52%;
  }
}
.confetti-120 {
  width: 5px;
  height: 2px;
  background-color: #263672;
  top: -10%;
  left: 2%;
  opacity: 0.6781557657;
  transform: rotate(55.9409224272deg);
  -webkit-animation: drop-120 4.1888120445s 0.9941468132s infinite;
          animation: drop-120 4.1888120445s 0.9941468132s infinite;
}

@-webkit-keyframes drop-120 {
  100% {
    top: 110%;
    left: 16%;
  }
}

@keyframes  drop-120 {
  100% {
    top: 110%;
    left: 16%;
  }
}
.confetti-121 {
  width: 2px;
  height: 0.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 84%;
  opacity: 0.8335032106;
  transform: rotate(279.8492849603deg);
  -webkit-animation: drop-121 4.663238434s 0.6695662465s infinite;
          animation: drop-121 4.663238434s 0.6695662465s infinite;
}

@-webkit-keyframes drop-121 {
  100% {
    top: 110%;
    left: 96%;
  }
}

@keyframes  drop-121 {
  100% {
    top: 110%;
    left: 96%;
  }
}
.confetti-122 {
  width: 1px;
  height: 0.4px;
  background-color: #d13447;
  top: -10%;
  left: 32%;
  opacity: 1.3783742339;
  transform: rotate(295.955123876deg);
  -webkit-animation: drop-122 4.3440739413s 0.0836829688s infinite;
          animation: drop-122 4.3440739413s 0.0836829688s infinite;
}

@-webkit-keyframes drop-122 {
  100% {
    top: 110%;
    left: 46%;
  }
}

@keyframes  drop-122 {
  100% {
    top: 110%;
    left: 46%;
  }
}
.confetti-123 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 30%;
  opacity: 0.8708867362;
  transform: rotate(181.2757315818deg);
  -webkit-animation: drop-123 4.8039665314s 0.2267187197s infinite;
          animation: drop-123 4.8039665314s 0.2267187197s infinite;
}

@-webkit-keyframes drop-123 {
  100% {
    top: 110%;
    left: 33%;
  }
}

@keyframes  drop-123 {
  100% {
    top: 110%;
    left: 33%;
  }
}
.confetti-124 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 19%;
  opacity: 1.0878086675;
  transform: rotate(49.2098686931deg);
  -webkit-animation: drop-124 4.6124392138s 0.789130861s infinite;
          animation: drop-124 4.6124392138s 0.789130861s infinite;
}

@-webkit-keyframes drop-124 {
  100% {
    top: 110%;
    left: 22%;
  }
}

@keyframes  drop-124 {
  100% {
    top: 110%;
    left: 22%;
  }
}
.confetti-125 {
  width: 3px;
  height: 1.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 16%;
  opacity: 1.3614333457;
  transform: rotate(56.198821185deg);
  -webkit-animation: drop-125 4.5106812091s 0.8060591719s infinite;
          animation: drop-125 4.5106812091s 0.8060591719s infinite;
}

@-webkit-keyframes drop-125 {
  100% {
    top: 110%;
    left: 31%;
  }
}

@keyframes  drop-125 {
  100% {
    top: 110%;
    left: 31%;
  }
}
.confetti-126 {
  width: 2px;
  height: 0.8px;
  background-color: #263672;
  top: -10%;
  left: 37%;
  opacity: 1.267150147;
  transform: rotate(90.3421852142deg);
  -webkit-animation: drop-126 4.5387070243s 0.8513674811s infinite;
          animation: drop-126 4.5387070243s 0.8513674811s infinite;
}

@-webkit-keyframes drop-126 {
  100% {
    top: 110%;
    left: 44%;
  }
}

@keyframes  drop-126 {
  100% {
    top: 110%;
    left: 44%;
  }
}
.confetti-127 {
  width: 1px;
  height: 0.4px;
  background-color: #d13447;
  top: -10%;
  left: 82%;
  opacity: 1.4349893554;
  transform: rotate(118.433643651deg);
  -webkit-animation: drop-127 4.3695064662s 0.3265101133s infinite;
          animation: drop-127 4.3695064662s 0.3265101133s infinite;
}

@-webkit-keyframes drop-127 {
  100% {
    top: 110%;
    left: 96%;
  }
}

@keyframes  drop-127 {
  100% {
    top: 110%;
    left: 96%;
  }
}
.confetti-128 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 49%;
  opacity: 0.7791898823;
  transform: rotate(152.4721113538deg);
  -webkit-animation: drop-128 4.3593273689s 0.6877988016s infinite;
          animation: drop-128 4.3593273689s 0.6877988016s infinite;
}

@-webkit-keyframes drop-128 {
  100% {
    top: 110%;
    left: 62%;
  }
}

@keyframes  drop-128 {
  100% {
    top: 110%;
    left: 62%;
  }
}
.confetti-129 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 100%;
  opacity: 1.4661936022;
  transform: rotate(356.7141469469deg);
  -webkit-animation: drop-129 4.1565562649s 0.4317048468s infinite;
          animation: drop-129 4.1565562649s 0.4317048468s infinite;
}

@-webkit-keyframes drop-129 {
  100% {
    top: 110%;
    left: 103%;
  }
}

@keyframes  drop-129 {
  100% {
    top: 110%;
    left: 103%;
  }
}
.confetti-130 {
  width: 5px;
  height: 2px;
  background-color: #263672;
  top: -10%;
  left: 35%;
  opacity: 0.9080177238;
  transform: rotate(119.5002882758deg);
  -webkit-animation: drop-130 4.1447644353s 0.7164085836s infinite;
          animation: drop-130 4.1447644353s 0.7164085836s infinite;
}

@-webkit-keyframes drop-130 {
  100% {
    top: 110%;
    left: 48%;
  }
}

@keyframes  drop-130 {
  100% {
    top: 110%;
    left: 48%;
  }
}
.confetti-131 {
  width: 8px;
  height: 3.2px;
  background-color: #ffbf00;
  top: -10%;
  left: 81%;
  opacity: 1.4246042511;
  transform: rotate(228.3556469474deg);
  -webkit-animation: drop-131 4.9583226123s 0.1744229177s infinite;
          animation: drop-131 4.9583226123s 0.1744229177s infinite;
}

@-webkit-keyframes drop-131 {
  100% {
    top: 110%;
    left: 83%;
  }
}

@keyframes  drop-131 {
  100% {
    top: 110%;
    left: 83%;
  }
}
.confetti-132 {
  width: 2px;
  height: 0.8px;
  background-color: #263672;
  top: -10%;
  left: 49%;
  opacity: 0.8544864947;
  transform: rotate(181.2020684463deg);
  -webkit-animation: drop-132 4.1506472812s 0.2718553412s infinite;
          animation: drop-132 4.1506472812s 0.2718553412s infinite;
}

@-webkit-keyframes drop-132 {
  100% {
    top: 110%;
    left: 63%;
  }
}

@keyframes  drop-132 {
  100% {
    top: 110%;
    left: 63%;
  }
}
.confetti-133 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 51%;
  opacity: 0.7193396618;
  transform: rotate(15.3008424717deg);
  -webkit-animation: drop-133 4.131525764s 0.3175298544s infinite;
          animation: drop-133 4.131525764s 0.3175298544s infinite;
}

@-webkit-keyframes drop-133 {
  100% {
    top: 110%;
    left: 61%;
  }
}

@keyframes  drop-133 {
  100% {
    top: 110%;
    left: 61%;
  }
}
.confetti-134 {
  width: 4px;
  height: 1.6px;
  background-color: #ffbf00;
  top: -10%;
  left: 6%;
  opacity: 0.5768334669;
  transform: rotate(31.2218348785deg);
  -webkit-animation: drop-134 4.106609478s 0.7387569772s infinite;
          animation: drop-134 4.106609478s 0.7387569772s infinite;
}

@-webkit-keyframes drop-134 {
  100% {
    top: 110%;
    left: 8%;
  }
}

@keyframes  drop-134 {
  100% {
    top: 110%;
    left: 8%;
  }
}
.confetti-135 {
  width: 4px;
  height: 1.6px;
  background-color: #263672;
  top: -10%;
  left: 87%;
  opacity: 1.0640007147;
  transform: rotate(167.9393864521deg);
  -webkit-animation: drop-135 4.3944306988s 0.0458210819s infinite;
          animation: drop-135 4.3944306988s 0.0458210819s infinite;
}

@-webkit-keyframes drop-135 {
  100% {
    top: 110%;
    left: 95%;
  }
}

@keyframes  drop-135 {
  100% {
    top: 110%;
    left: 95%;
  }
}
.confetti-136 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 51%;
  opacity: 0.750951342;
  transform: rotate(267.9973519314deg);
  -webkit-animation: drop-136 4.3524405531s 0.4187830163s infinite;
          animation: drop-136 4.3524405531s 0.4187830163s infinite;
}

@-webkit-keyframes drop-136 {
  100% {
    top: 110%;
    left: 62%;
  }
}

@keyframes  drop-136 {
  100% {
    top: 110%;
    left: 62%;
  }
}
.confetti-137 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 11%;
  opacity: 1.4261564627;
  transform: rotate(289.9130526305deg);
  -webkit-animation: drop-137 4.6895312759s 0.6637158204s infinite;
          animation: drop-137 4.6895312759s 0.6637158204s infinite;
}

@-webkit-keyframes drop-137 {
  100% {
    top: 110%;
    left: 25%;
  }
}

@keyframes  drop-137 {
  100% {
    top: 110%;
    left: 25%;
  }
}
.confetti-138 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 28%;
  opacity: 1.2884733042;
  transform: rotate(48.6620431339deg);
  -webkit-animation: drop-138 4.2598319844s 0.1557392216s infinite;
          animation: drop-138 4.2598319844s 0.1557392216s infinite;
}

@-webkit-keyframes drop-138 {
  100% {
    top: 110%;
    left: 33%;
  }
}

@keyframes  drop-138 {
  100% {
    top: 110%;
    left: 33%;
  }
}
.confetti-139 {
  width: 6px;
  height: 2.4px;
  background-color: #ffbf00;
  top: -10%;
  left: 62%;
  opacity: 1.0982374003;
  transform: rotate(12.7632388663deg);
  -webkit-animation: drop-139 4.1287946332s 0.4961357521s infinite;
          animation: drop-139 4.1287946332s 0.4961357521s infinite;
}

@-webkit-keyframes drop-139 {
  100% {
    top: 110%;
    left: 73%;
  }
}

@keyframes  drop-139 {
  100% {
    top: 110%;
    left: 73%;
  }
}
.confetti-140 {
  width: 7px;
  height: 2.8px;
  background-color: #ffbf00;
  top: -10%;
  left: 34%;
  opacity: 0.8552713642;
  transform: rotate(25.3018209523deg);
  -webkit-animation: drop-140 4.4355412891s 0.5593515568s infinite;
          animation: drop-140 4.4355412891s 0.5593515568s infinite;
}

@-webkit-keyframes drop-140 {
  100% {
    top: 110%;
    left: 49%;
  }
}

@keyframes  drop-140 {
  100% {
    top: 110%;
    left: 49%;
  }
}
.confetti-141 {
  width: 1px;
  height: 0.4px;
  background-color: #263672;
  top: -10%;
  left: 4%;
  opacity: 1.1582782387;
  transform: rotate(138.6571662859deg);
  -webkit-animation: drop-141 4.3307222867s 0.0389902889s infinite;
          animation: drop-141 4.3307222867s 0.0389902889s infinite;
}

@-webkit-keyframes drop-141 {
  100% {
    top: 110%;
    left: 16%;
  }
}

@keyframes  drop-141 {
  100% {
    top: 110%;
    left: 16%;
  }
}
.confetti-142 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 3%;
  opacity: 0.7584307802;
  transform: rotate(299.6588260835deg);
  -webkit-animation: drop-142 4.0285393672s 0.5514831988s infinite;
          animation: drop-142 4.0285393672s 0.5514831988s infinite;
}

@-webkit-keyframes drop-142 {
  100% {
    top: 110%;
    left: 18%;
  }
}

@keyframes  drop-142 {
  100% {
    top: 110%;
    left: 18%;
  }
}
.confetti-143 {
  width: 8px;
  height: 3.2px;
  background-color: #d13447;
  top: -10%;
  left: 68%;
  opacity: 0.7890961999;
  transform: rotate(165.1959680324deg);
  -webkit-animation: drop-143 4.6151566068s 0.8493239767s infinite;
          animation: drop-143 4.6151566068s 0.8493239767s infinite;
}

@-webkit-keyframes drop-143 {
  100% {
    top: 110%;
    left: 71%;
  }
}

@keyframes  drop-143 {
  100% {
    top: 110%;
    left: 71%;
  }
}
.confetti-144 {
  width: 7px;
  height: 2.8px;
  background-color: #263672;
  top: -10%;
  left: 57%;
  opacity: 0.5697916276;
  transform: rotate(172.7057864175deg);
  -webkit-animation: drop-144 4.7679708822s 0.0149986435s infinite;
          animation: drop-144 4.7679708822s 0.0149986435s infinite;
}

@-webkit-keyframes drop-144 {
  100% {
    top: 110%;
    left: 61%;
  }
}

@keyframes  drop-144 {
  100% {
    top: 110%;
    left: 61%;
  }
}
.confetti-145 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 99%;
  opacity: 0.8582965612;
  transform: rotate(174.4397596622deg);
  -webkit-animation: drop-145 4.5142179299s 0.5832682154s infinite;
          animation: drop-145 4.5142179299s 0.5832682154s infinite;
}

@-webkit-keyframes drop-145 {
  100% {
    top: 110%;
    left: 104%;
  }
}

@keyframes  drop-145 {
  100% {
    top: 110%;
    left: 104%;
  }
}
.confetti-146 {
  width: 6px;
  height: 2.4px;
  background-color: #263672;
  top: -10%;
  left: 69%;
  opacity: 0.9359734577;
  transform: rotate(22.6782918779deg);
  -webkit-animation: drop-146 4.1089637747s 0.988489862s infinite;
          animation: drop-146 4.1089637747s 0.988489862s infinite;
}

@-webkit-keyframes drop-146 {
  100% {
    top: 110%;
    left: 72%;
  }
}

@keyframes  drop-146 {
  100% {
    top: 110%;
    left: 72%;
  }
}
.confetti-147 {
  width: 6px;
  height: 2.4px;
  background-color: #d13447;
  top: -10%;
  left: 84%;
  opacity: 1.1044204122;
  transform: rotate(92.4025710371deg);
  -webkit-animation: drop-147 4.0228803003s 0.0918672476s infinite;
          animation: drop-147 4.0228803003s 0.0918672476s infinite;
}

@-webkit-keyframes drop-147 {
  100% {
    top: 110%;
    left: 94%;
  }
}

@keyframes  drop-147 {
  100% {
    top: 110%;
    left: 94%;
  }
}
.confetti-148 {
  width: 2px;
  height: 0.8px;
  background-color: #d13447;
  top: -10%;
  left: 25%;
  opacity: 1.0879445331;
  transform: rotate(298.2474923645deg);
  -webkit-animation: drop-148 4.1489179603s 0.5246440714s infinite;
          animation: drop-148 4.1489179603s 0.5246440714s infinite;
}

@-webkit-keyframes drop-148 {
  100% {
    top: 110%;
    left: 39%;
  }
}

@keyframes  drop-148 {
  100% {
    top: 110%;
    left: 39%;
  }
}
.confetti-149 {
  width: 4px;
  height: 1.6px;
  background-color: #d13447;
  top: -10%;
  left: 91%;
  opacity: 1.3074829524;
  transform: rotate(52.926920732deg);
  -webkit-animation: drop-149 4.1425239814s 0.4164271854s infinite;
          animation: drop-149 4.1425239814s 0.4164271854s infinite;
}

@-webkit-keyframes drop-149 {
  100% {
    top: 110%;
    left: 103%;
  }
}

@keyframes  drop-149 {
  100% {
    top: 110%;
    left: 103%;
  }
}
</style>
<div class="wrapper-confeti">
  <div class="confetti-149"></div>
  <div class="confetti-148"></div>
  <div class="confetti-147"></div>
  <div class="confetti-146"></div>
  <div class="confetti-145"></div>
  <div class="confetti-144"></div>
  <div class="confetti-143"></div>
  <div class="confetti-142"></div>
  <div class="confetti-141"></div>
  <div class="confetti-140"></div>
  <div class="confetti-139"></div>
  <div class="confetti-138"></div>
  <div class="confetti-137"></div>
  <div class="confetti-136"></div>
  <div class="confetti-135"></div>
  <div class="confetti-134"></div>
  <div class="confetti-133"></div>
  <div class="confetti-132"></div>
  <div class="confetti-131"></div>
  <div class="confetti-130"></div>
  <div class="confetti-129"></div>
  <div class="confetti-128"></div>
  <div class="confetti-127"></div>
  <div class="confetti-126"></div>
  <div class="confetti-125"></div>
  <div class="confetti-124"></div>
  <div class="confetti-123"></div>
  <div class="confetti-122"></div>
  <div class="confetti-121"></div>
  <div class="confetti-120"></div>
  <div class="confetti-119"></div>
  <div class="confetti-118"></div>
  <div class="confetti-117"></div>
  <div class="confetti-116"></div>
  <div class="confetti-115"></div>
  <div class="confetti-114"></div>
  <div class="confetti-113"></div>
  <div class="confetti-112"></div>
  <div class="confetti-111"></div>
  <div class="confetti-110"></div>
  <div class="confetti-109"></div>
  <div class="confetti-108"></div>
  <div class="confetti-107"></div>
  <div class="confetti-106"></div>
  <div class="confetti-105"></div>
  <div class="confetti-104"></div>
  <div class="confetti-103"></div>
  <div class="confetti-102"></div>
  <div class="confetti-101"></div>
  <div class="confetti-100"></div>
  <div class="confetti-99"></div>
  <div class="confetti-98"></div>
  <div class="confetti-97"></div>
  <div class="confetti-96"></div>
  <div class="confetti-95"></div>
  <div class="confetti-94"></div>
  <div class="confetti-93"></div>
  <div class="confetti-92"></div>
  <div class="confetti-91"></div>
  <div class="confetti-90"></div>
  <div class="confetti-89"></div>
  <div class="confetti-88"></div>
  <div class="confetti-87"></div>
  <div class="confetti-86"></div>
  <div class="confetti-85"></div>
  <div class="confetti-84"></div>
  <div class="confetti-83"></div>
  <div class="confetti-82"></div>
  <div class="confetti-81"></div>
  <div class="confetti-80"></div>
  <div class="confetti-79"></div>
  <div class="confetti-78"></div>
  <div class="confetti-77"></div>
  <div class="confetti-76"></div>
  <div class="confetti-75"></div>
  <div class="confetti-74"></div>
  <div class="confetti-73"></div>
  <div class="confetti-72"></div>
  <div class="confetti-71"></div>
  <div class="confetti-70"></div>
  <div class="confetti-69"></div>
  <div class="confetti-68"></div>
  <div class="confetti-67"></div>
  <div class="confetti-66"></div>
  <div class="confetti-65"></div>
  <div class="confetti-64"></div>
  <div class="confetti-63"></div>
  <div class="confetti-62"></div>
  <div class="confetti-61"></div>
  <div class="confetti-60"></div>
  <div class="confetti-59"></div>
  <div class="confetti-58"></div>
  <div class="confetti-57"></div>
  <div class="confetti-56"></div>
  <div class="confetti-55"></div>
  <div class="confetti-54"></div>
  <div class="confetti-53"></div>
  <div class="confetti-52"></div>
  <div class="confetti-51"></div>
  <div class="confetti-50"></div>
  <div class="confetti-49"></div>
  <div class="confetti-48"></div>
  <div class="confetti-47"></div>
  <div class="confetti-46"></div>
  <div class="confetti-45"></div>
  <div class="confetti-44"></div>
  <div class="confetti-43"></div>
  <div class="confetti-42"></div>
  <div class="confetti-41"></div>
  <div class="confetti-40"></div>
  <div class="confetti-39"></div>
  <div class="confetti-38"></div>
  <div class="confetti-37"></div>
  <div class="confetti-36"></div>
  <div class="confetti-35"></div>
  <div class="confetti-34"></div>
  <div class="confetti-33"></div>
  <div class="confetti-32"></div>
  <div class="confetti-31"></div>
  <div class="confetti-30"></div>
  <div class="confetti-29"></div>
  <div class="confetti-28"></div>
  <div class="confetti-27"></div>
  <div class="confetti-26"></div>
  <div class="confetti-25"></div>
  <div class="confetti-24"></div>
  <div class="confetti-23"></div>
  <div class="confetti-22"></div>
  <div class="confetti-21"></div>
  <div class="confetti-20"></div>
  <div class="confetti-19"></div>
  <div class="confetti-18"></div>
  <div class="confetti-17"></div>
  <div class="confetti-16"></div>
  <div class="confetti-15"></div>
  <div class="confetti-14"></div>
  <div class="confetti-13"></div>
  <div class="confetti-12"></div>
  <div class="confetti-11"></div>
  <div class="confetti-10"></div>
  <div class="confetti-9"></div>
  <div class="confetti-8"></div>
  <div class="confetti-7"></div>
  <div class="confetti-6"></div>
  <div class="confetti-5"></div>
  <div class="confetti-4"></div>
  <div class="confetti-3"></div>
  <div class="confetti-2"></div>
  <div class="confetti-1"></div>
  <div class="confetti-0"></div>
</div><?php /**PATH C:\wamp64\www\polla_america\resources\views/trivias/partials/confeti.blade.php ENDPATH**/ ?>