

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Sobre la Polla</span></h1>
			<h2>¿Qué es?</h2>
			
			<h2>Términos y condiciones</h2>
			
			<h2>Políticas de privacidad</h2>
			
		</section>
		
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/la-polla.blade.php ENDPATH**/ ?>