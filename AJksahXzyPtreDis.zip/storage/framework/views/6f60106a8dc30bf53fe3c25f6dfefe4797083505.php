

<?php $__env->startSection('content'); ?>
	<main>
		<section>
			<h1><span><?php echo e($trivia->titulo); ?></span></h1>
		</section>
		<section>
			<p style="text-align: center;"><?php echo e($trivia->objetivo); ?></p>
			<div class="divider"></div>
			<div style="max-width: 400px; display: block; margin: 20px auto; width: 95%;">
				<strong class="instruciones">Instruciones</strong>
				<div class="intrucion">
					<span>1</span>
					<p>Cada pregunta tiene un tiempo limite para responder</p>
				</div>
				<div class="intrucion">
					<span>2</span>
					<p>Si no respondes antes de terminar el tiempo, no podras volver a responder esa pregunta</p>
				</div>
				<div class="intrucion">
					<span>3</span>
					<p>Solo tienes una oportunidad por cada pregunta</p>
				</div>
				<div class="intrucion">
					<span>4</span>
					<p>Al finalizar la trivia te mostraremos los puntos que sumaste</p>
				</div>
				<a href="<?php echo e(route('trivia.play', $trivia->id)); ?>" class="btn-big"><i class="icon-trophy"></i>Comenzar</a>
			</div>


		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/trivias/comenzar.blade.php ENDPATH**/ ?>