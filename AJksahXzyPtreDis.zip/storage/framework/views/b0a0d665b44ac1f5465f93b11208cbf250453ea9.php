<section class="popup condiciones">
	<span class="close-panel">x</span>
	<h3>Términos y condiciones</h3>
	<div class="in-pop">
<p><strong><span>POLLA MUNDIALISTA DEL ESTE</span></strong></p>
<p><span>DEL ESTE CENTRO COMERCIAL P. H presenta la actividad POLLA MUNDIALISTA DEL ESTE,</span><span> una actividad en l&iacute;nea para la predicci&oacute;n de resultados de los partidos del Mundial, cuyo objetivo es capturar y fidelizar clientes a trav&eacute;s de actividades de promoci&oacute;n y posicionamiento de marca del Centro Comercial.</span></p>
<p><span> Una vez registrado, el participante acepta los t&eacute;rminos y condiciones&nbsp;de uso y pol&iacute;tica de confidencialidad y entiende las responsabilidades derivadas de esta.</span></p>
<p><span>DEL ESTE CENTRO COMERCIAL P.H</span><span> invita a todos los clientes y visitantes a participar de la POLLA MUNDIALISTA DEL ESTE ingresando al sitio DELESTE.POLLAMUNDIALISTA.COM, ingresando sus datos personales y seleccionando las opciones que en la aplicaci&oacute;n se plantean. </span></p>
<strong>1.</strong><strong><span>MEC&Aacute;NICA PARA PARTICIPAR: </span></strong><span>Las personas naturales mayores de edad que realicen compras en los locales participantes por la cuant&iacute;a indicada para cada uno de los locales, entre el 19 de junio de 2018 y el 15 de julio de 2018, podr&aacute;n recibir una tarjeta que tendr&aacute; un c&oacute;digo de registro diferente y &uacute;nico para participar en la Polla Mundialista Del Este. </span>
<p><strong><span>Los locales participantes son los siguientes: </span></strong></p>
<ul>
<li><strong><span>ALMAC&Eacute;N &Eacute;XITO</span></strong><span>: Compras iguales o superiores a <strong>QUINIENTOS MIL PESOS ($500.000). </strong></span></li>
<li><strong><span>GIMNASIO BODYTECH:</span></strong><span> Por inscripciones de usuarios nuevos iguales o superiores a <strong>CIENTO CINCUENTA Y CINCO MIL PESOS </strong> <strong>($155.000)</strong></span></li>
<li><strong><span>FANZONE</span></strong><span>: Compras iguales o superiores a <strong>CIENTO CINCUENTA MIL PESOS ($150.000)</strong></span></li>
<li><span> <strong>MADEROS DEL ESTE</strong>: Compras iguales o superiores a <strong>CIENTO CINCUENTA MIL PESOS ($150.000).</strong></span></li>
<li><span> <strong>FUEGO LENTO</strong>: Compras iguales o superiores a <strong>CIENTO CINCUENTA MIL PESOS ($150.000)</strong></span></li>
<li><strong><span>DELLA NONNA</span></strong><span>: Compras iguales o superiores a <strong>DOSCIENTOS MIL PESOS ($200.000)</strong></span></li>
<li><strong><span>BESMART:</span></strong><span> Por inscripciones de usuarios nuevos iguales o superiores a <strong>CIENTO CINCUENTA MIL PESOS ($150.000)</strong></span></li>
<li><strong><span>JOE MIX:</span></strong><span> Compras iguales o superiores a <strong>CIENTO CINCUENTA MIL PESOS ($150.000)</strong></span></li>
<li><strong><span>KNIGHT</span></strong><span>: </span><span>Compras iguales o superiores a <strong>CIENTO CINCUENTA MIL PESOS ($150.000)</strong></span></li>
</ul>
<p><strong><span>Una vez el cliente reciba su tarjeta con el respectivo c&oacute;digo, deber&aacute; realizar los siguientes pasos:</span></strong></p>
<ol>
<li><span>Ingresar a DELESTE.LAPOLLAMUNDIAL.COM entre el 19 de junio de 2018 y el 15 de julio de 2018. </span></li>
<li><span>Registrarse con su correo electr&oacute;nico, diligenciar datos personales b&aacute;sicos como: nombre, apellidos, ciudad, c&eacute;dula de ciudadan&iacute;a y tel&eacute;fono celular, entre otros datos requeridos en el formulario. El registro deber&aacute; realizarse con datos comprobables y fidedignos. </span></li>
<li><span>Ingresar los c&oacute;digos de la POLLA MUNDIALISTA DEL ESTE asignados en las tarjetas.</span></li>
<li><span>Aceptar los t&eacute;rminos y condiciones de la actividad</span></li>
<li><span>Aceptar el manejo de datos personales (Habeas data)</span></li>
<li><span>Ingresar los marcadores que el participante considere correspondientes a los partidos que se jugar&aacute;n en el mundial. Los participantes podr&aacute;n modificar sus resultados en la polla mundialista hasta 3 minutos antes de cada partido. Cada usuario al hacer su predicci&oacute;n deber&aacute; dar clic en el bot&oacute;n "Guardar".</span></li>
<li><span>Seg&uacute;n sus predicciones y los c&oacute;digos registrados, acumular la mayor cantidad de puntos. </span><span> Es decir, </span><span>cada participante ganar&aacute; puntos de acuerdo al acierto en la predicci&oacute;n de los resultados de los partidos que cada uno haga en la aplicaci&oacute;n La Polla Futbolera en DELESTE.LAPOLLAMUNDIAL.COM</span>.</li>
<li><span>Los puntos que cada usuario obtendr&aacute;, depender&aacute;n de cu&aacute;nto se asemeja su predicci&oacute;n a la realidad, los puntos los asignar&aacute; la plataforma de manera autom&aacute;tica. </span></li>
<li><span>Los participantes de la POLLA MUNDIALISTA DEL ESTE pueden ingresar sus marcadores hasta 3 minutos antes de iniciar cada partido, se acumulan puntos de acuerdo con su predicci&oacute;n y el resultado final del partido de la siguiente manera:</span></li>
</ol>
<p><span><strong><span>ACIERTA RESULTADOS EXACTOS: </span></strong></span><span><span>ganador, perdedor y marcador exacto de cada equipo: 12 PUNTOS</span></span></p>
<p><span><strong><span>ACIERTA GANADOR Y MARCADOR DE UN EQUIPO:</span></strong></span><strong><span> 7 PUNTOS</span></strong></p>
<p><span><strong><span>ACIERTA GANADOR O EMPATE </span></strong></span><span><span>(no acierta ning&uacute;n marcador): <strong>5 PUNTOS</strong></span></span></p>
<p><span><strong><span>ACIERTA MARCADOR DE UNO DE LOS EQUIPOS </span></strong></span><span><span>(no acierta ganador ni perdedor, solo la cantidad de goles de un equipo)<strong>: 2 PUNTOS</strong></span></span></p>
<p><span><strong><span>REGISTRO DEL C&Oacute;DIGO &Uacute;NICO IMPRESO EN LAS FACTURAS DE COMPRA EN LOS LOCALES PARTICIPANTES EN LA POLLA:</span></strong></span><span><span> <strong>4 PUNTOS</strong></span></span></p>
<p><strong><span>EMPATE:</span></strong><span> En caso de existir un empate entre los participantes, se tomar&aacute; en cuenta los puntos acumulados por la redenci&oacute;n de c&oacute;digos de la factura de mayor a menor, si aun as&iacute; contin&uacute;a existiendo el empate, tendr&aacute; prevalencia el participante que se registr&oacute; primero en la actividad.</span></p>

<span>Al correo electr&oacute;nico registrado por el cliente le llegar&aacute; la confirmaci&oacute;n correspondiente de la participaci&oacute;n en la POLLA MUNDIALISTA DEL ESTE, y ser&aacute; este medio de comunicaci&oacute;n, el canal oficial de comunicaci&oacute;n entre el participante y el organizador de la actividad.</span>

<strong>2.</strong><strong><span>RESTRICCIONES: </span></strong>

<ol>
<li><span>Solo participan personales naturales mayores de edad. </span></li>
<li><span>Cada local har&aacute; entrega de los c&oacute;digos que tenga disponibles, hasta agotar existencias. Es decir, cada local tiene un n&uacute;mero m&aacute;ximo de tarjetas con c&oacute;digos para participar, y una vez sean entregados en su totalidad podr&aacute;n suspender la entrega de los mismos. </span></li>
<li><span> No es permitido que un mismo usuario ingrese con varias cuentas para participar.</span></li>
<li><span>En total ser&aacute;n 10 ganadores. </span></li>
<li><span>NO podr&aacute; participar empleados de </span><span>DEL ESTE CENTRO COMERCIAL</span></li>
<li><span>En caso de que se genere impuesto por ganancia ocasional deber&aacute; ser asumido por el ganador. </span></li>
</ol>
<p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span>&nbsp; </span></p>
<p><strong>3.<span> DESCALIFICACIONES Y PENALIZACIONES:</span></strong><span> Se establece la posibilidad de dar de baja o descalificar usuarios participantes en la POLLA MUNDIALISTA DEL ESTE que incumplan las reglas y requisitos de la actividad o que actu&eacute; de manera fraudulenta.</span></p>
<p><strong>4</strong><span>. <strong>OBSEQUIOS: </strong>En total ser&aacute;n 10 ganadores, elegidos de acuerdo al puesto que ocupe al ordenar a los participantes seg&uacute;n el n&uacute;mero de puntos acumulados de mayor a menor en la POLLA FUTBOLERA DEL ESTE. </span></p>
<p><strong><span>LOS OBSEQUIOS SER&Aacute;N LOS SIGUIENTES:</span></strong></p>
<strong>A.</strong><strong><span>PRIMER PUESTO: TRES MILLONES DE PESOS ($ 3.000.000) REPRESENTADOS EN: </span></strong>

<ul>
<li><span>Una (1) Alineaci&oacute;n de direcci&oacute;n + cuatro (4) balanceos de llantas + un (1) Mantenimiento de Frenos en la </span><strong><span>SERVITECA MULTICAR TEXACO ENVIGADO DEL ESTE.</span></strong></li>
<li><span> Tres (</span></li>
<li><span>Un (1) Accesorio de Leobay.</span></li>
<li><span> Una (1) Comida </span><span>(Hamburguesa Americana)</span><span>, para 6 personas en Fanzone del Este</span><span>.</span></li>
<li><span>Una (1) Jarra de sangr&iacute;a + nachos de la casa en Maderos del Este.</span></li>
<li><span>SPA GENERAL en Knight del este.</span></li>
<li><span>Una (1) asesor&iacute;a de imagen en Armattura del Este.</span></li>
<li><span>Un (1) bono de UN MILL&Oacute;N DE PESOS ($1.000.000) para redimir en compras en el &Eacute;XITO del Este. </span></li>
<li><span>Dos (2) fotodepilaciones (zonas peque&ntilde;as) + 1 fotorejuvenecimiento + 1 limpieza en Bodybrite del Este.</span></li>
<li><span>Un (1) bono de DOSCIENTOS MIL PESOS ($200.000) para redimir en el Local Fuego Lento del Este.</span></li>
<li><span> Una (1) cena para 2 personas + una (1) botella de vino en Della Nonna Del este</span></li>
<li><span> Un plan de 8 entrenamientos en Be Smart Del Este.</span></li>
<li><span>Un (1) bono de CIENTO CINCUENTA MIL PESOS (150.000)para redimir en Joe mix Del Este. </span></li>
<li><span>Un (1) arreglo de manos y pies en la peluquer&iacute;a Luz &Aacute;ngel Del Este. </span></li>
</ul>
<strong>B.</strong><strong><span>SEGUNDO PUESTO: </span></strong><span> <strong>UN MILL&Oacute;N DE PESOS ($ 1.000.000) REPRESENTADOS EN</strong></span><strong><span>: </span></strong>

<ul>
<li><span>Una (1) Alineaci&oacute;n de direcci&oacute;n + cuatro (4) balanceos de llantas + Mano de obra para un cambio de l&iacute;quido de frenos en la </span><strong><span>SERVITECA MULTICAR TEXACO ENVIGADO DEL ESTE.</span></strong></li>
<li><span>Quince (15) d&iacute;as gratis en el Gimnasio Bodytech.</span></li>
<li><span>Una (1) Comida (Hamburguesa Americana), para 4 personas en Fanzone del Este. </span></li>
<li><span>Un (1) Bucket de cervezas + papas de la casa en Maderos del Este.</span></li>
<li><span>Una (1) brillada con m&aacute;quina en Knight del Este.</span></li>
<li><span> Una (1) ancheta de QUINIENTOS MIL PESOS ($500.000) del &Eacute;xito Del Este.</span></li>
<li><span>Una (1) botella de vino + una (1) entrada </span><span>en Della Nonna Del Este. </span></li>
<li><span>Dos (2) 2 fotodepilaciones (zonas peque&ntilde;as) + una (1) limpieza en Bodybrite. </span></li>
<li><span>Un (1) arreglo de manos y pies en la peluquer&iacute;a Luz &Aacute;ngel. </span></li>
</ul>
<strong>C.</strong><strong><span>TERCER PUESTO: SEISCIENTOS MIL PESOS (</span></strong><span><strong><span>$600.000) REPRESENTADOS EN: </span></strong></span>
<ul>
<li><span>Una (1) alineaci&oacute;n de direcci&oacute;n + 4 balanceos de llantas en la </span><strong><span>SERVITECA MULTICAR TEXACO ENVIGADO DEL ESTE.</span></strong></li>
<li><span>Quince (</span></li>
<li><span>Un (1) Sanduche con una (1) bebida en Maderos del Este.</span></li>
<li><span>Una (1) Comida (Hamburguesa Americana), para dos (2) personas en Fanzone del Este.</span></li>
<li><span>Una (1) lavada de motor en Knight del Este.</span></li>
<li><span>Una (1) ancheta del &Eacute;xito Del Este de DOSCIENTOS CINCUENTA MIL PESOS ($250.000).</span></li>
<li><span>Una (1) botella de vino en Della Nonna del Este. </span></li>
<li><span>Un (1) bono de TREINTA MIL PESOS ($30.000) para ser redimido en Bodybrite del Este.</span></li>
<li><span>Un (1) arreglo de manos y pies en la peluquer&iacute;a Luz &Aacute;ngel. </span></li>
</ul>

<strong>D.</strong><strong><span>CUARTO, QUINTO, SEXTO, S&Eacute;PTIMO, Y OCTAVO PUESTO: </span></strong><span>Un (1) </span><span><span>Balanceo<span> GRATIS + <span>una (1) <span>Alineaci&oacute;n en la </span></span></span></span></span><strong><span>SERVITECA MULTICAR TEXACO ENVIGADO DEL ESTE.</span></strong>

<strong>E.</strong><strong><span>NOVENO Y D&Eacute;CIMO PUESTO: </span></strong><span>Un (1) balanceo gratis en la </span><strong><span>SERVITECA MULTICAR TEXACO ENVIGADO DEL ESTE. </span></strong>

<p>&nbsp;</p>

<strong>F.</strong><strong><span> Adicionalmente,</span></strong><span> se conceder&aacute; un <strong>10%</strong> de descuento en COSECHAS DEL ESTE, en su l&iacute;nea de batidos Verde y Refrescante para todas las personas que se inscriban a la polla, presentando la constancia de la creaci&oacute;n del perfil para participar en DELESTE. LAPOLLAMUNDIAL.COM. </span><br><br>

<strong>5.</strong><span>DEL ESTE CENTRO COMERCIAL</span>
<p><span>Para reclamar el obsequio, el beneficiario deber&aacute; presentar documento de identificaci&oacute;n y la constancia del registro del perfil con el cual particip&oacute;, como m&aacute;ximo 20 d&iacute;as calendario despu&eacute;s de haber sido notificado como ganador en las redes sociales de DEL ESTE, es decir, a partir del 17 de julio de 2018 hasta el 06 de agosto de 2018. </span></p>
<p><span>En caso de no cumplir con los requisitos mencionados y/o </span><span>no reclamar el obsequio durante el tiempo estipulado</span><span>, se entender&aacute; que renuncia a &eacute;l y el Centro Comercial estar&aacute; en la libertad de entregarlo al siguiente participante con el mayor puntaje de acuerdo a la mec&aacute;nica explicada. </span></p>
<p><span>Al momento de reclamar el premio al ganador se le har&aacute; entrega de un bono en el que se discriminar&aacute; a lo que tiene derecho y deber&aacute; presentar el bono en cada establecimiento a medida que vaya redimiendo sus premios. </span></p>
<p><span>Los premios ser&aacute;n redimibles desde el momento que reclame el premio hasta el 31 de diciembre de 2018, teniendo en cuenta la disponibilidad de cada local, despu&eacute;s de este t&eacute;rmino el premio caducar&aacute;. </span></p>
<p><span><span>Los premios entregados no son canjeables por otros premios y/o por dinero o transferible a otras personas. </span></span></p>
<p><span>Los premios son personales e intransferibles. </span></p>
<p><span>Por ning&uacute;n motivo se entregar&aacute; el valor del premio en efectivo. </span></p>
<p><span><span>No se podr&aacute; ganar m&aacute;s de un premio.</span></span></p>
<p><strong>6.</strong><span>DEL ESTE CENTRO COMERCIAL</span><span> PH </span><span><span>no se har&aacute; responsable de los gastos adicionales requeridos para la entrega del premio, y en caso de generarse la obligaci&oacute;n del pago por ganancia ocasional, &eacute;ste deber&aacute; ser asumido por el ganador. </span></span></p>
<p><span>Al momento de recibir el premio, el ganador deber&aacute; firmar la respectiva acta de entrega. </span></p>
<p><span>La responsabilidad de DEL ESTE CENTRO COMERCIAL P.H. termina con la entrega del obsequio, por lo tanto, cualquier reclamaci&oacute;n relacionada con defectos del servicio prestado o producto recibido como incentivo, deber&aacute; ser atendido por el proveedor del servicio, eximiendo de cualquier responsabilidad a DEL ESTE CENTRO COMERCIAL P.H. </span></p>
<p><strong>7.<span> ACEPTACI&Oacute;N DE LAS BASES DE ESTE CONCURSO: </span></strong><span>Al participar autoriza a DEL ESTE CENTRO COMERCIAL P.H. como organizador a difundir y publicar su nombre; y a divulgar y en general a usar sus im&aacute;genes, fotograf&iacute;as, fotogramas y fonogramas en los medios y en las formas que el organizador considere convenientes para efectos de publicaci&oacute;n testimonial de dicha actividad, sin derecho a remuneraci&oacute;n o compensaci&oacute;n alguna. Por tanto renuncia a cualquier reclamo por derechos de imagen o de propiedad intelectual.</span></p>
<p>&nbsp;</p>
<p><span>Igualmente, al participar de la polla futbolera y dar tus datos personales est&aacute;s aceptando de forma expresa los anteriores t&eacute;rminos y condiciones. </span></p>
<p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
<p><span>En caso de que desee obtener m&aacute;s informaci&oacute;n podr&aacute; ponerse en contacto con el Mall Comercial, llamando al siguiente n&uacute;mero de tel&eacute;fono </span><span>&nbsp;4180188; </span><span>o enviando un email a </span><span>mercadeo@ccdeleste.com</span></p>

	</div>
</section>

<?php /**PATH C:\wamp64\www\polla_america\resources\views/layouts/partials/terminos.blade.php ENDPATH**/ ?>