

<?php $__env->startSection('content'); ?>
	<main>

		<section>
			<h1><span>Plan de premios</span></h1>
			<?php $__currentLoopData = config('polla.premios'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<h2><?php echo e($premio['titulo']); ?></h2>
				<div class="editado">
					<img class="premio-plan" src="<?php echo e(asset('images')); ?>/<?php echo e($premio['img']); ?>" alt="<?php echo e($premio['titulo']); ?>">
					<p><?php echo e($premio['descripcion_larga']); ?></p>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			
			
		</section>
		
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\polla_america\resources\views/plan-premios.blade.php ENDPATH**/ ?>