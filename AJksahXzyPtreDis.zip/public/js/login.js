$( document ).ready(function(){

	$('.btn-sesion').click(function(){
		$('.form-login').slideToggle();
		$('.form-register').slideUp();
	});
	$('.btn-register').click(function(){
		$('.form-register').slideToggle();
		$('.form-login').slideUp();
	});

	// muestra el popup de condiciones y politicas
	$('.a-cond').click(function(e){
		e.preventDefault();
		$('.condiciones').show();
	});
	$('.a-poli').click(function(e){
		e.preventDefault();
		$('.politicas').show();
	});
	$('.close-panel').click(function(){
		$('.condiciones').hide();
		$('.politicas').hide();
	});

});