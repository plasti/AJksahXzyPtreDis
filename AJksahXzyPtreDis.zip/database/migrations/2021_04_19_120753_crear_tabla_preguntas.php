<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaPreguntas extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('preguntas', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_trivia')->nullable();
            $table->text('pregunta')->nullable();
            $table->text('puntos')->nullable();
            $table->text('imagen')->nullable();
            $table->text('opcion_a')->nullable();
            $table->text('opcion_b')->nullable();
            $table->text('opcion_c')->nullable();
            $table->text('opcion_d')->nullable();
            $table->string('respuesta')->nullable();
            $table->string('tiempo')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('preguntas');
    }
}
