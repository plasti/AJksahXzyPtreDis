<?php

use Illuminate\Database\Seeder;
use App\Group;
use App\User;
use App\Widget;

class DatabaseSeeder extends Seeder
{
	/**
	* Run the database seeds.
	*
	* @return void
	*/
	public function run()
	{
		
		
		Group::create([
			'name' => 'General'
		]);

		User::create([
			'name' => 'Plastimedia',
			'email' => 'desarrollo@plastimedia.com',
			'password' => bcrypt('plasti249'),
			'role' => 'admin',
			'document' => '0',
		]);

		Widget::create([
			'estado' => 'Inactivo',
			'titulo' => null,
			'wpp' => null,
			'tel' => null,
			'color' => '#111111',
		]);

		$this->call(TeamsTableSeeder::class);
		$this->call(MatchsTableSeeder::class);

	}

}
