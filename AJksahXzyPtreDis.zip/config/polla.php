<?php 
// Array de configuracion
// ---------------------
return [
	'id' => 'polla_america_pruebas', // id para las notificaciones de cada polla
	'name' => 'Demo', //-> nombre que aparecera en la app
	'debug' => true,
	'register' => true, // -> registro de usuarios
	'code_reg' => true, // -> si requiere un codigo para poder registrarse
	'groups' => true, // -> si se juega por grupos 
	'code_section' => true, // -> si tiene seccion de codigos para acumular puntos
	'widget' => true,
	'code_points' => 3, // -> puntos por cada codigo que registr en la seccion de codigos
	'slider' => true, // -> si cuenta con slider para pautas y promociones dentro de la app
	'trivia' => true, // -> si cuenta con trivia
	'users_admin' => true, // -> si cuenta con administracion de usuarios
	'login_redes' => true, // -> si cuenta con login con rede sociales
	'callback_facebook' => 'http://localhost/polla_america/public/register/callback-facebook',
	'callback_google' => 'http://localhost/polla_america/public/register/callback-google',
	// 'logros' => true, // -> si tiene apartado de logros
	'ruta_madre' => 'http://plastimedia.com/polla_madre/public/xml/example.xml', // -> ruta madre
	'app_mobile' => true, // -> si cuenta con app mobile
	'primario' => '#eec211', // -> color para la aplicación mobile
	'secundario' => '#ffffff', // -> color para la aplicación mobile
	'terciario' => '#de0209', // -> color para la aplicación mobile
	'premios' => [
		[
			'img' => 'premio-1.jpg',
			'titulo' => '1° Puesto',
			'descripcion' => 'Viaje para 2 personas a Europa',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
		[
			'img' => 'premio-2.jpg',
			'titulo' => '2° Puesto',
			'descripcion' => 'LED Full HD de 49 pulgadas',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
		[
			'img' => 'premio-3.jpg',
			'titulo' => '3° Puesto',
			'descripcion' => 'Celular Huawei P9',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
		[
			'img' => 'premio-3.jpg',
			'titulo' => '4° Puesto',
			'descripcion' => 'Celular apple P9',
			'descripcion_larga' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero nemo consequuntur recusandae doloribus, modi. Optio asperiores iste nam fuga, voluptatibus corporis aut esse molestiae magnam ratione, expedita aspernatur vel. Accusantium.',
		],
	],

	// canal 0
	// -----------------------
	// los accesos para administrar las cuentas de pusher
	// url: https://pusher.com
	// ----------------------

	// canal 1
	// user: soporte@lapollamundial.com
	// pass: plasti249

	// canal 2
	// user: contacto@lapollamundial.com
	// pass: plasti249

	// canal 3
	// user: ssl1@plastimedia.com
	// pass: plasti249

	// canal 4
	// user: ssl2@plastimedia.com
	// pass: plasti249

	// canal 5
	// user: ssl4@plastimedia.com
	// pass: plasti249
	// -------------------
];

?>