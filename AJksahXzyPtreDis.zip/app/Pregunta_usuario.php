<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pregunta_usuario extends Model
{
    protected $table = 'preguntas_usuario';

	protected $fillable = [
		'id_pregunta',
		'id_user',
		'respuesta',
		'puntos',
	];
}
