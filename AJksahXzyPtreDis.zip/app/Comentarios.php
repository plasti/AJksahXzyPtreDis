<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comentarios extends Model
{
	protected $table = 'comentarios';

	protected $fillable = [
		'id_user',
		'id_match',
		'text',
	];

	/**
	* Obtiene una lista de los usuarios que pertenecen a un grupo
	*/
	public function user()
	{
		return $this->belongsTo('App\User', 'id_user');
	}

	public function match()
	{
		return $this->belongsTo('App\Match', 'id_match');
	}
}
