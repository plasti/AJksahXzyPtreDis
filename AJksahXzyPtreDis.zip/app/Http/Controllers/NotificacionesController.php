<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notificaciones;
use Auth;

class NotificacionesController extends Controller
{
    public function index()
    {
    	$notificaciones = Notificaciones::orderBy('id', 'DESC')->where('id_user', Auth::user()->id)->paginate(2);
    	$notificaciones_new = Notificaciones::where('estado', '<>', null)->where('id_user', Auth::user()->id)->get();
    	foreach ($notificaciones_new as $old) {
    		$old->estado = null;
    		$old->update();
    	}
    	return view('notificaciones.index', ['notificaciones' => $notificaciones]);
    }
}
