<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Match;
use App\Group;
use App\Pregunta_usuario;
use App\Plastimedia;

class PointsController extends Controller
{
  
	/*
	 * Método para calcular los puntos por prediccion de los usuarios
	 */
  public function predictionPoints()
	{
		// Busco el partido que hay que editar
		$match = Match::where('updated', 1)->first();

		$am = $match->score_a;
		$bm = $match->score_b;

		foreach ($match->predictions as $prediction) {
			$ap = $prediction->a_score;
			$bp = $prediction->b_score;

			// Calculo los puntos
			if ($am == $ap && $bm== $bp) {
				$points = 12;
			} elseif ( ($am > $bm && $ap > $bp) || ($am < $bm && $ap < $bp) || ($am == $bm && $ap == $bp) ) {
				if ($am == $ap || $bm == $bp) {
					$points = 7;
				} else {
					$points = 5;
				}
			}	elseif ($am == $ap || $bm == $bp) {
					$points = 2;
			} else {
				$points = 0;
			}

			// Guardo los puntos en la base de datos
			$prediction->points = $points;
			$prediction->save();
		}

		return 'Puntos de las predicciones de los usuarios calculados';
	}

	/*
	 * Método para calcular los puntos de todos los usuarios
	 */
  public function allUserPoints()
	{
		$predicciones = DB::raw('( SELECT user_id, SUM(points) as total FROM user_predictions GROUP BY user_id ) as prediccion');

		$users = DB::table('users');
			
		// Si esta activado el registro de códigos obtengo la cantidad de códigos por usuario
		if ( config('polla.code_section') ) {
			$codigos = DB::raw('(SELECT user_id, COUNT(user_id) AS cantidad FROM user_codes GROUP BY user_id) as codigos');
			$users = $users->select('users.id','prediccion.total as points', 'codigos.cantidad')
				->leftJoin($codigos, 'users.id', '=', 'codigos.user_id');
		} else {
			$users = $users->select('users.id','prediccion.total as points');
		}
		
		$users = $users->leftJoin($predicciones, 'users.id', '=', 'prediccion.user_id')->where('role','<>','admin')->get();
		
		foreach ($users as $user) {
			// Si esta activado el registro de códigos sumo los puntos de los códigos
			if ( config('polla.code_section') ) {
				if (!is_null($user->cantidad)) {
					$user->points += $user->cantidad * config('polla.code_points');
				}
			}

			// si la trivia esta activa sumo los puntos de la trivia
			if (config('polla.trivia')) {
				$puntos_trivia = Pregunta_usuario::where('id_user',$user->id)->sum('puntos');
				if ($puntos_trivia != null && $puntos_trivia != 0) {
					$user->points += $puntos_trivia;
				}
			}

			// Guardo los puntos del usuario
			$points = ($user->points != null) ? $user->points : 0;
			DB::table('users')->where('id',$user->id)->update(['points' => $points]);
			if ($points != 0) {
				Plastimedia::notificar([
	                'id' => $user->id,
	                'icono' => 'copa.png',
	                'title' => 'Tus puntos fuerón calculados',
	                'content' => 'En total tienes '.$points.' puntos acumulados',
	                'link' => '#',
	            ]);
			}
			$points = 0;
		}

		return 'Puntos de los usuarios calculados';
	}
	

	/*
	 * Método para calcular los puntos de un usuario
	 */
	public function userPoints($id)
	{
		// Obtener los puntos de las predicciones
		$userPoints = DB::table('user_predictions')->where('user_id',$id)->sum('points');
		

		if ( config('polla.code_section') ) {
			// Obtener los puntos de los codigos registrados
			$codesReg = DB::table('user_codes')->where('user_id', $id)->count('id');
			$userPoints += $codesReg * config('polla.code_points');
		}
		if (config('polla.trivia')) {
			$puntos_trivia = Pregunta_usuario::where('id_user',$id)->sum('puntos');
			$userPoints	+= $puntos_trivia;
		}


		return $userPoints;
	}

	/*
	 * Método para calcular las posiciones de los usuarios
	 */
	public function userPositions()
	{
		// Obtengo la lista de todos los usuarios
		$users = User::where('role','<>','admin')->orderBy('points','desc')->get();

		$position = 0;
		$puntos = null;
		foreach ($users as $user) {
			if ($user->points !== $puntos) {
				$position++;
				$puntos = $user->points;
			}
			if ($user->position < $position) {
				Plastimedia::notificar([
	                'id' => $user->id,
	                'icono' => 'sube.png',
	                'title' => '¡Genial!, subiste de posición',
	                'content' => 'Ahora estas en la posicion: '.$position,
	                'link' => '#',
	            ]);
			}
			$user->position = $position;
			$user->save();
		}

		return 'Posiciones de los usuarios calculadas';
	}

	/*
	 * Método para calcular los puntos por prediccion
	 */
  public function import()
	{
		
		$partido = simplexml_load_file(config('polla.ruta_madre'));
		$match = Match::find($partido->id);

		$match->score_a = $partido->score_a;
		$match->score_b = $partido->score_b;
		$match->updated = $partido->updated;

		$match->save();

		return view('partidos.import');
	}

	/*
	 * Método para calcular los puntos por prediccion de los grupos
	 */
  public function predictionGroupPoints()
	{
		// Busco el partido que hay que editar
		$match = Match::where('updated', 1)->first();

		$am = $match->score_a;
		$bm = $match->score_b;

		foreach ($match->groupPredictions as $prediction) {
			$ap = $prediction->a_score;
			$bp = $prediction->b_score;

			// Calculo los puntos
			if ($am == $ap && $bm== $bp) {
				$points = 12;
			} elseif ( ($am > $bm && $ap > $bp) || ($am < $bm && $ap < $bp) || ($am == $bm && $ap == $bp) ) {
				if ($am == $ap || $bm == $bp) {
					$points = 7;
				} else {
					$points = 5;
				}
			}	elseif ($am == $ap || $bm == $bp) {
					$points = 2;
			} else {
				$points = 0;
			}

			// Guardo los puntos en la base de datos
			$prediction->points = $points;
			$prediction->save();
		}

		return 'Puntos de las predicciones de los grupos calculados';
	}

	/*
	 * Método para calcular los puntos de los grupos
	 */
  public function groupPoints()
	{
		$predicciones = DB::raw('( SELECT group_id, SUM(points) as total FROM group_predictions GROUP BY group_id ) as prediccion');

		$groups = DB::table('groups')
			->select('groups.id','prediccion.total as points')
			->leftJoin($predicciones, 'groups.id', '=', 'prediccion.group_id')
			->get();
		
		foreach ($groups as $group) {
			// Guardo los puntos del grupo
			DB::table('groups')->where('id',$group->id)->update(['points' => $group->points]);
		}

		return 'Puntos de los grupos calculados';
	}

	/*
	 * Método para calcular las posiciones de los grupos
	 */
	public function groupPositions()
	{
		// Obtengo la lista de los grupos
		$groups = Group::orderBy('points','desc')->get();

		$position = 0;
		$puntos = null;
		foreach ($groups as $group) {
			if ($group->points !== $puntos) {
				$position++;
				$puntos = $group->points;
			}
			$group->position = $position;
			$group->save();
		}

		return 'Posiciones de los grupos calculadas';
	}

}
