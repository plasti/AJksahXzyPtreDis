<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Code;
use App\UserCode;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Auth;
use Socialite;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/partidos';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        
        if (config('polla.code_reg')) {
            return Validator::make($data, [
                'name' => 'required|string|max:255',
                'email-reg' => 'required|string|email|max:255|unique:users,email',
                'password-reg' => 'required|string|min:6|confirmed',
                'g-recaptcha-response' => (config('polla.debug')) ? 'captcha' :'required|captcha',
                'code' => 'required|exists:codes,code',
                'terms' => 'present',
            ],[
                'name.required' => 'Ingresa tu nombre',
                'name.max' => 'Ingresaste más de 255 caracteres en el nombre',
                'email-reg.required' => 'Ingresa tu correo electrónico', 
                'email-reg.email' => 'Ingresa un correo electrónico válido', 
                'email.max' => 'Ingresaste más de 255 caracteres en el correo electrónico',
                'email.unique' => 'El correo que ingresaste ya está registrado',
                'password-reg.required' => 'Ingresa una contraseña', 
                'password-reg.min' => 'Ingresa más de 6 caracteres en la contraseña', 
                'password-reg.confirmed' => 'Las contraseñas deben coincidir',
                'code.required' => 'Ingresa un código válido', 
                'code.exists' => 'El código que ingresaste no es válido o ya fue registrado', 
                'terms.present' => 'Debes aceptar los términos y condiciones y las políticas de privacidad',
            ]);
        } else {
        	return Validator::make($data, [
                'name' => 'required|string|max:255',
                'email-reg' => 'required|string|email|max:255|unique:users,email',
                'password-reg' => 'required|string|min:6|confirmed',
                'g-recaptcha-response' => (config('polla.debug')) ? 'captcha' :'required|captcha',
                'terms' => 'present',
            ],[
                'name.required' => 'Ingresa tu nombre',
                'name.max' => 'Ingresaste más de 255 caracteres en el nombre',
                'email-reg.required' => 'Ingresa tu correo electrónico', 
                'email-reg.email' => 'Ingresa un correo electrónico válido', 
                'email-reg.max' => 'Ingresaste más de 255 caracteres en el correo electrónico',
                'email-reg.unique' => 'El correo que ingresaste ya está registrado',
                'password-reg.required' => 'Ingresa una contraseña', 
                'password-reg.min' => 'Ingresa más de 6 caracteres en la contraseña', 
                'password-reg.confirmed' => 'Las contraseñas deben coincidir',
                'terms.present' => 'Debes aceptar los términos y condiciones y las políticas de privacidad',
            ]);
        }
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email-reg'],
            'password' => bcrypt($data['password-reg']), 
        ]);

        if (config('polla.code_reg')) {
        	// Obtengo el código
        	$codigo = Code::where('code',$data['code'])->first();
        	// pongo el código como usado
        	$code = Code::find($codigo->id);
        	$code->code = '';
        	$code->used_code = $codigo->code;
        	$code->save();
        	// Guardo el codigo registrado
        	$userCode = new UserCode();
        	$userCode->user_id = $user->id;
        	$userCode->code_id = $codigo->id;
        	$userCode->save();
        }

        return $user;
    }

    // *******************************
    // LOGIN CON FACEBOOK
    // *******************************
    public function redirectToProvider()
    {
        return Socialite::driver('facebook')->redirect();
    }
    public function CallbackFacebook()
    {
        $user = Socialite::driver('facebook')->user(); 
        $mailSocialUser = $user->getEmail();
        $user_exist = User::where('email', $mailSocialUser)->first();
        if (!is_null($user_exist)) {
            
            $nueva_foto = User::find($user_exist->id);
            $nueva_foto->avatar = $user->getAvatar();
            $nueva_foto->update();

            return $this->AuthAndRedirect($user_exist); // Login y redirección
        }else {
            $userNew = User::create([
                'name' => $user->getName(),
                'email' => $user->getEmail(),
                'avatar' => $user->getAvatar(),
            ]);
            return $this->AuthAndRedirect($userNew); // Login y redirección
        }
    }


    // *******************************
    // LOGIN CON GOOGLE +
    // *******************************
    public function redirectToProviderGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    public function CallbackGoogle()
    {
        $user = Socialite::driver('google')->stateless()->user(); 
        $mailSocialUser = $user->getEmail();
        $user_exist = User::where('email', $mailSocialUser)->first();
        if (!is_null($user_exist)) {
            $nueva_foto = User::find($user_exist->id);
            $nueva_foto->avatar = $user->getAvatar();
            $nueva_foto->update();
            return $this->AuthAndRedirect($user_exist); // Login y redirección
        }else {
            $userNew = User::create([
            'name' => $user->getName(),
            'email' => $user->getEmail(),
            'avatar' => $user->getAvatar(),
            ]);
            return $this->AuthAndRedirect($userNew); // Login y redirección
        }
    }

    // *******************************
    // LOGIN CON TWITTER +
    // *******************************
    public function redirectToProviderTwitter()
    {
        dd('Ocurrio un problema');
        // return Socialite::driver('twitter')->redirect();
    }

    public function CallbackTwitter()
    {
        dd('Callback de twitter');
        // $user = Socialite::driver('twitter')->stateless()->user(); 
        // $mailSocialUser = $user->getEmail();
        // $user_exist = User::where('email', $mailSocialUser)->first();
        // if (!is_null($user_exist)) {
        //     return $this->AuthAndRedirect($user_exist); // Login y redirección
        // }else {
        //     $userNew = User::create([
        //     'name' => $user->getName(),
        //     'email' => $user->getEmail(),
        //     ]);
        //     return $this->AuthAndRedirect($userNew); // Login y redirección
        // }
    }



    public function AuthAndRedirect($user)
    {
        Auth::login($user);
        return redirect()->to('/partidos');
    }
}
