<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slider;
use Image;

class SliderController extends Controller
{
    public function index()
    {
    	$sliders = Slider::paginate(20);
    	return view('sliders.index', ['sliders' => $sliders]);
    }
    public function create()
    {
        $error_extension = false;
    	return view('sliders.create', ['error_extension' => $error_extension]);
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'img' => 'required',
            'name' => 'required|max:255',
            'status' => 'required',
        ], [
            'img.required' => 'Selecciona una imagen.',
            'name.required' => 'Ingresa el nombre del slider.',
            'name.max' => 'El nombre no debe superar los 255 caracteres.',
            'status.required' => 'Selecciona el estado del slider',
        ]);


        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ($img->getClientOriginalExtension() == 'jpg' ||
                $img->getClientOriginalExtension() == 'png' ||
                $img->getClientOriginalExtension() == 'jpeg' ) {
                $filename = time().'.'.$img->getClientOriginalExtension();
                // Creo la imagen
                Image::make($img)->fit(900, 300)->save( public_path( 'images/sliders/' . $filename ) );
                $slider = Slider::create([
                    'img' => $filename,
                    'name' => $data['name'],
                    'link' => $request->link,
                    'status' => $data['status'],
                ]);
                return redirect('sliders')->with('status', 'Slider guardado')->with('class', 'succes');
            } else {
                $error_extension = true;
                return view('sliders.create', ['error_extension' => $error_extension]);
            }
        }
    }
    public function edit($id)
    {
    	$slider = Slider::find($id);
        return view('sliders.edit', ['slider' => $slider, 'error_extension' => false]);
    }
    public function update(Request $request, $id)
    {
        $slider = Slider::find($id);
    	$data = $request->validate([
            'name' => 'required|max:255',
            'status' => 'required',
        ], [
            'name.required' => 'Ingresa el nombre del slider.',
            'name.max' => 'El nombre no debe superar los 255 caracteres.',
            'status.required' => 'Selecciona el estado del slider',
        ]);

        $slider->name = $data['name'];
        $slider->link = $request->link;
        $slider->status = $data['status'];

        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ($img->getClientOriginalExtension() == 'jpg' ||
                $img->getClientOriginalExtension() == 'png' ||
                $img->getClientOriginalExtension() == 'jpeg' ) {
                $filename = time().'.'.$img->getClientOriginalExtension();
                // Creo la imagen
                Image::make($img)->fit(900, 300)->save( public_path( 'images/sliders/' . $filename ) );
                if ($slider->img != 'default.jpg') {
                    if (file_exists( public_path( 'images/sliders/' . $slider->img ) )) {
                        unlink( public_path( 'images/sliders/' . $slider->img ) );
                    }
                }
                $slider->img = $filename;
            } else {
                $error_extension = true;
                return view('sliders.create', ['error_extension' => $error_extension]);
            }
        }
        $slider->update();
        return redirect('sliders')->with('status', 'Slider guardado')->with('class', 'succes');
    }
    public function delete($id)
    {
    	$slider = Slider::find($id);
        if ($slider->img != 'default.jpg') {
            if (file_exists( public_path( 'images/sliders/' . $slider->img ) )) {
                unlink( public_path( 'images/sliders/' . $slider->img ) );
            }
        }
        $slider->delete();
        return redirect('sliders')->with('status', 'Slider eliminado')->with('class', 'succes');
    }
}
