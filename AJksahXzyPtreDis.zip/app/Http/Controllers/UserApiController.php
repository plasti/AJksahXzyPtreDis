<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\User;
use Auth;

class UserApiController extends Controller
{
    public function login(Request $request)
    {
    	if ( Auth::attempt($request->data) ){
        	$user = User::find(Auth::user()->id);
        	$user->grupo_name = $user->group->name;
        	$user->avatar = $user->avatar();
        	return response()->json(['status' => 'Ok', 'data' => $user]);
        }else {
        	return response()->json(['status' => 'Fail', 'data' => 'Correo o contraseña incorrecta.']);
        }
    }

    public function profile(Request $request)
    {
        $data = $request->data;
        $user = User::find($data['id']);
        $user->grupo_name = $user->group->name;
        $user->avatar = $user->avatar();
        return response()->json(['status' => 'Ok', 'data' => $user]);
    }

    public function update_profile(Request $request)
    {

        $data = $request->data;
        $user = User::find($data['id']);
        $validator = Validator::make($data, [
            'name' => 'max:255',
            'email' => 'max:100|unique:users,email,'.$user->id,
        ], [
            'name.max' => 'El nombre no debe superar los 255 caracteres.',
            'email.max' => 'El correo no debe superar los 100 caracteres.',
            'email.unique' => 'Este correo ya esta registrado.',
        ]);
        if ($validator->fails()) {
            $errors = $validator->errors();
            $mensajes = '';
            foreach ($errors->all() as $message) {
                $mensajes .= '- '.$message;
            }
            return response()->json(['status' => 'Fail', 'data' => $mensajes]); 
        }else {
            $data = $request->data;
            $user = User::find($data['id']);
            $user->name = $data['name'];
            $user->email = $data['email'];
            if ($data['password'] != null) {
                $user->password = bcrypt($data['password']);
            }
            $base = $data['avatar'];
            if ($base <> null) {
                $filename = time().'_'.$data['id'].'_'.".jpg";
                $image_base64 = base64_decode($base);
                $a = file_put_contents(public_path( 'images/avatars/' . $filename ), $image_base64);
                $user->avatar = $filename;
            }
            $user->update();
            $user->avatar = $user->avatar();
            return response()->json(['status' => 'Ok', 'data' => $user]);
        }
    }
}
