<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comentarios;
use App\Match;
use Auth;
use App\Plastimedia;
use App\User;

class ComentariosController extends Controller
{
    public function show($id)
    {
    	$match = Match::find($id);
    	return view('comentarios.show', ['match' => $match]);
    }

    public function store(Request $request, $id)
    {
    	$comentario = Comentarios::create([
			'id_user' => Auth::user()->id,
			'id_match' => $id,
			'text' => $request->text,
    	]);

    	$response = [
    		'id' => $comentario->id,
    		'avatar' => $comentario->user->avatar(),
    		'name' => $comentario->user->name,
    		'text' => $comentario->text,
    		'fecha' => date_format(date_create($comentario->created_at), 'd/m/Y H:i').' HS',
    		'ruta' => route('comentarios.delete', $comentario->id),
    	];

        $ss = Comentarios::select('id_user')->where('id_match', $id)->where('id_user', '<>', Auth::user()->id)->groupBy('id_user')->get();
        foreach ($ss as $s) {
            Plastimedia::notificar([
                'id' => $s->id_user,
                'icono' => 'conversacion.png',
                'title' => Auth::user()->name.' comentó en el partido '.$comentario->match->team_a->country.' VS '.$comentario->match->team_b->country,
                'content' => 'Da click en el botón ver más para leer su comentario',
                'link' => route('comentarios', $id),
            ]);
        }
    	return response()->json(['status' => 'Ok', 'data' => $response]);
    }

    public function delete($id)
    {
    	$comentario = Comentarios::find($id);
    	$comentario->delete();
    	return response()->json(['status' => 'Ok', 'data' => $comentario]);
    }
}
