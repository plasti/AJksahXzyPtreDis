<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pregunta;
use Image;

class PreguntasController extends Controller
{
    public function create($id)
    {
    	return view('preguntas.create', ['id' => $id]);
    }

    public function store(Request $request, $id)
    {
    	$data = $request->validate([
    		'pregunta' => 'required|max:500',
    		'tiempo' => 'required',
	        'puntos' => 'required|max:2',
	        'opcion_a' => 'required|max:300',
	        'opcion_b' => 'required|max:300',
	        'opcion_c' => 'required|max:300',
	        'opcion_d' => 'required|max:300',
	        'respuesta' => 'required',
    	], [
    		'pregunta.required' => 'Ingresa la pregunta.',
    		'tiempo.required' => 'Ingresa el tiempo de respuesta.',
    		'pregunta.max' => 'La pregunta no debe superar los 500 caracteres.',
	        'puntos.required' => 'Ingresa el puntaje para la pregunta.',
	        'puntos.max' => 'El puntaje no debe superar las 2 cifras.',
	        'opcion_a.required' => 'Ingresa la opcion A.',
	        'opcion_a.max' => 'la opcion A no debe superar los 300 caracteres.',
	        'opcion_b.required' => 'Ingresa la opcion B.',
	        'opcion_b.max' => 'la opcion B no debe superar los 300 caracteres.',
	        'opcion_c.required' => 'Ingresa la opcion C.',
	        'opcion_c.max' => 'la opcion C no debe superar los 300 caracteres.',
	        'opcion_d.required' => 'Ingresa la opcion D.',
	        'opcion_d.max' => 'la opcion D no debe superar los 300 caracteres.',
	        'respuesta.required' => 'Selecciona una respuesta',
    	]);

    	$pregunta = Pregunta::create([
    		'id_trivia' => $id,
			'pregunta' => $request->pregunta,
			'tiempo' => $request->tiempo,
			'puntos' => $request->puntos,
			'opcion_a' => $request->opcion_a,
			'opcion_b' => $request->opcion_b,
			'opcion_c' => $request->opcion_c,
			'opcion_d' => $request->opcion_d,
			'respuesta' => $request->respuesta,
    	]);

    	if ($request->hasFile('imagen')) {
			$imagen = $request->file('imagen');
			if ( $imagen->getClientOriginalExtension() == 'jpg' || 
				 $imagen->getClientOriginalExtension() == 'png' ||
				 $imagen->getClientOriginalExtension() == 'jpeg' 
			) {
				if (!file_exists(public_path( 'images/preguntas/'))) {
					mkdir(public_path( 'images/preguntas/'));
				}
				$filename = $pregunta->id.'_'.time().'_'.'.'.$imagen->getClientOriginalExtension();
				Image::make($imagen)->fit(400, 270)->save( public_path( 'images/preguntas/'.$filename ) );
				$pregunta->imagen = $filename;
				$pregunta->update();
			}
		}

		return redirect('trivias/'.$id.'/edit')->with('status', 'Pregunta creada')->with('class', 'succes');
    }

    public function edit($id)
    {
    	$pregunta = Pregunta::find($id);
    	return view('preguntas.edit', ['pregunta' => $pregunta]);
    }

    public function update(Request $request, $id)
    {
    	$data = $request->validate([
    		'pregunta' => 'required|max:500',
    		'tiempo' => 'required',
	        'puntos' => 'required|max:2',
	        'opcion_a' => 'required|max:300',
	        'opcion_b' => 'required|max:300',
	        'opcion_c' => 'required|max:300',
	        'opcion_d' => 'required|max:300',
	        'respuesta' => 'required',
    	], [
    		'pregunta.required' => 'Ingresa la pregunta.',
    		'tiempo.required' => 'Ingresa el tiempo de respuesta.',
    		'pregunta.max' => 'La pregunta no debe superar los 500 caracteres.',
	        'puntos.required' => 'Ingresa el puntaje para la pregunta.',
	        'puntos.max' => 'El puntaje no debe superar las 2 cifras.',
	        'opcion_a.required' => 'Ingresa la opcion A.',
	        'opcion_a.max' => 'la opcion A no debe superar los 300 caracteres.',
	        'opcion_b.required' => 'Ingresa la opcion B.',
	        'opcion_b.max' => 'la opcion B no debe superar los 300 caracteres.',
	        'opcion_c.required' => 'Ingresa la opcion C.',
	        'opcion_c.max' => 'la opcion C no debe superar los 300 caracteres.',
	        'opcion_d.required' => 'Ingresa la opcion D.',
	        'opcion_d.max' => 'la opcion D no debe superar los 300 caracteres.',
	        'respuesta.required' => 'Selecciona una respuesta',
    	]);
    	$pregunta = Pregunta::find($id);
		$pregunta->pregunta = $request->pregunta;
		$pregunta->tiempo = $request->tiempo;
		$pregunta->puntos = $request->puntos;
		$pregunta->opcion_a = $request->opcion_a;
		$pregunta->opcion_b = $request->opcion_b;
		$pregunta->opcion_c = $request->opcion_c;
		$pregunta->opcion_d = $request->opcion_d;
		$pregunta->respuesta = $request->respuesta;

    	if ($request->hasFile('imagen')) {
			$imagen = $request->file('imagen');
			if ( $imagen->getClientOriginalExtension() == 'jpg' || 
				 $imagen->getClientOriginalExtension() == 'png' ||
				 $imagen->getClientOriginalExtension() == 'jpeg' 
			) {
				if (!file_exists(public_path( 'images/preguntas/'))) {
					mkdir(public_path( 'images/preguntas/'));
				}

				if($pregunta->imagen <> null){
                    unlink(public_path( 'images/preguntas/'.$pregunta->imagen)); //eliminar imagen 
                }

				$filename = $pregunta->id.'_'.time().'_'.'.'.$imagen->getClientOriginalExtension();
				Image::make($imagen)->fit(400, 270)->save( public_path( 'images/preguntas/'.$filename ) );
				$pregunta->imagen = $filename;
				$pregunta->update();
			}
		}
		$pregunta->update();
		return redirect('trivias/'.$pregunta->id_trivia.'/edit')->with('status', 'Pregunta actualizada')->with('class', 'succes');
    }

    public function delete($id)
    {
    	$pregunta = Pregunta::find($id);
    	$pregunta->delete();
    	return redirect('trivias/'.$pregunta->id_trivia.'/edit')->with('status', 'Pregunta eliminada')->with('class', 'succes');	
    }
}
