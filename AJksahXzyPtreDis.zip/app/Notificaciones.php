<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notificaciones extends Model
{

	protected $table = 'notificaciones';

	protected $fillable = [
		'id_user',
		'titulo',
		'descripcion',
		'link',
		'estado',
		'icono',
	];

	/**
	* Obtiene la información del usuario.
	*/
	public function user()
	{
		return $this->belongsTo('App\User', 'id_user');
	}

	public function icono()
	{
		return asset('images/notificaciones').'/'.$this->icono;
	}

}
