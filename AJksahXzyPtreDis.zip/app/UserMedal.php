<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserMedal extends Model
{
	protected $table = 'medals';

	protected $fillable = [
		'user_id',
		'medal_id',
		'delivered',
	];

	/**
	* Obtiene la información de la medalla
	*/
	public function medal()
	{
		return $this->hasOne('App\Medal', 'medal_id');
	}
}
