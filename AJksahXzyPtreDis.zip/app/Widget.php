<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Widget extends Model
{
    protected $table = 'widget';

	protected $fillable = [
		'estado',
		'titulo',
		'wpp',
		'tel',
		'color',
	];
}
