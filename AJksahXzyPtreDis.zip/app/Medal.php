<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Medal extends Model
{
	protected $table = 'medals';

	protected $fillable = [
		'name',
		'desc',
		'img',
	];

}
