<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Pregunta_usuario;

class Pregunta extends Model
{
    protected $table = 'preguntas';

	protected $fillable = [
        'id_trivia',
        'pregunta',
        'puntos',
        'imagen',
        'opcion_a',
        'opcion_b',
        'opcion_c',
        'opcion_d',
        'respuesta',
        'tiempo',
	];

    public function imagen()
    {
        if ($this->imagen != null) {
            return asset('images/preguntas').'/'.$this->imagen;
        }
    }

    public function respuesta($id_user)
    {
        return Pregunta_usuario::where('id_user', $id_user)->where('id_pregunta', $this->id)->first();
    }
}
